// Electrical model: rail voltages, branch currents, meter readings, and the full-system simulation.
import * as THREE from 'three';

// ------------------------------------------------------------------ component data (datasheet values)
export const LOADS = {
  nrf: { idle: 3.2, blinky: 4.5, label: 'nRF5340 (app + net core, DK)' },
  sensors: { as7341: 0.30, lsm6: 0.55, h3lis: 0.30, bme: 0.90, rtc: 0.01, gauge: 0.03, label: 'I2C sensors' },
  boardLeds: 0.9 * 5,          // green "on" LEDs on LSM6, H3LIS, BME, RTC, gauge (AS7341's cut)
  max31865: 1.6,               // each, plus ~0.55 mA RTD bias while converting
  nfc: { off: 0, pd: 0.01, idle: 5.16, poll: 24.34, rf: 71.95 },
  led: { r: 13.6, g: 7.6, b: 7.4, w: 8.2 },    // at 5.2 V through 220 Ω and a saturated PN2222
  base: 2.6,                   // (3.3 - 0.75) / 1 kΩ
  boostEff: 0.88, boostIq: 0.05, ldoIq: 0.004,
  chg: 500,                    // bq24074 fast-charge with the 0.5 A jumper
};

export function defaultState() {
  return { toggle: 0, bat: 0, usb: 0, docked: 0, pi: 0, boost: 0, led: '', sw9: -1, sw10: 1, swPower: 1, fw: '', nfc: 'pd',
    battV: 3.92, soc: 72, cartridge: 0, tCore: 4.2, tAmb: 22.0, gas: 182, accel: [0, 0, 1], highg: 0, color: 'green', heater: 0, built: new Set() };
}

// ------------------------------------------------------------------ solve the circuit for one state
export function solve(st) {
  const b = (id) => st.built.has(id);
  const r = { V: {}, I: {}, notes: [] };
  const batOK = st.bat && b('w_bat') && b('w_jst');
  const dockOK = st.docked && st.pi && b('w_m1') && b('w_m2') && b('w_pi5v') && b('w_pigd');
  const vbus = dockOK ? 4.96 : 0;
  let out = 0;
  if (dockOK) out = 4.4; else if (batOK) out = st.battV - 0.03;
  const swOK = st.toggle && b('w_out_sw') && b('w_sw_vsys');
  const vsys = swOK ? out : 0;
  const ldoOK = b('ldo') && b('w_ldo_vin1') && b('w_ldo_vin2') && b('w_ldo_gnd');
  let v33 = ldoOK && vsys > 0 ? (vsys >= 3.36 ? 3.30 : Math.max(0, vsys - 0.06)) : 0;
  const p21 = b('j_p21p') && b('j_p21n');
  const dkCfg = st.sw9 === 0 && st.sw10 === -1 && st.swPower === -1;
  let vdd = 0;
  if (st.usb && st.swPower === -1) vdd = 3.0; else if (p21 && dkCfg) vdd = v33;
  const fwRun = vdd > 1.7 && st.fw;
  const d5 = fwRun && st.boost && b('j_en');
  const boostOK = b('boost') && b('w_boost_vin') && b('w_boost_gnd') && b('w_boost_out');
  const v5 = d5 && boostOK && vsys >= 1.8 ? 5.2 : 0;
  // loads on VDD (3.3 V)
  const I = {};
  I.nrf = vdd > 1.7 ? (st.fw === 'blinky' ? LOADS.nrf.blinky : LOADS.nrf.idle) : 0;
  const i2c = b('qt_VDD1') && b('qt_GND1') && vdd > 0;
  const chain = ['qt_dk', 'qt_1', 'qt_2', 'qt_3', 'qt_4', 'qt_5'];
  const on = { as7341: i2c, lsm6: i2c && b('qt_1'), h3lis: i2c && b('qt_1') && b('qt_2'), bme: i2c && b('qt_1') && b('qt_2') && b('qt_3'), rtc: i2c && chain.slice(1, 5).every(b), gauge: i2c && chain.every(b) };
  I.sensors = 0; for (const k of Object.keys(on)) if (on[k]) I.sensors += LOADS.sensors[k] + (k !== 'as7341' ? 0.9 : 0) + (k === 'bme' && st.heater ? 11.5 : 0) + (k === 'as7341' && st.colorRead ? 1.5 : 0);
  const pp2 = b('j_3v3') && b('j_gnd2') && vdd > 0;
  I.core = pp2 && b('hdr_core') && b('w_core_vin') && b('w_core_gnd') ? LOADS.max31865 + 0.55 : 0;
  I.amb = pp2 && b('hdr_amb') && b('w_amb_vin') && b('w_amb_gnd') ? LOADS.max31865 + 0.55 : 0;
  const leds = new Set(v5 ? st.led.split('') : []);
  const ledBuilt = { r: b('w_rgb_r') && b('w_rgb_a') && b('j_a1') && b('q1') && b('rb1') && b('w_e1'), g: b('w_rgb_g') && b('w_rgb_a') && b('j_a2') && b('q2') && b('rb2') && b('w_e2'), b: b('w_rgb_b') && b('w_rgb_a') && b('j_a3') && b('q3') && b('rb3') && b('w_e3'), w: b('w_wl_a') && b('w_wl_k') && b('rw') && b('j_a4') && b('q4') && b('rb4') && b('w_e4') };
  I.base = 0; I.led = { r: 0, g: 0, b: 0, w: 0 };
  for (const c of 'rgbw') if (fwRun && st.led.includes(c)) { I.base += LOADS.base; if (leds.has(c) && ledBuilt[c]) I.led[c] = LOADS.led[c]; }
  const nfcOK = b('n_5v') && b('n_gnd') && v5 > 0;
  I.nfc = nfcOK ? LOADS.nfc[st.nfc] : 0;
  I.v33 = I.nrf + I.sensors + I.core + I.amb + I.base;
  I.v5 = I.nfc + I.led.r + I.led.g + I.led.b + I.led.w;
  I.ldoIn = v33 > 0 && !st.usb ? (p21 && dkCfg ? I.v33 : 0) + LOADS.ldoIq : 0;
  I.boostIn = v5 > 0 ? (5.2 * I.v5) / (LOADS.boostEff * Math.max(vsys, 1.8)) + LOADS.boostIq : 0;
  I.sys = vsys > 0 ? I.ldoIn + I.boostIn : 0;
  I.chg = dockOK && batOK && st.soc < 99.5 ? LOADS.chg * (st.soc > 90 ? Math.max(0.08, (100 - st.soc) / 10) : 1) : 0;
  I.vbus = dockOK ? I.chg + I.sys * vsys / 4.4 : 0;
  I.bat = batOK ? (dockOK ? I.chg : -I.sys) : 0;  // + = charging
  I.pi = st.pi ? 330 : 0;
  r.I = I;
  // net voltages
  const V = r.V;
  V.GND = 0; V.BAT = batOK ? st.battV : (st.bat && b('w_bat') ? st.battV : 0); V.OUT = out; V.VSYS = vsys; V['3V3'] = v33; V.VDD = vdd; V['5V_SW'] = v5;
  V.VBUS = vbus; V.PI5V = st.pi ? 5.08 : 0; V.USB = st.usb ? 5.0 : 0;
  const hi = vdd;
  V.I2C = i2c ? vdd : 0; V.SCK = 0; V.MOSI = 0; V.MISO = 0; V.D10 = fwRun ? hi : 0; V.D9 = fwRun ? hi : 0; V.D7 = fwRun ? hi : 0; V.D6 = 0;
  V.D5 = d5 ? hi : 0; V.D4 = fwRun ? (st.cartridge && b('w_reed2') ? 0 : hi) : 0; V.D2 = 0; V.D3 = 0; V.A5 = fwRun ? (st.soc < 6 ? 0 : hi) : 0;
  V.A0 = fwRun ? (dockOK ? 0 : hi) : 0; V.D1 = fwRun ? hi : 0; V.D0 = dockOK ? 3.3 : (fwRun ? hi : 0); V.PI_TX = st.pi ? 3.3 : 0; V.PI_RX = st.pi ? 3.3 : 0;
  for (const [k, c] of [['A1', 'r'], ['A2', 'g'], ['A3', 'b'], ['A4', 'w']]) V[k] = fwRun && st.led.includes(c) ? hi : 0;
  for (const [k, c] of [['LED_R', 'r'], ['LED_G', 'g'], ['LED_B', 'b'], ['LED_W', 'w']]) V[k] = I.led[c] > 0 ? 0.12 : (v5 ? v5 - 2.4 : 0);
  V.LED_WA = I.led.w > 0 ? 5.2 - 8.2 * 0.22 : v5;
  for (const p of ['core', 'amb']) { const on = I[p] > 0; V[p + '_F+'] = on ? 0.62 : 0; V[p + '_R+'] = on ? 0.62 : 0; V[p + '_R-'] = on ? 0.0 : 0; V[p + '_F-'] = 0; }
  r.dockOK = dockOK; r.batOK = batOK; r.fwRun = fwRun; r.on = on; r.ledBuilt = ledBuilt;
  return r;
}

// current through a wire (mA) by role
export function wireCurrent(w, R) {
  const I = R.I;
  switch (w.role) {
    case 'bat': return I.bat;
    case 'sys': case 'sys_ret': return I.sys;
    case 'ldo_in': return I.ldoIn;
    case 'boost_in': return I.boostIn;
    case 'v5_out': return I.v5;
    case 'v33': case 'v33_ret': return R.V.VDD > 0 && !(R.V.USB > 0) ? I.v33 : 0;
    case 'pp2_3v3': return I.core + I.amb;
    case 'rtd_sup': return w.id.includes('core') ? I.core : I.amb;
    case 'i2c_pwr': case 'i2c_ret': return I.sensors;
    case 'nfc': case 'nfc_ret': return I.nfc;
    case 'led_a': return I.led.r + I.led.g + I.led.b;
    case 'led1': return I.led.r; case 'led2': return I.led.g; case 'led3': return I.led.b; case 'led4': return I.led.w;
    case 'led_ret1': return I.led.r + (I.led.r ? LOADS.base : 0); case 'led_ret2': return I.led.g + (I.led.g ? LOADS.base : 0);
    case 'led_ret3': return I.led.b + (I.led.b ? LOADS.base : 0); case 'led_ret4': return I.led.w + (I.led.w ? LOADS.base : 0);
    case 'base1': return R.V.A1 ? LOADS.base : 0; case 'base2': return R.V.A2 ? LOADS.base : 0; case 'base3': return R.V.A3 ? LOADS.base : 0; case 'base4': return R.V.A4 ? LOADS.base : 0;
    case 'vbus': case 'vbus_ret': return I.vbus;
    case 'pi_in': return I.pi + I.vbus;
    case 'rtd_f': return R.V[w.net] !== undefined && (w.id.startsWith('core') ? I.core : I.amb) ? 0.55 : 0;
    default: return 0;
  }
}

// ------------------------------------------------------------------ test points for the meter
// name -> { net or resistance rule, label, where: [partId, pin] | [pp, row, col] }
export const TP = {
  'pp1:GND': { net: 'GND', label: 'PP1 GND rail', where: ['pp1', 'RB1', 4] },
  'pp1:VSYS': { net: 'VSYS', label: 'PP1 VSYS rail', where: ['pp1', 'RT1', 8] },
  'pp1:A12': { net: '3V3', label: 'P21 + pin (LDO out)', where: ['h_p21p', 'pin'] },
  'pp1:5V_SW': { net: '5V_SW', label: 'PP1 5V_SW rail', where: ['pp1', 'RB0', 24] },
  'pp1:RB0_28': { net: '5V_SW', label: 'White-LED resistor, rail end', where: ['pp1', 'RB0', 28] },
  'pp1:C28': { net: 'LED_WA', label: 'White-LED resistor, LED end', where: ['pp1', 'C', 28] },
  'chg:LIPO': { net: 'BAT', label: 'Charger LIPO pad', where: ['chg', 'LIPO'] },
  'chg:GND': { net: 'GND', label: 'Charger GND pad', where: ['chg', 'GND2'] },
  'chg:OUT': { net: 'OUT', label: 'Charger OUT pad', where: ['chg', 'OUT'] },
  'chg:VBUS': { net: 'VBUS', label: 'Charger VBUS pad', where: ['chg', 'VBUS'] },
  'chg:1A_a': { special: 'jumper1a', label: '1.0A jumper pad', where: ['chgj', -0.9] },
  'chg:1A_b': { special: 'jumper1a', label: '1.0A jumper pad', where: ['chgj', 0.9] },
  'tog:COM': { net: 'OUT', special: 'toggle', label: 'Switch COM lug', where: ['tog', 'COM'] },
  'tog:L1': { net: 'VSYS', special: 'toggle', label: 'Switch L1 lug', where: ['tog', 'L1'] },
  'dk:VDD1': { net: 'VDD', label: 'DK VDD socket', where: ['dk', 'VDD1'] },
  'dk:GND1': { net: 'GND', label: 'DK GND socket', where: ['dk', 'GND1'] },
  'dk:D5': { net: 'D5', label: 'DK D5 (boost EN)', where: ['dk', 'D5'] },
  'dk:D4': { net: 'D4', label: 'DK D4 (reed)', where: ['dk', 'D4'] },
  'dk:A0': { net: 'A0', label: 'DK A0 (dock detect)', where: ['dk', 'A0'] },
  'as7341:SDA': { net: 'I2C', label: 'AS7341 SDA pad', where: ['as7341', 'SDA'] },
  'pp2:GND': { net: 'GND', label: 'PP2 GND rail', where: ['pp2', 'RB1', 22] },
  'pp2:3V3': { net: 'VDD', label: 'PP2 3V3 rail', where: ['pp2', 'RB0', 22] },
  'magDock:P1': { net: 'VBUS', special: 'dockpin', label: 'Dock pin 1 (fused 5 V)', where: ['magDock', 'P1'] },
  'magDock:P2': { net: 'GND', special: 'dockpin', label: 'Dock pin 2 (GND)', where: ['magDock', 'P2'] },
  'magDock:P5': { net: 'GND', label: 'Dock pin 5 (detect)', where: ['magDock', 'P5'] },
  'core:F+': { net: 'core_F+', special: 'rtd', label: 'CORE probe red', where: ['core', 'F+'] },
  'core:F-': { net: 'core_F-', special: 'rtd', label: 'CORE probe white', where: ['core', 'F-'] },
  'gauge:BAT': { net: 'BAT', label: 'Gauge VBAT pad', where: ['gauge', 'VBAT'] },
  'nfc:5V': { net: '5V_SW', label: 'NFC 5 V wire', where: ['nfc', 'CONN'] },
};

export function meterRead(mode, a, b, st, R, built) {
  const A = TP[a], Bp = TP[b];
  if (!A || !Bp) return { text: '—' };
  const noise = (k) => (Math.sin(performance.now() / 370 + k) * 0.5 + Math.sin(performance.now() / 910 + k * 3) * 0.5);
  if (mode === 'V') {
    let va = R.V[A.net] ?? 0, vb = R.V[Bp.net] ?? 0;
    if (A.special === 'dockpin' || Bp.special === 'dockpin') { va = a === 'magDock:P1' ? (st.pi ? 4.97 : 0) : 0; vb = b === 'magDock:P1' ? (st.pi ? 4.97 : 0) : 0; }
    const v = va - vb + (va - vb !== 0 ? noise(1) * 0.004 : 0);
    return { value: v, text: (Math.abs(v) < 0.005 ? 0 : v).toFixed(v > 9.99 ? 1 : 2), unit: 'V' };
  }
  // resistance / continuity (meter injects its own current)
  if (A.special === 'jumper1a' && Bp.special === 'jumper1a') return built.has('cut1a') ? { text: 'OL', unit: 'Ω', ol: true } : { text: '0.1', unit: 'Ω', beep: true };
  if (A.special === 'toggle' && Bp.special === 'toggle') return st.toggle ? { text: '0.0', unit: 'Ω', beep: true } : { text: 'OL', unit: 'Ω', ol: true };
  if (A.special === 'rtd' && Bp.special === 'rtd') { const T = 22 + noise(2) * 0.05; const r = 1000 * (1 + 3.9083e-3 * T - 5.775e-7 * T * T) + 0.4; return { text: r.toFixed(1), unit: 'Ω', value: r }; }
  if (A.special === 'dockpin' && Bp.special === 'dockpin') return { text: 'OL', unit: 'Ω', ol: true };
  if (A.net === Bp.net) return { text: '0.1', unit: 'Ω', beep: true };
  if ((A.net === '3V3' || A.net === 'VSYS') && Bp.net === 'GND') return st.toggle ? { text: '—', unit: 'Ω', note: 'Power is on: switch off before measuring resistance' } : { text: 'OL', unit: 'Ω', ol: true };
  return { text: 'OL', unit: 'Ω', ol: true };
}

// ------------------------------------------------------------------ AS7341 colour model (counts per channel for an indicator colour)
export const AS_CH = [['F1', 415], ['F2', 445], ['F3', 480], ['F4', 515], ['F5', 555], ['F6', 590], ['F7', 630], ['F8', 680], ['Clear', 0], ['NIR', 910]];
const INDICATOR = { // bromothymol blue transmission (0..1) through the vial at each channel
  yellow: [0.08, 0.10, 0.18, 0.55, 0.85, 0.92, 0.95, 0.96, 0.62, 0.97],
  green: [0.20, 0.30, 0.42, 0.66, 0.62, 0.48, 0.40, 0.60, 0.50, 0.97],
  blue: [0.55, 0.62, 0.66, 0.50, 0.24, 0.10, 0.08, 0.40, 0.38, 0.97],
};
const LED_SPEC = [0.18, 0.62, 0.55, 0.60, 0.72, 0.68, 0.55, 0.30, 1.0, 0.05]; // white LED spectrum seen by each channel
export function colourCounts(colour, dark = false) {
  const t = INDICATOR[colour];
  return AS_CH.map(([n], i) => Math.round(dark ? 18 + 4 * Math.random() : 120 + 5200 * LED_SPEC[i] * t[i] * (0.97 + 0.06 * Math.random())));
}
