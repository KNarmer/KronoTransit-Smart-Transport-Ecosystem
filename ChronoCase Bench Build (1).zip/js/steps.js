// One action per step. Each step names what appears (show), what it changes (state), and how to check it (test).
// tp(...) test points are resolved by sim.js; holes are [board, row, col].
export const BUILDS = {
  A: { name: 'Build A · Power system and DK', week: 'Week 2 · Nov 16–22' },
  B: { name: 'Build B · Backbone, I2C sensors and dock', week: 'Week 3 · Nov 23–29' },
  C: { name: 'Build C · Temperature, NFC, reed switch and lights', week: 'Week 4 · Nov 30–Dec 6' },
  D: { name: 'Build D · Into the pod', week: 'Week 5 · Dec 7–13' },
};
const H = (pp, ...holes) => ({ pp, holes });
const s = [];
const add = (b, title, text, o = {}) => s.push({ build: b, title, text, ...o });

// ============================================================ Build A
add('A', 'Fit standoffs to the DK', 'Screw four <b>12 mm nylon M2.5 standoffs</b> into the DK’s corner holes from below, nuts on top. Set the DK on the bench, logo end to the right. The DK ships without a USB cable.', { show: ['dk', 'so_dk'], focus: ['dk'], parts: ['dk', 'so_dk'], view: 'iso' });
add('A', 'Set SW10 to OFF', 'Slide <b>SW10 (VEXT→nRF)</b>, the small orange switch near the bottom-left, to <b>OFF</b> (left). With SW10 ON the external supply would power only the nRF chip, not the VDD pins the sensors use.', { state: { sw10: -1 }, focus: ['dk:sw10'], zoom: 34 });
add('A', 'Set SW9 to VDD', 'Slide <b>SW9 (nRF power source)</b> to the middle position, <b>VDD</b>. This lets the external 3.3 V on P21 run the whole board.', { state: { sw9: 0 }, focus: ['dk:sw9'], zoom: 40 });
add('A', 'Turn the DK’s power switch ON', 'Slide the DK’s <b>Power</b> switch (bottom-left corner) to <b>ON</b> (left). The pod’s toggle switch will be the real on/off control later.', { state: { swPower: -1 }, focus: ['dk:swPower'], zoom: 34 });
add('A', 'Plug in the USB cable', 'Plug the 6 in micro-USB cable (A2) into the DK’s <b>interface USB</b> on the left edge and into the laptop. Nothing else is connected yet, so USB is the only power source.', { show: ['usb'], parts: ['usb'], focus: ['dk:USB_IF'], zoom: 70, state: { usb: 1 } });
add('A', 'Flash blinky', 'In nRF Connect for VS Code build <code>blinky</code> for <code>nrf5340dk/nrf5340/cpuapp</code> and flash it. <b>LED1</b> blinks once a second.', { fw: ['west build -b nrf5340dk/nrf5340/cpuapp samples/basic/blinky', 'west flash', '*** Booting nRF Connect SDK ***', 'LED state: ON', 'LED state: OFF'], state: { fw: 'blinky' }, focus: ['dk:leds'], zoom: 50 });
add('A', 'Unplug the USB cable', 'Unplug the micro-USB cable. From here on the DK runs from the battery through P21; plug USB in only with the pod switched off.', { hide: ['usb'], state: { usb: 0 }, focus: ['dk'] });

add('A', 'Mount Perma-Proto #1', 'Fit two <b>6 mm standoffs</b> to Perma-Proto #1 (the power & light board) and set it in front of the DK, column 1 on the left. Rails: top outer <b>GND</b>, top inner <b>VSYS</b>, bottom inner <b>GND</b>, bottom outer <b>5V_SW</b>.', { show: ['pp1', 'so_pp1'], parts: ['pp1', 'so_pp1'], focus: ['pp1'], view: 'top' });
add('A', 'Insert the MCP1700', 'Push the <b>MCP1700-3302E</b> into <b>C10 · C11 · C12</b> with the flat face toward you. Left to right: GND, VIN, VOUT.', { show: ['ldo'], parts: ['ldo'], focus: ['ldo'], zoom: 45 });
add('A', 'Solder the MCP1700', 'Flip the board, solder the three legs (2–3 s each), then trim them flush.', { solder: H('pp1', ['C', 10], ['C', 11], ['C', 12]), focus: ['ldo'], view: 'under', zoom: 45 });
add('A', 'Insert the input capacitor', 'Push a <b>1 µF</b> ceramic capacitor (marked 105) into <b>B10 · B11</b>: VIN to GND.', { show: ['cin'], parts: ['cin'], focus: ['cin'], zoom: 45 });
add('A', 'Solder the input capacitor', 'Solder both legs underneath and trim.', { solder: H('pp1', ['B', 10], ['B', 11]), focus: ['cin'], view: 'under', zoom: 45 });
add('A', 'Insert the output capacitor', 'Push the second <b>1 µF</b> capacitor into <b>D12 · D13</b>: VOUT to the column that will be GND.', { show: ['cout'], parts: ['cout'], focus: ['cout'], zoom: 45 });
add('A', 'Solder the output capacitor', 'Solder both legs underneath and trim.', { solder: H('pp1', ['D', 12], ['D', 13]), focus: ['cout'], view: 'under', zoom: 45 });
add('A', 'LDO ground to the GND rail', 'Black 30 AWG, about 15 mm: <b>A10 → bottom inner rail</b> (GND). Strip 2 mm, push through, solder underneath.', { show: ['w_ldo_gnd'], parts: ['wire30b'], focus: ['w_ldo_gnd'], zoom: 40 });
add('A', 'Capacitor column to GND', 'Black 30 AWG: <b>A13 → bottom inner rail</b>. Column 13 is now GND for the output capacitor.', { show: ['w_cout_gnd'], parts: ['wire30b'], focus: ['w_cout_gnd'], zoom: 40 });
add('A', 'Bridge VIN across the channel', 'Red 30 AWG: <b>E11 → F11</b>, across the centre channel. The VIN strip now continues into the top half.', { show: ['w_ldo_vin1'], parts: ['wire30r'], focus: ['w_ldo_vin1'], zoom: 40 });
add('A', 'VIN to the VSYS rail', 'Red 30 AWG: <b>J11 → top inner rail</b> (VSYS).', { show: ['w_ldo_vin2'], parts: ['wire30r'], focus: ['w_ldo_vin2'], zoom: 40 });
add('A', 'Join the two GND rails', 'Black 30 AWG along the left edge: <b>top outer rail, column 1 → bottom inner rail, column 1</b>. Both GND rails are now one ground.', { show: ['w_gnd_join1'], parts: ['wire30b'], focus: ['w_gnd_join1'], zoom: 55 });
add('A', 'Header pin P21 +', 'Break off one male header pin. Solder it into <b>A12</b> (the LDO’s VOUT strip), long end up.', { show: ['h_p21p'], solder: H('pp1', ['A', 12]), parts: ['h_p21p'], focus: ['h_p21p'], zoom: 35 });
add('A', 'Header pin P21 −', 'One more pin into <b>B13</b> (GND column), long end up.', { show: ['h_p21n'], solder: H('pp1', ['B', 13]), parts: ['h_p21n'], focus: ['h_p21n'], zoom: 35 });
add('A', 'Check for shorts', 'Meter on continuity, nothing powered. Probe the <b>3.3 V pin (A12)</b> and the <b>GND rail</b>: no beep. Repeat VSYS rail to GND: no beep.', { test: { mode: 'ohm', a: 'pp1:A12', b: 'pp1:GND', expect: 'OL' }, focus: ['ldo'], zoom: 60 });
add('A', 'Header on the MiniBoost', 'Solder a 4-pin header to the <b>MiniBoost</b>, long pins down. Pins left to right: VIN, GND, 5V, EN.', { show: ['boost', 'hdr_boost'], parts: ['boost', 'hdr_boost'], focus: ['boost'], zoom: 40 });
add('A', 'Seat the MiniBoost', 'Push the header into <b>E20 · E21 · E22 · E23</b> (VIN, GND, 5V, EN); the board lies over the channel. Solder the four pins underneath.', { solder: H('pp1', ['E', 20], ['E', 21], ['E', 22], ['E', 23]), focus: ['boost'], view: 'under', zoom: 45 });
add('A', 'MiniBoost VIN to VSYS', 'Red 30 AWG: <b>D20 → top inner rail, column 18</b> (VSYS), passing left of the MiniBoost.', { show: ['w_boost_vin'], parts: ['wire30r'], focus: ['w_boost_vin'], zoom: 50 });
add('A', 'MiniBoost GND', 'Black 30 AWG: <b>A21 → bottom inner rail</b> (GND).', { show: ['w_boost_gnd'], parts: ['wire30b'], focus: ['w_boost_gnd'], zoom: 40 });
add('A', 'MiniBoost 5 V out to the 5V_SW rail', 'Red 30 AWG: <b>A22 → bottom outer rail</b>. That rail is now <b>5V_SW</b>: 5.2 V only while EN is high.', { show: ['w_boost_out'], parts: ['wire30r'], focus: ['w_boost_out'], zoom: 40 });
add('A', 'EN harness pin', 'Solder a header pin into <b>C23</b> (the EN strip). It becomes the D5 control point.', { show: ['h_en'], solder: H('pp1', ['C', 23]), parts: ['h_en'], focus: ['h_en'], zoom: 35 });
add('A', 'Ground harness pin', 'Solder a header pin into the <b>bottom inner rail at column 26</b> (GND), for the DK’s ground jumper.', { show: ['h_gnd1'], solder: H('pp1', ['RB1', 26]), parts: ['h_gnd1'], focus: ['h_gnd1'], zoom: 35 });

add('A', 'Mount the bq24074', 'Fit four 6 mm standoffs and set the <b>bq24074 charger</b> to the right of the board, JST sockets facing right.', { show: ['chg', 'so_chg'], parts: ['chg', 'so_chg'], focus: ['chg'], zoom: 70 });
add('A', 'Cut the 1.0 A trace', 'The charger ships at <b>1.0 A</b> through a thin trace between the <b>1.0A</b> pads. Score it with a hobby knife until the meter reads open across those pads.', { cut: 'cut1a', show: ['cut1a'], focus: ['chg:jumpers'], zoom: 22 });
add('A', 'Bridge the 0.5 A jumper', 'Bridge the two <b>0.5A</b> pads with a solder blob. Charge current is now 500 mA (0.2 C for the 2,500 mAh cell).', { show: ['blob05'], focus: ['chg:jumpers'], zoom: 22 });
add('A', 'Check the jumpers', 'Continuity: across the <b>1.0A</b> pads, no beep; across the <b>0.5A</b> pads, beep.', { test: { mode: 'ohm', a: 'chg:1A_a', b: 'chg:1A_b', expect: 'OL' }, focus: ['chg:jumpers'], zoom: 26 });
add('A', 'Fit the toggle switch', 'Pass the <b>toggle switch</b> through the scrap-PETG test bracket and tighten the nut. Lugs point down: L1, COM (middle), L2.', { show: ['bracket', 'tog'], parts: ['tog', 'bracket'], focus: ['tog'], zoom: 60 });
add('A', 'Charger OUT to the switch', 'Twist two red 30 AWG strands together (doubled for current). Solder <b>bq24074 OUT → switch COM</b> (middle lug).', { show: ['w_out_sw'], parts: ['wire30r'], focus: ['w_out_sw'], zoom: 90 });
add('A', 'Switch to VSYS', 'Doubled red: <b>switch L1 → PP1 top inner rail, column 30</b> (VSYS).', { show: ['w_sw_vsys'], parts: ['wire30r'], focus: ['w_sw_vsys'], zoom: 90 });
add('A', 'Charger GND to the board', 'Doubled black: <b>bq24074 GND (pad next to VBUS) → PP1 top outer rail, column 29</b> (GND).', { show: ['w_chg_gnd'], parts: ['wire30b'], focus: ['w_chg_gnd'], zoom: 100 });
add('A', 'Set the switch OFF', 'Flip the lever so <b>COM is not connected to L1</b>. Confirm with the meter (COM to L1: no beep). This is OFF from now on.', { state: { toggle: 0 }, test: { mode: 'ohm', a: 'tog:COM', b: 'tog:L1', expect: 'OL' }, focus: ['tog'], zoom: 50 });
add('A', 'Mount the MAX17048', 'Fit two 6 mm standoffs and set the <b>MAX17048 fuel gauge</b> behind the charger, JST sockets facing right.', { show: ['gauge', 'so_gauge'], parts: ['gauge'], focus: ['gauge'], zoom: 60 });
add('A', 'Place the battery', 'Set the <b>2,500 mAh LiPo</b> to the right of the gauge, lead toward it. Don’t plug it in yet.', { show: ['bat'], parts: ['bat'], focus: ['bat'], zoom: 110 });
add('A', 'Gauge to charger', 'JST-PH jumper (A5): <b>gauge’s other socket → charger’s LiPo Batt socket</b>. The gauge sits inline and measures every milliamp.', { show: ['w_jst'], parts: ['w_jst'], focus: ['w_jst'], zoom: 90 });
add('A', 'Plug in the battery', 'Plug the battery lead into the <b>gauge’s first socket</b>. Its two sockets are wired straight through, so either is fine.', { show: ['w_bat'], state: { bat: 1 }, focus: ['w_bat'], zoom: 90 });
add('A', 'Check the battery', 'Meter on DC volts: charger <b>LIPO pad</b> to <b>GND</b> reads the cell, 3.6–4.2 V.', { test: { mode: 'V', a: 'chg:LIPO', b: 'chg:GND', expect: [3.6, 4.2] }, focus: ['chg'], zoom: 60 });
add('A', 'P21 + to the DK', 'Female/female jumper, red: <b>A12 pin → DK P21 “+”</b> (lower pin of the right-angle pair on the left edge).', { show: ['j_p21p'], parts: ['jFF'], focus: ['j_p21p'], zoom: 120 });
add('A', 'P21 − to the DK', 'Female/female jumper, black: <b>B13 pin → DK P21 “−”</b> (upper pin).', { show: ['j_p21n'], parts: ['jFF'], focus: ['j_p21n'], zoom: 120 });
add('A', 'EN to D5', 'Female/male jumper, orange: female end on the <b>C23 pin</b>, male end into the DK socket <b>D5</b>.', { show: ['j_en'], parts: ['jFM'], focus: ['j_en'], zoom: 130 });
add('A', 'Ground jumper', 'Female/male jumper, black: <b>GND pin (rail, column 26) → DK GND</b> (power header).', { show: ['j_gnd1'], parts: ['jFM'], focus: ['j_gnd1'], zoom: 120 });
add('A', 'Switch ON', 'Flip the toggle to <b>ON</b>. The DK starts from the battery through the LDO: LED1 blinks (blinky is still flashed).', { state: { toggle: 1 }, focus: ['tog', 'dk'], zoom: 200 });
add('A', 'Measure VSYS', 'DC volts: <b>PP1 top inner rail</b> (VSYS) to GND reads the battery, 3.6–4.2 V.', { test: { mode: 'V', a: 'pp1:VSYS', b: 'pp1:GND', expect: [3.6, 4.2] }, focus: ['pp1'], view: 'top' });
add('A', 'Measure the 3.3 V rail', 'DC volts: <b>A12 pin</b> (P21 +) to GND: <b>3.24–3.36 V</b>.', { test: { mode: 'V', a: 'pp1:A12', b: 'pp1:GND', expect: [3.24, 3.36] }, focus: ['ldo'], zoom: 60 });
add('A', 'Measure the DK’s VDD', 'DC volts: DK socket <b>VDD</b> (power header) to GND: <b>3.24–3.36 V</b>. If it reads 0 V, re-check SW9 = VDD and SW10 = OFF.', { test: { mode: 'V', a: 'dk:VDD1', b: 'dk:GND1', expect: [3.24, 3.36] }, focus: ['dk:VDD1'], zoom: 60 });
add('A', 'Check 5V_SW is off', 'DC volts: <b>bottom outer rail</b> (5V_SW) to GND reads <b>0.00 V</b>: EN is low, and the MiniBoost’s output disconnect keeps the rail dead.', { test: { mode: 'V', a: 'pp1:5V_SW', b: 'pp1:GND', expect: [0, 0.05] }, focus: ['boost'], zoom: 60 });
add('A', 'Switch OFF before flashing', 'One power source at a time. Flip the toggle <b>OFF</b> before plugging in USB.', { state: { toggle: 0 }, focus: ['tog'], zoom: 50 });
add('A', 'Plug in USB to flash', 'Plug the micro-USB cable into the DK’s interface USB.', { show: ['usb'], state: { usb: 1 }, focus: ['dk:USB_IF'], zoom: 70 });
add('A', 'Flash the pod app', 'Flash the pod app with the <code>boost on|off</code> shell command; <code>main()</code> drives D5 low first.', { fw: ['west build -b nrf5340dk/nrf5340/cpuapp app', 'west flash', 'uart:~$ help', 'boost  : switch the 5 V rail'], state: { fw: 'app' }, focus: ['dk'] });
add('A', 'Unplug USB', 'Unplug the micro-USB cable.', { hide: ['usb'], state: { usb: 0 }, focus: ['dk:USB_IF'], zoom: 70 });
add('A', 'Switch ON', 'Flip the toggle <b>ON</b>. The app boots from the battery.', { state: { toggle: 1 }, focus: ['tog'], zoom: 60 });
add('A', 'Boost on', 'In the shell type <code>boost on</code>. The 5V_SW rail now reads <b>5.15–5.25 V</b>.', { fw: ['uart:~$ boost on', 'boost: EN=1, 5V_SW up'], state: { boost: 1 }, test: { mode: 'V', a: 'pp1:5V_SW', b: 'pp1:GND', expect: [5.15, 5.25] }, focus: ['boost'], zoom: 60 });
add('A', 'Boost off — Gate A', '<code>boost off</code>: 5V_SW back to 0 V. <b>Gate A:</b> DK on battery, 5 V rail switches, idle current noted (≈ 20 mA from the cell).', { fw: ['uart:~$ boost off', 'boost: EN=0'], state: { boost: 0 }, focus: ['pp1', 'dk', 'chg'], view: 'iso' });

// ============================================================ Build B
add('B', 'Mount Perma-Proto #2', 'Fit two 6 mm standoffs to Perma-Proto #2 (the SPI backbone) and set it <b>behind the DK</b>. Rails: bottom outer <b>3V3</b>, bottom inner <b>GND</b>. The top rails stay unused.', { show: ['pp2', 'so_pp2'], parts: ['pp2'], focus: ['pp2'], view: 'top' });
add('B', '3V3 IN harness pin', 'Solder a header pin into the <b>bottom outer rail, column 26</b>.', { show: ['h_3v3'], solder: H('pp2', ['RB0', 26]), parts: ['h_3v3'], focus: ['h_3v3'], zoom: 35 });
add('B', 'GND IN harness pin', 'Solder a header pin into the <b>bottom inner rail, column 26</b>.', { show: ['h_gnd2'], solder: H('pp2', ['RB1', 26]), parts: ['h_gnd2'], focus: ['h_gnd2'], zoom: 35 });
add('B', 'Switch OFF', 'Toggle <b>OFF</b> before adding anything to the powered rails.', { state: { toggle: 0 }, focus: ['tog'], zoom: 50 });
add('B', 'DK VDD to 3V3 IN', 'Female/male jumper, red: male into the DK’s third <b>VDD</b> socket, female onto <b>3V3 IN</b>.', { show: ['j_3v3'], parts: ['jFM'], focus: ['j_3v3'], zoom: 120 });
add('B', 'DK GND to GND IN', 'Female/male jumper, black: male into the DK’s <b>GND</b> socket next to AREF, female onto <b>GND IN</b>.', { show: ['j_gnd2'], parts: ['jFM'], focus: ['j_gnd2'], zoom: 120 });
add('B', 'Mount the AS7341', 'Two 6 mm standoffs; set the <b>AS7341</b> behind the DK, right of the backbone.', { show: ['as7341', 'so_as7341'], parts: ['as7341'], focus: ['as7341'], zoom: 50 });
add('B', 'Mount the LSM6DSOX', 'Standoffs; <b>LSM6DSOX</b> next in the row.', { show: ['lsm6', 'so_lsm6'], parts: ['lsm6'], focus: ['lsm6'], zoom: 50 });
add('B', 'Mount the H3LIS331', 'Standoffs; <b>H3LIS331</b> next.', { show: ['h3lis', 'so_h3lis'], parts: ['h3lis'], focus: ['h3lis'], zoom: 50 });
add('B', 'Mount the BME688', 'Standoffs; <b>BME688</b> next.', { show: ['bme', 'so_bme'], parts: ['bme'], focus: ['bme'], zoom: 50 });
add('B', 'Mount the PCF8523', 'Standoffs; <b>PCF8523</b> at the end of the row.', { show: ['rtc', 'so_rtc'], parts: ['rtc'], focus: ['rtc'], zoom: 50 });
add('B', 'AS7341 power LED (optional)', 'Boards from 2023 on have a cuttable jumper for the green “on” LED on the back; cut it to save about 1 mA. Older boards don’t have it: skip this step.', { focus: ['as7341:D1'], zoom: 24 });
add('B', 'LSM6DSOX INT1 pin', 'Solder one header pin into the LSM6DSOX <b>I1</b> pad, long end up.', { show: ['h_i1'], parts: ['h_i1'], focus: ['h_i1'], zoom: 32 });
add('B', 'H3LIS331 INT pin', 'Solder one header pin into the H3LIS331 <b>INT</b> pad.', { show: ['h_int3'], parts: ['h_int3'], focus: ['h_int3'], zoom: 32 });
add('B', 'MAX17048 INT pin', 'Solder one header pin into the MAX17048 <b>INT</b> pad (the low-battery alert).', { show: ['h_alrt'], parts: ['h_alrt'], focus: ['h_alrt'], zoom: 32 });
add('B', 'Fit the CR1220', 'Slide the <b>CR1220</b> into the holder under the PCF8523, <b>+ side facing out</b> (away from the board).', { show: ['cr1220'], parts: ['cr1220'], focus: ['rtc'], view: 'under', zoom: 45 });
add('B', 'QT cable into the AS7341', 'Plug the JST end of the <b>STEMMA QT-to-male-header cable</b> into the AS7341’s left port until it clicks.', { show: ['qt_dk'], parts: ['qt_dk'], focus: ['as7341'], zoom: 60 });
add('B', 'Black to GND', 'Black male pin into the DK’s first <b>GND</b> socket (power header).', { show: ['qt_GND1'], focus: ['dk:GND1'], zoom: 70 });
add('B', 'Red to VDD', 'Red male pin into the DK’s first <b>VDD</b> socket.', { show: ['qt_VDD1'], focus: ['dk:VDD1'], zoom: 70 });
add('B', 'Blue to SDA', 'Blue male pin into <b>SDA</b> (top header, second from the left).', { show: ['qt_SDA'], focus: ['dk:SDA'], zoom: 70 });
add('B', 'Yellow to SCL', 'Yellow male pin into <b>SCL</b> (top header, far left).', { show: ['qt_SCL'], focus: ['dk:SCL'], zoom: 70 });
add('B', 'AS7341 → LSM6DSOX', '100 mm STEMMA QT cable between the AS7341’s right port and the LSM6DSOX’s left port.', { show: ['qt_1'], parts: ['qt100'], focus: ['qt_1'], zoom: 70 });
add('B', 'LSM6DSOX → H3LIS331', '100 mm cable.', { show: ['qt_2'], parts: ['qt100'], focus: ['qt_2'], zoom: 70 });
add('B', 'H3LIS331 → BME688', '200 mm cable.', { show: ['qt_3'], parts: ['qt200'], focus: ['qt_3'], zoom: 90 });
add('B', 'BME688 → PCF8523', '100 mm cable.', { show: ['qt_4'], parts: ['qt100'], focus: ['qt_4'], zoom: 70 });
add('B', 'PCF8523 → MAX17048', '200 mm cable to the gauge’s free STEMMA port. The bus is complete: six devices, about 1.7 kΩ of combined pull-up, 100 kHz.', { show: ['qt_5'], parts: ['qt200'], focus: ['qt_5'], zoom: 120 });
add('B', 'LSM6DSOX INT1 → D2', 'Two female/male extension jumpers pushed together (300 mm): female on the <b>I1</b> pin, male into DK <b>D2</b>.', { show: ['j_d2'], parts: ['jFM', 'jFM'], focus: ['j_d2'], zoom: 160 });
add('B', 'H3LIS331 INT → D3', 'Two chained extension jumpers: <b>INT → D3</b>.', { show: ['j_d3'], parts: ['jFM', 'jFM'], focus: ['j_d3'], zoom: 160 });
add('B', 'MAX17048 INT → A5', 'Two chained extension jumpers: <b>INT → A5</b>. The gauge pulls it low on a low-battery alert.', { show: ['j_a5'], parts: ['jFM', 'jFM'], focus: ['j_a5'], zoom: 180 });
add('B', 'Switch ON and scan', 'Toggle ON. In the shell: <code>i2c scan i2c@...</code>. Exactly six addresses answer.', { state: { toggle: 1 }, fw: ['uart:~$ i2c scan i2c1', '     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f', '10: -- -- -- -- -- -- -- -- 18 -- -- -- -- -- -- --', '30: -- -- -- -- -- -- 36 -- -- 39 -- -- -- -- -- --', '60: -- -- -- -- -- -- -- -- 68 -- 6a -- -- -- -- --', '70: -- -- -- -- -- -- -- 77', '6 devices found'], focus: ['as7341', 'lsm6', 'h3lis', 'bme', 'rtc'], view: 'iso' });
add('B', 'Measure the I2C idle level', 'DC volts: AS7341 <b>SDA</b> pad to GND reads the bus idle high, about 3.3 V.', { test: { mode: 'V', a: 'as7341:SDA', b: 'pp2:GND', expect: [3.2, 3.36] }, focus: ['as7341'], zoom: 50 });

add('B', 'Mount the Pi Zero 2 W', 'Four 6 mm standoffs; set the <b>Pi Zero 2 W</b> at the front right, GPIO edge toward the back.', { show: ['pi', 'so_pi'], parts: ['pi'], focus: ['pi'], zoom: 90 });
add('B', 'Insert the microSD', 'Flash <b>Raspberry Pi OS Lite (64-bit)</b> with Raspberry Pi Imager (hostname <code>chronodock</code>, Wi-Fi, SSH), then push the card into the slot, contacts down.', { show: ['sd'], parts: ['sd'], focus: ['pi'], zoom: 60 });
add('B', 'Mount Perma-Proto #3', 'Two 6 mm standoffs; set the <b>dock board</b> behind the Pi.', { show: ['pp3', 'so_pp3'], parts: ['pp3'], focus: ['pp3'], view: 'top' });
add('B', 'Dock connector half', 'Mark <b>pin 1</b> with a paint dot on both connector halves. Push the <b>spring-pin half</b> into <b>J13–J17</b>, pin 1 in J13, and solder the five tails.', { show: ['magDock'], solder: H('pp3', ['J', 13], ['J', 14], ['J', 15], ['J', 16], ['J', 17]), parts: ['magDock'], focus: ['magDock'], zoom: 45 });
add('B', 'Fit the fuse', 'Resettable fuse <b>RXEF110</b> into <b>C11 · C13</b>; solder and trim.', { show: ['fuse'], solder: H('pp3', ['C', 11], ['C', 13]), parts: ['fuse'], focus: ['fuse'], zoom: 45 });
add('B', 'Fused 5 V across the channel', 'Red 30 AWG: <b>E13 → F13</b>. Column 13 (top) is connector pin 1: the exposed 5 V pin is now behind the fuse.', { show: ['w_fuse_x'], parts: ['wire30r'], focus: ['w_fuse_x'], zoom: 40 });
add('B', '1 kΩ in the Pi TX line', '1 kΩ (brown-black-red) from <b>D16 → F16</b>, across the channel. Top column 16 is connector pin 4 (to the pod’s RX).', { show: ['rtx'], solder: H('pp3', ['D', 16], ['F', 16]), parts: ['rtx'], focus: ['rtx'], zoom: 40 });
add('B', '1 kΩ in the Pi RX line (new)', 'A second 1 kΩ from <b>D15 → F15</b>. Pin 3 carries the pod’s TX; the resistor stops a powered pod from back-feeding an unpowered Pi through its RX pin.', { show: ['rrx'], solder: H('pp3', ['D', 15], ['F', 15]), parts: ['rrx'], focus: ['rrx'], zoom: 40 });
add('B', 'Pi 5 V to the fuse', 'Red 30 AWG soldered into Pi <b>pin 2</b> (5 V) → <b>A11</b>.', { show: ['w_pi5v'], parts: ['wire30r'], focus: ['w_pi5v'], zoom: 70 });
add('B', 'Pi GND to pin 2', 'Black 30 AWG: Pi <b>pin 6</b> (GND) → <b>H14</b> (connector pin 2).', { show: ['w_pigd'], parts: ['wire30b'], focus: ['w_pigd'], zoom: 70 });
add('B', 'Pi TXD', 'Black 30 AWG: Pi <b>pin 8</b> (GPIO14 TXD) → <b>A16</b>.', { show: ['w_pitx'], parts: ['wire30b'], focus: ['w_pitx'], zoom: 70 });
add('B', 'Pi RXD', 'Black 30 AWG: Pi <b>pin 10</b> (GPIO15 RXD) → <b>A15</b>.', { show: ['w_pirx'], parts: ['wire30b'], focus: ['w_pirx'], zoom: 70 });
add('B', 'Dock-detect strap', 'Black 30 AWG: <b>H17 → I14</b>. Connector pin 5 is tied to GND, so the pod sees A0 go low when docked.', { show: ['w_detect'], parts: ['wire30b'], focus: ['w_detect'], zoom: 40 });
add('B', 'Check the dock board', 'Continuity: connector <b>pin 5 to pin 2</b> beeps; <b>pin 1 to pin 2</b> does not.', { test: { mode: 'ohm', a: 'magDock:P1', b: 'magDock:P2', expect: 'OL' }, focus: ['magDock'], zoom: 40 });
add('B', 'Power the Pi', 'Plug the <b>5.1 V 2.5 A</b> supply into <b>PWR IN</b>. Then: <code>raspi-config</code> → Serial: login shell No, hardware Yes; add <code>dtoverlay=disable-bt</code>; disable <code>hciuart</code>; reboot.', { show: ['usb_pi'], state: { pi: 1 }, parts: ['usb_pi'], fw: ['pi@chronodock:~ $ ls -l /dev/serial0', 'lrwxrwxrwx 1 root root 7 /dev/serial0 -> ttyAMA0'], focus: ['pi'], zoom: 110 });
add('B', 'Check dock 5 V', 'DC volts: connector <b>pin 1 to pin 2</b> reads about <b>4.9–5.1 V</b> (supply minus the fuse).', { test: { mode: 'V', a: 'magDock:P1', b: 'magDock:P2', expect: [4.85, 5.12] }, focus: ['magDock'], zoom: 45 });
add('B', 'Pod connector half', 'Take the <b>flat-pad half</b>; paint-dot pin 1. It will sit in the pod’s base. Place it face up on the bench for wiring.', { show: ['magPod'], parts: ['magPod'], focus: ['magPod'], zoom: 40 });
add('B', 'Pod pin 1 → charger VBUS', 'Red 30 AWG: pod <b>pin 1 → bq24074 VBUS</b> pad.', { show: ['w_m1'], parts: ['wire30r'], focus: ['w_m1'], zoom: 110 });
add('B', 'Pod pin 2 → charger GND', 'Black 30 AWG: pod <b>pin 2 → bq24074 GND</b> (end pad).', { show: ['w_m2'], parts: ['wire30b'], focus: ['w_m2'], zoom: 110 });
add('B', 'Pod pin 3 → D1 (TX)', '30 AWG from pod <b>pin 3</b>, spliced and heat-shrunk to the male half of a cut jumper, into DK <b>D1</b>.', { show: ['w_m3'], parts: ['wire30b', 'jFM'], focus: ['w_m3'], view: 'iso' });
add('B', 'Pod pin 4 → D0 (RX)', 'Same for pod <b>pin 4 → D0</b>.', { show: ['w_m4'], parts: ['wire30b', 'jFM'], focus: ['w_m4'], view: 'iso' });
add('B', 'Pod pin 5 → A0 (detect)', 'Same for pod <b>pin 5 → A0</b>.', { show: ['w_m5'], parts: ['wire30b', 'jFM'], focus: ['w_m5'], view: 'iso' });
add('B', 'Gate B: dock it', 'Set the pod half onto the dock half (pin 1 to pin 1; reversed, the magnets repel). The charger’s CHG LED lights, A0 reads low and <code>HELLO</code> reaches the Pi.', { state: { docked: 1 }, fw: ['dock: A0=0 → docked', 'TX HELLO v0.1', 'pi: RX HELLO v0.1 → ACK'], focus: ['magDock', 'chg'], zoom: 120 });
add('B', 'Undock', 'Lift the pod half off. The CHG LED goes out; A0 returns high.', { state: { docked: 0 }, focus: ['magDock'], zoom: 90 });

// ============================================================ Build C
add('C', 'Switch OFF', 'Toggle OFF before working on the SPI backbone.', { state: { toggle: 0 }, focus: ['tog'], zoom: 50 });
add('C', 'CORE board: terminal blocks', 'Solder the two blue <b>3.5 mm terminal blocks</b> onto the first MAX31865, openings facing out. Label it <b>CORE</b>. Leave the wire-mode jumpers as shipped (4-wire).', { show: ['core'], parts: ['core'], focus: ['core'], zoom: 50 });
add('C', 'CORE board: header', '8-pin header, long pins down. Push it into <b>E2–E9</b> (VIN, GND, 3V3, CLK, SDO, SDI, CS, RDY) and solder underneath.', { show: ['hdr_core'], solder: H('pp2', ['E', 2], ['E', 3], ['E', 4], ['E', 5], ['E', 6], ['E', 7], ['E', 8], ['E', 9]), parts: ['hdr_core'], focus: ['core'], zoom: 60 });
add('C', 'AMB board: terminal blocks', 'Same for the second MAX31865; label it <b>AMB</b>.', { show: ['amb'], parts: ['amb'], focus: ['amb'], zoom: 50 });
add('C', 'AMB board: header', 'Header into <b>E13–E20</b>; solder.', { show: ['hdr_amb'], solder: H('pp2', ['E', 13], ['E', 14], ['E', 15], ['E', 16], ['E', 17], ['E', 18], ['E', 19], ['E', 20]), parts: ['hdr_amb'], focus: ['amb'], zoom: 60 });
add('C', 'CORE VIN to 3V3', 'Red 30 AWG: <b>A2 → bottom outer rail</b> (3V3).', { show: ['w_core_vin'], parts: ['wire30r'], focus: ['w_core_vin'], zoom: 40 });
add('C', 'CORE GND', 'Black 30 AWG: <b>A3 → bottom inner rail</b>.', { show: ['w_core_gnd'], parts: ['wire30b'], focus: ['w_core_gnd'], zoom: 40 });
add('C', 'AMB VIN to 3V3', 'Red: <b>A13 → bottom outer rail</b>.', { show: ['w_amb_vin'], parts: ['wire30r'], focus: ['w_amb_vin'], zoom: 40 });
add('C', 'AMB GND', 'Black: <b>A14 → bottom inner rail</b>.', { show: ['w_amb_gnd'], parts: ['wire30b'], focus: ['w_amb_gnd'], zoom: 40 });
add('C', 'Share SCK', '30 AWG: <b>B5 → B16</b> (CORE CLK to AMB CLK).', { show: ['w_bus_sck'], parts: ['wire30b'], focus: ['w_bus_sck'], zoom: 55 });
add('C', 'Share MISO', '30 AWG: <b>B6 → B17</b> (SDO to SDO).', { show: ['w_bus_miso'], parts: ['wire30b'], focus: ['w_bus_miso'], zoom: 55 });
add('C', 'Share MOSI', '30 AWG: <b>B7 → B18</b> (SDI to SDI).', { show: ['w_bus_mosi'], parts: ['wire30b'], focus: ['w_bus_mosi'], zoom: 55 });
for (const [id, hole, lab] of [['h_sck', ['D', 5], 'SCK'], ['h_miso', ['D', 6], 'MISO'], ['h_mosi', ['D', 7], 'MOSI'], ['h_cs10', ['D', 8], 'CORE CS'], ['h_cs9', ['D', 19], 'AMB CS']])
  add('C', `${lab} harness pin`, `Solder a header pin into <b>${hole.join('')}</b> (the ${lab} strip).`, { show: [id], solder: H('pp2', hole), parts: [id], focus: [id], zoom: 35 });
for (const [id, dk, lab, col] of [['j_sck', 'D13', 'SCK', 'blue'], ['j_miso', 'D12', 'MISO', 'green'], ['j_mosi', 'D11', 'MOSI', 'yellow'], ['j_cs10', 'D10', 'CORE CS', 'orange'], ['j_cs9', 'D9', 'AMB CS', 'brown']])
  add('C', `${dk} → ${lab}`, `Female/male jumper, ${col}: male into DK <b>${dk}</b>, female onto the <b>${lab}</b> pin.`, { show: [id], parts: ['jFM'], focus: [id], zoom: 110 });
add('C', 'Core probe: lead A', 'PT1000 element: solder <b>two red</b> 30 AWG wires (250 mm) to one lead, under 3 s per joint.', { show: ['ptcore', 'core_fp', 'core_rp'], parts: ['ptcore', 'wire30r'], focus: ['ptcore'], zoom: 30 });
add('C', 'Core probe: lead B', 'Two <b>white</b> wires to the other lead.', { show: ['core_rn', 'core_fn'], parts: ['wire30w'], focus: ['ptcore'], zoom: 30 });
add('C', 'Core probe: insulate', 'Kapton tape between and around the two joints.', { show: ['kap_core'], parts: ['kapton'], focus: ['ptcore'], zoom: 30 });
add('C', 'Core probe: check', 'Ohms between a red and a white wire: about <b>1,085 Ω at 22 °C</b>.', { test: { mode: 'ohm', a: 'core:F+', b: 'core:F-', expect: [1070, 1100] }, focus: ['ptcore'], zoom: 40 });
for (const [pin, w, col] of [['F+', 'core_fp', 'red #1'], ['RTD+', 'core_rp', 'red #2'], ['RTD-', 'core_rn', 'white #1'], ['F-', 'core_fn', 'white #2']])
  add('C', `CORE ${pin}`, `Strip 5 mm, push the <b>${col}</b> wire into the CORE block’s <b>${pin}</b> opening and tighten the screw.`, { focus: [w + ':end'], zoom: 40, clamp: w });
add('C', 'Ambient probe: lead A', 'Second element: <b>two blue</b> wires (150 mm) to one lead.', { show: ['ptamb', 'amb_fp', 'amb_rp'], parts: ['ptamb'], focus: ['ptamb'], zoom: 30 });
add('C', 'Ambient probe: lead B', 'Two <b>white</b> wires to the other lead.', { show: ['amb_rn', 'amb_fn'], focus: ['ptamb'], zoom: 30 });
add('C', 'Ambient probe: insulate', 'Kapton over the joints.', { show: ['kap_amb'], focus: ['ptamb'], zoom: 30 });
for (const [pin, w, col] of [['F+', 'amb_fp', 'blue #1'], ['RTD+', 'amb_rp', 'blue #2'], ['RTD-', 'amb_rn', 'white #1'], ['F-', 'amb_fn', 'white #2']])
  add('C', `AMB ${pin}`, `<b>${col}</b> into the AMB block’s <b>${pin}</b>; tighten.`, { focus: [w + ':end'], zoom: 40, clamp: w });
add('C', 'Mount the NFC module', 'Two 6 mm standoffs; set the <b>ST25R3916B module</b> left of the backbone, antenna up.', { show: ['nfc', 'so_nfc'], parts: ['nfc'], focus: ['nfc'], zoom: 70 });
add('C', 'NFC IRQ → D6', 'Plug the <b>PicoBlade 7-pin pigtail</b> into the module (pin 1 = IRQ). Splice wire 1 to the male half of a cut jumper; heat-shrink; male into DK <b>D6</b>.', { show: ['n_irq'], parts: ['pico', 'jFM'], focus: ['n_irq'], view: 'iso' });
add('C', 'NFC CS → D7', 'Wire 2 (CS): splice to a jumper half; into DK <b>D7</b>.', { show: ['n_cs'], focus: ['n_cs'], view: 'iso' });
add('C', 'NFC SCLK → SCK strip', 'Wire 3 (SCLK): splice to 30 AWG; solder into backbone <b>C5</b>.', { show: ['n_sck'], solder: H('pp2', ['C', 5]), focus: ['n_sck'], zoom: 90 });
add('C', 'NFC MOSI → MOSI strip', 'Wire 4 (MOSI) → <b>C7</b>.', { show: ['n_mosi'], solder: H('pp2', ['C', 7]), focus: ['n_mosi'], zoom: 90 });
add('C', 'NFC MISO → MISO strip', 'Wire 5 (MISO) → <b>C6</b>.', { show: ['n_miso'], solder: H('pp2', ['C', 6]), focus: ['n_miso'], zoom: 90 });
add('C', 'NFC 5 V → 5V_SW', 'Wire 6 (5 V) → PP1 <b>bottom outer rail, column 2</b> (5V_SW).', { show: ['n_5v'], focus: ['n_5v'], view: 'iso' });
add('C', 'NFC GND', 'Wire 7 (GND) → PP1 <b>bottom inner rail, column 3</b>.', { show: ['n_gnd'], focus: ['n_gnd'], view: 'iso' });
add('C', 'NFC power rule', 'Firmware keeps 5V_SW on whenever the pod is on and parks the reader in power-down (≈10 µA) between reads. Before ever switching the boost off it drives D7, D11 and D13 low. <b>Unplug the PicoBlade plug whenever the DK runs from USB.</b>', { focus: ['nfc'], zoom: 70, fw: ['nfc: boost on, wait 10 ms', 'rfal: ST25R3916B id OK, power-down'] });
add('C', 'Reed switch', 'Bend each lead <b>beyond pliers held next to the glass</b>; never bend at the seal. Slide heat-shrink over the whole switch afterwards.', { show: ['reed'], parts: ['reed'], focus: ['reed'], zoom: 30 });
add('C', 'Reed → D4', '30 AWG from one lead, spliced to a jumper half, into DK <b>D4</b>.', { show: ['w_reed1'], focus: ['w_reed1'], view: 'iso' });
add('C', 'Reed → GND', '30 AWG from the other lead → backbone <b>bottom inner rail, column 28</b>.', { show: ['w_reed2'], focus: ['w_reed2'], view: 'iso' });
for (const [i, c, col] of [[1, 3, 'red'], [2, 6, 'green'], [3, 15, 'blue'], [4, 27, 'white']]) {
  add('C', `Driver Q${i} (${col})`, `PN2222 into <b>I${c - 1} · I${c} · I${c + 1}</b>, flat face toward you: E, B, C. Solder and trim.`, { show: ['q' + i], solder: H('pp1', ['I', c - 1], ['I', c], ['I', c + 1]), parts: ['q' + i], focus: ['q' + i], zoom: 40 });
  add('C', `Base resistor Q${i}`, `1 kΩ (brown-black-red) from <b>G${c}</b> (base strip) across the channel to <b>E${c}</b>. Solder and trim.`, { show: ['rb' + i], solder: H('pp1', ['G', c], ['E', c]), parts: ['rb' + i], focus: ['rb' + i], zoom: 40 });
  add('C', `Emitter Q${i} to GND`, `Black 30 AWG: <b>J${c - 1} → top outer rail</b> (GND).`, { show: ['w_e' + i], parts: ['wire30b'], focus: ['w_e' + i], zoom: 35 });
  add('C', `A${i} harness pin`, `Header pin into <b>B${c}</b>.`, { show: ['h_a' + i], solder: H('pp1', ['B', c]), parts: ['h_a' + i], focus: ['h_a' + i], zoom: 35 });
  add('C', `A${i} jumper`, `Female/male jumper, ${col}: female on the <b>B${c}</b> pin, male into DK <b>A${i}</b>.`, { show: ['j_a' + i], parts: ['jFM'], focus: ['j_a' + i], zoom: 110 });
}
add('C', 'RGB LED', 'Set the <b>RGB LED</b> (common anode) in its stand. Legs: R, anode (longest), G, B.', { show: ['rgb'], parts: ['rgb'], focus: ['rgb'], zoom: 40 });
add('C', 'RGB anode to 5V_SW', 'Red 30 AWG from the <b>anode</b> → PP1 <b>bottom outer rail, column 30</b>.', { show: ['w_rgb_a'], focus: ['w_rgb_a'], zoom: 90 });
add('C', 'Red leg', 'Solder a <b>220 Ω</b> (red-red-brown) to the R leg; heat-shrink it; 30 AWG on to <b>J4</b> (Q1 collector).', { show: ['w_rgb_r'], parts: ['r220'], focus: ['w_rgb_r'], zoom: 90 });
add('C', 'Green leg', '220 Ω on G; wire to <b>J7</b> (Q2 collector).', { show: ['w_rgb_g'], parts: ['r220'], focus: ['w_rgb_g'], zoom: 90 });
add('C', 'Blue leg', '220 Ω on B; wire to <b>J16</b> (Q3 collector).', { show: ['w_rgb_b'], parts: ['r220'], focus: ['w_rgb_b'], zoom: 90 });
add('C', 'White LED', 'Set the <b>3 mm white LED</b> in its stand; long leg is the anode.', { show: ['wled'], parts: ['wled'], focus: ['wled'], zoom: 40 });
add('C', 'White LED resistor', '220 Ω from the <b>bottom outer rail, column 28</b> (5V_SW) to <b>C28</b>. Solder and trim.', { show: ['rw'], solder: H('pp1', ['RB0', 28], ['C', 28]), parts: ['rw'], focus: ['rw'], zoom: 40 });
add('C', 'White anode', 'Red 30 AWG from the <b>anode</b> → <b>A28</b>.', { show: ['w_wl_a'], focus: ['w_wl_a'], zoom: 90 });
add('C', 'White cathode', 'Black 30 AWG from the <b>cathode</b> → <b>J28</b> (Q4 collector).', { show: ['w_wl_k'], focus: ['w_wl_k'], zoom: 90 });
add('C', 'Switch ON', 'Toggle ON; the app boots.', { state: { toggle: 1 }, focus: ['tog'], zoom: 50 });
add('C', 'Light test', '<code>boost on</code>, then <code>led red on</code> … <code>led white on</code>. White LED current ≈ 8 mA: meter across its 220 Ω reads ≈ 1.8 V.', { fw: ['uart:~$ boost on', 'uart:~$ led white on'], state: { boost: 1, led: 'w' }, test: { mode: 'V', a: 'pp1:RB0_28', b: 'pp1:C28', expect: [1.6, 2.0] }, focus: ['rw', 'wled'], zoom: 80 });
add('C', 'Gate C', '<b>Gate C:</b> ice bath 0.0 ± 0.3 °C on both channels; NFC reads 20/20 at 10 mm; magnet on the reed pulls D4 low; every light works. Open the <b>Simulate</b> tab to run the whole system.', { state: { led: '' }, focus: [], view: 'iso' });

export const STEPS = s;
