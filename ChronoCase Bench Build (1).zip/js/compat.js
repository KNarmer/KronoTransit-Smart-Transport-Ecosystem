// Per-component compatibility check (datasheet / product-guide values) and the power budget.
export const NEWPARTS = [
  { id: 'A18', name: 'Adafruit #826 Female/Male extension jumpers, 40 × 150 mm', price: 3.95, why: 'The DK’s Arduino headers are female sockets, so the female/female jumpers (A14) can’t plug into them. 22 of the DK connections need a male end; the long runs (D2, D3, A5) use two of these chained.' },
  { id: 'C11', name: 'Molex PicoBlade 15134-0700, 7-circuit, 50 mm (Mouser)', price: 5.83, why: 'The ST25R3916B module’s connector is an MX1.25 / PicoBlade 7-pin socket, with no solder pads. Cut the cable in half and splice each wire to 30 AWG.' },
];
export const COMPAT = [
  { id: 'A1', part: 'nRF5340 DK', supply: 'P21 external 1.7–3.6 V; VDD 3.0 V on USB', link: 'P21 ← MCP1700 3.30 V; SW9 = VDD, SW10 = OFF', v: 'fix', note: 'Arduino headers are female sockets: male-ended jumpers needed (A18). One source at a time: P21 is isolated while USB is plugged in.' },
  { id: 'A3', part: 'LiPo 2,500 mAh', supply: '3.0–4.2 V, PCM-protected', link: 'JST-PH → MAX17048 → bq24074 BAT', v: 'ok', note: '0.5 A charge = 0.2 C.' },
  { id: 'A4', part: 'MAX17048', supply: 'Runs from the cell; VIN 3–5 V for logic only', link: 'Inline in the battery lead; I2C 0x36; INT → A5', v: 'ok', note: 'INT pulled up to VIN (3.3 V) by 10 kΩ: safe for the nRF. Set the alert at 3.50 V so firmware sleeps before the LDO drops out.' },
  { id: 'A6', part: 'bq24074', supply: 'Input 5–10 V (DPM ≈ 4.5 V); OUT ≤ 4.4 V', link: 'VBUS ← dock pin 1 (≈ 4.96 V); OUT → switch → VSYS', v: 'fix', note: 'Ships at 1.0 A through a trace: <b>cut the 1.0A trace first</b>, then bridge 0.5A. Bridging alone leaves it at 1.0 A or more.' },
  { id: 'A7', part: 'Mini SPDT toggle', supply: 'Carries ≤ 0.6 A', link: 'COM ← OUT, L1 → VSYS', v: 'ok', note: 'Doubled 30 AWG on both sides.' },
  { id: 'A8', part: 'MCP1700-3302E', supply: 'VIN 2.3–6 V, 250 mA, dropout ≈ 60 mV at our load', link: 'VSYS → 3.30 V → P21', v: 'ok', note: 'Regulates down to a 3.36 V cell. Peak 3.3 V load ≈ 40 mA (16 % of rating). 1 µF in and out meets the datasheet.' },
  { id: 'A10', part: 'MiniBoost TPS61023', supply: 'In 0.5–5.5 V (starts at 1.8 V); out 5.2 V; ≈1.1 A at 3.5 V in', link: 'VIN ← VSYS, EN ← D5, 5V → 5V_SW rail', v: 'fix', note: 'Output is <b>5.2 V</b>, not 5.0 V; LED currents below use 5.2 V. True output disconnect when EN is low. Keep it on while the pod runs (NFC rule).' },
  { id: 'B1', part: 'AS7341', supply: 'VIN 3–5 V, regulated + level-shifted', link: 'STEMMA QT, 0x39', v: 'ok', note: 'Keep the chip’s own LED driver off; the pod uses the separate white LED.' },
  { id: 'B2', part: 'BME688', supply: 'VIN 3–5 V', link: 'STEMMA QT, 0x77', v: 'ok', note: 'Gas heater draws ≈ 12 mA during a scan, in the budget.' },
  { id: 'B3', part: 'LSM6DSOX', supply: 'VIN 3–5 V; I1 level-shifted', link: 'STEMMA QT, 0x6A; I1 → D2', v: 'ok', note: 'Configure INT1 active-high, push-pull.' },
  { id: 'B4', part: 'H3LIS331', supply: 'VIN 3–5 V; all pins level-shifted', link: 'STEMMA QT, 0x18 (SDO open); INT → D3', v: 'ok', note: 'Leave SDO unconnected (0x18).' },
  { id: 'B5', part: 'PCF8523 + CR1220', supply: 'VIN 3–5 V', link: 'STEMMA QT, 0x68', v: 'ok', note: 'Only one device per address: no clashes across the six.' },
  { id: 'B9', part: 'QT-to-male-header cable', supply: '—', link: 'Male pins into DK VDD, GND, SDA, SCL sockets', v: 'ok', note: 'Male pins mate the DK’s female sockets directly.' },
  { id: 'B10', part: 'Pi Zero 2 W', supply: '5.1 V 2.5 A supply; GPIO 3.3 V', link: 'Pins 2, 6, 8, 10 → dock board', v: 'fix', note: 'Add <b>1 kΩ in the pod-TX → Pi-RX line</b> (pin 3) so a powered pod can’t back-feed an unpowered Pi.' },
  { id: 'B13', part: 'RXEF110 fuse', supply: '1.1 A hold, 2.2 A trip', link: 'Pi 5 V → dock pin 1', v: 'ok', note: 'Charging + system ≈ 0.6 A, inside the hold current.' },
  { id: 'B14', part: 'Magnetic 5-pin connector', supply: 'Current rating not published', link: 'Pins 1 VBUS, 2 GND, 3 TX, 4 RX, 5 detect', v: 'ok', note: 'Expected ≤ 0.6 A. Check pin temperature with a finger on the first full charge.' },
  { id: 'C1', part: 'MAX31865 ×2', supply: 'VIN 3–5 V, 3.3 V regulator; inputs level-shifted', link: 'SPI mode 1, 4 MHz; CS D10 / D9', v: 'ok', note: 'Shipped jumpers = 4-wire. Calibrate on battery: VDD is 3.0 V on USB.' },
  { id: 'C2', part: 'PT1000 PTFM102T1A0', supply: '≈1,085 Ω at 22 °C', link: '4-wire: two wires per lead', v: 'ok', note: 'Rref 4,300 Ω on the Adafruit board suits PT1000.' },
  { id: 'C3', part: 'ST25R3916B module', supply: '5 V in (onboard 3.3 V regulator); 3.3 V SPI; 10 µA PD · 5.2 mA idle · 24 mA polling · 72 mA RF', link: 'MX1.25 7-pin: IRQ, CS, SCLK, MOSI, MISO, 5V, GND', v: 'new', note: 'Needs the PicoBlade cable (C11). Unpowered, it is back-fed through shared SPI lines: keep 5V_SW on and use power-down between reads; drive D7, D11, D13 low before the boost goes off; unplug it when the DK runs on USB.' },
  { id: 'C4', part: 'Reed switch MDSR-7', supply: 'Dry contact', link: 'D4 (internal pull-up) to GND', v: 'ok', note: 'Closes with the N52 disc within ≈ 10 mm.' },
  { id: 'C5–C9', part: 'LEDs, PN2222, 220 Ω, 1 kΩ', supply: '5V_SW 5.2 V; bases from 3.3 V GPIO', link: 'A1–A4 → 1 kΩ → bases; collectors sink the LEDs', v: 'ok', note: 'Red 13.6 mA, green 7.6, blue 7.4, white 8.2 mA. Base 2.6 mA: set A1–A4 to high drive.' },
];
export const POWER = [
  { rail: '3V3 (MCP1700)', load: '≈ 40 mA', limit: '250 mA', margin: '6×' },
  { rail: '5V_SW (MiniBoost)', load: '≈ 110 mA (NFC RF + red + white)', limit: '≈ 1.1 A', margin: '10×' },
  { rail: 'Battery, worst case', load: '≈ 0.20 A', limit: 'PCM ≈ 2 A', margin: '10×' },
  { rail: 'Dock charging (VBUS)', load: '≈ 0.55 A', limit: 'fuse hold 1.1 A', margin: '2×' },
  { rail: 'I2C bus', load: '≈ 180 pF, 1.7 kΩ pull-ups', limit: '400 pF at 100 kHz', margin: 'rise ≈ 0.3 µs' },
];
