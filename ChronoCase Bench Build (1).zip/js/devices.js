// Whole devices: nRF5340 DK, Adafruit breakouts, Perma-Proto, Pi Zero 2 W, NFC module, battery, switch, magnetic connector.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import {
  M, box, cyl, rbox, canvasTex, labelTex, loadTex, addPin, makePCB, populateBoard, PCB_T,
  maleHeader, femaleSocket, colorMat, solderFillet, coinCell, picoBladePlug
} from './models.js';

const P2 = 2.54;

// --------------------------------------------------------------------------- Adafruit breakouts
// Silkscreen pin labels per header (left to right in board coordinates) so wires can refer to them.
export const HEADER_LABELS = {
  lsm6dsox: { JP1: ['VIN', '3Vo', 'GND', 'SCL', 'SDA', 'DO', 'CS', 'I1', 'I2'], JP2: ['GND', 'DO2', 'CS2', 'SDX', 'SCX'] },
  h3lis331: { JP3: ['VIN', '3Vo', 'GND', 'SCL', 'SDA', 'INT'], JP2: ['CS', 'SDO', 'X3', 'X4', 'X5', 'I2'] },
  pcf8523: { JP2: ['SQW', 'SDA', 'SCL', 'GND', 'VIN'] },
  max31865: { JP1: ['VIN', 'GND', '3V3', 'CLK', 'SDO', 'SDI', 'CS', 'RDY'], X1: ['RTD+', 'F+'], X2: ['F-', 'RTD-'] },
  as7341: { JP1: ['VIN', 'GND', 'SCL', 'SDA', 'GPIO', 'INT'] },
  bme688: { JP1: ['VIN', '3Vo', 'GND', 'SCK', 'SDO', 'SDI', 'CS'] },
  max17048: { JP1: ['VIN', 'GND', 'SCL', 'SDA', 'INT', 'QST'], JP2: ['VBAT', 'BGND'] },
  miniboost: { JP1: ['EN', '5V', 'GND', 'VIN'] },
  bq24074: { JP3: ['GND3', 'LIPO', 'GND2', 'OUT', 'CHG', 'PGOOD', 'CE', 'ISET', 'THERM', 'GND', 'VBUS'], JP1: ['D+', 'D-'], JP2: ['GNDp'], JP4: ['VBUSp'] },
};

export function makeAdafruit(name, spec) {
  const tex = loadTex(spec.tex);
  // mounting pads (drill >= 2 mm) keep a gold ring on both sides
  const sp = { ...spec, th: spec.th.map(h => ({ ...h })) };
  const board = makePCB(sp, { tex });
  populateBoard(board, sp);
  const t = board.userData.top;
  const labels = HEADER_LABELS[name] || {};
  for (const h of spec.th) {
    if (h.drill >= 2) continue;
    const L = labels[h.el];
    let lab = L ? L[(parseInt(h.pad, 10) || 1) - 1] : null;
    const key = lab || `${h.el}.${h.pad}`;
    if (name === 'max31865' && (h.el === 'X1' || h.el === 'X2')) { addPin(board, key, h.x, t + 1.6, -(h.y + 3.9), 'term', [0, 0, -1], { net: h.net }); continue; }
    addPin(board, key, h.x, t, -h.y, 'hole', [0, 1, 0], { net: h.net, drill: h.drill });
  }
  // STEMMA QT port anchors (left = CONN4 at low x, right = CONN3 at high x)
  for (const [n, m] of Object.entries(board.userData.parts)) {
    const b = m.userData.body;
    if (b.type !== 'stemma') continue;
    const dir = new THREE.Vector3(Math.cos(b.rot * Math.PI / 180), 0, -Math.sin(b.rot * Math.PI / 180));
    const mouth = new THREE.Vector3(b.cx, t + 1.5, -b.cy).addScaledVector(dir, 2.1);
    const side = b.cx < (spec.bbox[0] + spec.bbox[2]) / 2 ? 'QT_L' : 'QT_R';
    addPin(board, side, mouth.x, mouth.y, mouth.z, 'qt', [dir.x, 0, dir.z]);
  }
  for (const [n, m] of Object.entries(board.userData.parts)) {
    const b = m.userData.body;
    if (b.type !== 'jstph') continue;
    const dir = new THREE.Vector3(1, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), m.rotation.y);
    const mouth = m.position.clone().add(new THREE.Vector3(0, 2.2, 0)).addScaledVector(dir, 3.8);
    addPin(board, 'JST_' + n, mouth.x, mouth.y, mouth.z, 'jstph', [dir.x, 0, dir.z]);
  }
  if (name === 'pcf8523') {
    // CR1220 holder on the back
    const hold = new THREE.Group();
    hold.add(cyl(7.4, 3.6, M.black, 40, 0, -3.6));
    hold.add(box(8, 0.3, 14, M.tin, 0, -3.9, 0));
    const cell = coinCell(6.1, 2.0); cell.rotation.x = Math.PI; cell.position.y = -0.6; cell.visible = false; cell.name = 'coin';
    hold.add(cell);
    hold.position.set(12.7, 0, -9.5); board.add(hold); board.userData.coin = cell;
  }
  board.userData.kind = name;
  return board;
}

// --------------------------------------------------------------------------- Perma-Proto half
export function makePermaProto(spec, id) {
  const tex = loadTex(spec.tex);
  const board = makePCB(spec, { tex, botColor: '#f1f1ec' });
  const t = board.userData.top;
  const rows = { RT0: 21.59, RT1: 19.05, J: 13.97, I: 11.43, H: 8.89, G: 6.35, F: 3.81, E: -3.81, D: -6.35, C: -8.89, B: -11.43, A: -13.97, RB1: -19.05, RB0: -21.59 };
  board.userData.hole = (row, col) => new THREE.Vector3(-36.83 + (col - 1) * P2, t, -rows[row]);
  board.userData.rows = rows;
  board.userData.kind = 'permaproto'; board.name = id;
  return board;
}

// --------------------------------------------------------------------------- nRF5340 DK
// Photo-derived coordinates (mm from the board's top-left, y down); converted to y-up below.
const DKH = 63.6;
const dk = (x, yd) => [x, DKH - yd];
export const DK_PINS = (() => {
  const p = {};
  const g1 = ['SCL', 'SDA', 'AREF', 'GND_T', 'D13', 'D12', 'D11', 'D10', 'D9', 'D8'];
  g1.forEach((n, i) => p[n] = dk(18.59 + i * P2, 6.34));
  ['D7', 'D6', 'D5', 'D4', 'D3', 'D2', 'D1', 'D0'].forEach((n, i) => p[n] = dk(45.74 + i * P2, 6.34));
  ['P0.10', 'P0.09', 'P0.08', 'P0.07b', 'P0.06b', 'P0.05b', 'P0.04b', 'P0.01'].forEach((n, i) => p['X_' + n] = dk(68.56 + i * P2, 6.34));
  ['VDD1', 'VDD2', 'RESET', 'VDD3', '5V', 'GND1', 'GND2', 'NC'].forEach((n, i) => p[n] = dk(27.98 + i * P2, 55.46));
  ['A0', 'A1', 'A2', 'A3', 'A4', 'A5'].forEach((n, i) => p[n] = dk(51.13 + i * P2, 55.46));
  return p;
})();
export function makeDK() {
  const outline = [[0.6, 0], [133.4, 0], [133.4, 7.5], [136.0, 10.0], [136.0, 42.8], [133.1, 45.7], [133.1, 63.0], [132.5, 63.6], [0.6, 63.6], [0, 63.0], [0, 0.6]];
  const holesD = [[15.06, 7.6], [89.89, 7.46], [127.5, 17.09], [65.87, 22.81], [66.08, 50.94], [13.82, 56.03], [96.57, 56.03]];
  const spec = { name: 'nrf5340dk', bbox: [0, 0, 136, 63.6], outline, holes: holesD.map(([x, y]) => ({ x, y: DKH - y, d: 3.2 })), th: [], mask: '#1e4fa3' };
  const board = makePCB(spec, { tex: loadTex('assets/dk_top.jpg'), botColor: '#1d4a99' });
  const t = board.userData.top;
  const at = (x, yd) => new THREE.Vector3(x, t, -(DKH - yd));
  // Arduino-style female sockets
  const sock = (n, x, yd, rows = 1) => { const s = femaleSocket(n, { rows }); s.position.copy(at(x, yd)); board.add(s); return s; };
  sock(10, 18.59, 6.34); sock(8, 45.74, 6.34); sock(8, 68.56, 6.34);
  sock(8, 27.98, 55.46); sock(6, 51.13, 55.46);
  const p24 = femaleSocket(12, { rows: 2 }); p24.rotation.y = -Math.PI / 2; p24.position.copy(at(94.76, 10.1)); board.add(p24);
  for (const [n, [x, y]] of Object.entries(DK_PINS)) addPin(board, n, x, t + 8.5, -y, 'socket', [0, 1, 0]);
  // micro-USB receptacles (nRF USB on the top edge, interface USB on the left edge)
  const usb = (x, yd, rotY) => {
    const g = new THREE.Group();
    const s = rbox(7.5, 2.8, 5.4, 0.9, M.steel); g.add(s);
    g.add(box(0.3, 1.7, 5.6, colorMat(0x0a0a0a), 0, 0.5, 0)); g.children.at(-1).position.set(3.7, 0.55, 0);
    g.children.at(-1).rotation.y = Math.PI / 2; g.children.at(-1).scale.set(1, 1, 0.12);
    const mouth = box(0.2, 1.6, 6.0, colorMat(0x050505), 0, 0.6, 0); mouth.rotation.y = Math.PI / 2; mouth.position.set(0, 0.6, -2.75); g.add(mouth);
    g.add(box(4.0, 0.5, 0.4, M.black, 0, 1.1, -2.6));
    g.position.copy(at(x, yd)); g.rotation.y = rotY; board.add(g); return g;
  };
  usb(108.6, 2.2, 0);
  usb(1.8, 29.0, Math.PI / 2);
  addPin(board, 'USB_IF', -1.2, t + 1.4, -(DKH - 29.0), 'usb', [-1, 0, 0]);
  addPin(board, 'USB_NRF', 108.6, t + 1.4, -(DKH + 0.8), 'usb', [0, 0, -1]);
  // Li-Po JST-PH (white) on the left edge
  const lipo = box(5.8, 4.6, 7.0, M.natural); lipo.position.copy(at(3.0, 51.0)); board.add(lipo);
  // slide switches
  const slide = (x, yd, w, d, h, bodyMat, knobMat, pos, name) => {
    const g = new THREE.Group();
    g.add(box(w, h, d, bodyMat));
    const k = box(w * 0.28, 1.4, d * 0.45, knobMat, 0, h, 0); k.name = 'knob'; g.add(k);
    g.userData.knob = k; g.userData.span = w * 0.36;
    g.position.copy(at(x, yd)); board.add(g); board.userData[name] = g;
    setSlide(g, pos); return g;
  };
  slide(5.4, 58.0, 8.6, 3.8, 3.4, M.steel, colorMat(0x111111), -1, 'swPower');
  slide(23.9, 24.7, 12.4, 3.6, 3.2, M.steel, colorMat(0x111111), 1, 'sw9');      // ships at USB? we set VDD later (0)
  slide(20.7, 59.4, 5.8, 3.4, 1.6, colorMat(0xd2742a), colorMat(0xf2f2f2), 1, 'sw10'); // VEXT->nRF ships ON? set OFF in the manual
  slide(89.0, 58.0, 5.8, 3.4, 1.6, colorMat(0xd2742a), colorMat(0xf2f2f2), 1, 'swNrfOnly');
  // tactile buttons (RESET + 4)
  const btn = (x, yd) => {
    const g = new THREE.Group();
    g.add(box(6.0, 3.1, 6.0, colorMat(0xdedede, { metalness: 0.4, roughness: 0.4 })));
    g.add(cyl(1.75, 1.6, M.black, 24, 0, 3.1, 0));
    for (const s of [-1, 1]) for (const u of [-1, 1]) g.add(box(1.2, 0.3, 0.8, M.tin, s * 3.4, 0, u * 2.25));
    g.position.copy(at(x, yd)); board.add(g); return g;
  };
  btn(74.0, 58.5); btn(110.0, 49.4); btn(120.6, 49.4); btn(110.0, 58.1); btn(120.6, 58.1);
  // LEDs 1-4 (0805, white bodies) - emissive driven by the sim
  board.userData.leds = [];
  for (const [x, yd] of [[119.1, 6.0], [129.4, 6.0], [119.1, 9.75], [129.4, 9.75]]) {
    const l = box(2.0, 0.7, 1.25, new THREE.MeshStandardMaterial({ color: 0xf4f6ff, emissive: 0x000000, roughness: 0.3 }));
    l.position.copy(at(x, yd)); board.add(l); board.userData.leds.push(l);
  }
  // main ICs
  const qfp = new THREE.Group();
  qfp.add(box(14, 1.4, 14, M.chip, 0, 0.15, 0));
  for (let s = 0; s < 4; s++) for (let i = 0; i < 32; i++) {
    const o = (i - 15.5) * 0.4, l = box(1.0, 0.15, 0.18, M.tin);
    if (s === 0) l.position.set(7.4, 0, o); else if (s === 1) { l.position.set(-7.4, 0, o); } else if (s === 2) { l.position.set(o, 0, 7.4); l.rotation.y = Math.PI / 2; } else { l.position.set(o, 0, -7.4); l.rotation.y = Math.PI / 2; }
    qfp.add(l);
  }
  qfp.add(cyl(0.5, 0.02, colorMat(0x333333), 12, -5.6, 1.55, 5.6));
  qfp.position.copy(at(42.5, 37.4)); board.add(qfp);
  const nrf = box(7, 0.85, 7, M.chip); nrf.position.copy(at(114.1, 24.6)); board.add(nrf);
  const mk = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 2.6), new THREE.MeshStandardMaterial({ map: labelTex('N5340\nQKAAD0', { w: 256, h: 128, fg: '#9a9a9a', font: 'bold 34px Arial' }), transparent: true, depthWrite: false }));
  mk.rotation.x = -Math.PI / 2; mk.position.copy(at(114.1, 24.6)); mk.position.y += 0.87; board.add(mk);
  const qspi = box(8, 0.8, 6, M.chip); qspi.position.copy(at(117.5, 41.3)); board.add(qspi);
  // Debug in / out shrouded 2x5 1.27 mm headers
  for (const [x, yd, r] of [[96.4, 3.4, 0], [3.9, 3.6, Math.PI / 2]]) {
    const g = new THREE.Group();
    g.add(box(6.4, 3.0, 4.8, M.black));
    g.add(box(5.4, 0.2, 2.6, colorMat(0x050505), 0, 2.9, 0));
    for (let i = 0; i < 5; i++) for (const s of [-1, 1]) g.add(box(0.4, 2.2, 0.4, M.gold, (i - 2) * 1.27, 0.8, s * 0.635));
    g.position.copy(at(x, yd)); g.rotation.y = r; board.add(g);
  }
  // right-angle 2-pin headers: P21 External supply (+ is the lower pin), current measurement pair
  const ra = (yd1, yd2, name1, name2) => {
    for (const [yd, n] of [[yd1, name1], [yd2, name2]]) {
      const pin = box(11, 0.64, 0.64, M.gold); pin.position.copy(at(2.0, yd)); pin.position.y = t + 1.27; board.add(pin);
      const tail = box(0.64, 3.5, 0.64, M.gold); tail.position.copy(at(7.4, yd)); tail.position.y = t - 1.9; board.add(tail);
      if (n) addPin(board, n, -3.3, t + 1.27, -(DKH - yd), 'rpin', [-1, 0, 0]);
    }
    const pl = box(2.5, 2.54, 5.08, M.black); pl.position.copy(at(6.0, (yd1 + yd2) / 2)); board.add(pl);
  };
  ra(42.63, 45.17, 'P21-', 'P21+');
  ra(11.0, 13.54, null, null);
  ra(19.7, 22.24, null, null);
  // big coin-cell holder on the bottom
  const hold = cyl(12, 4.2, M.black, 48, 0, -4.2, 0); hold.position.copy(at(76, 38)); hold.position.y = -4.2; board.add(hold);
  board.userData.kind = 'dk';
  return board;
}
export function setSlide(sw, pos) {
  // pos: -1 left, 0 middle, 1 right (along local x)
  sw.userData.pos = pos;
  sw.userData.knob.position.x = pos * sw.userData.span;
}

// --------------------------------------------------------------------------- Raspberry Pi Zero 2 W
export function makePiZero(specPi) {
  const spec = { name: 'pizero', bbox: [0, 0, 65, 30], outline: 'rect', radius: 3.0, holes: [], th: [], mask: '#409c48' };
  for (const [x, y] of [[3.5, 3.5], [61.5, 3.5], [3.5, 26.5], [61.5, 26.5]]) spec.holes.push({ x, y: 30 - y, d: 2.75 });
  for (const [pin, x, yd] of specPi.gpio) spec.th.push({ x, y: 30 - yd, drill: 1.0, dia: 1.7, pin });
  const board = makePCB(spec, { tex: loadTex('assets/pizero_top.jpg'), botColor: '#3e9746' });
  const t = board.userData.top;
  const at = (x, yd) => new THREE.Vector3(x, t, -(30 - yd));
  for (const [pin, x, yd] of specPi.gpio) addPin(board, 'GPIO' + pin, x, t, -(30 - yd), 'hole', [0, 1, 0]);
  // RP3A0 system-in-package
  const sip = box(14.0, 1.3, 14.0, colorMat(0x1a1a1c, { roughness: 0.4 })); sip.position.copy(at(26, 15.5)); board.add(sip);
  const mk = new THREE.Mesh(new THREE.PlaneGeometry(9, 5), new THREE.MeshStandardMaterial({ map: labelTex('RP3A0-AU\n2041\n210826', { w: 256, h: 160, fg: '#8d8d8d', font: 'bold 34px Arial' }), transparent: true, depthWrite: false }));
  mk.rotation.x = -Math.PI / 2; mk.position.copy(at(27, 17)); mk.position.y += 1.32; board.add(mk);
  // wireless module shield
  const sh = rbox(12.0, 1.3, 10.6, 0.6, colorMat(0xb7bcc2, { metalness: 0.9, roughness: 0.25 })); sh.position.copy(at(42.5, 13.0)); board.add(sh);
  // mini HDMI
  const hd = new THREE.Group();
  hd.add(rbox(11.2, 3.2, 7.5, 0.6, M.steel));
  const hm = box(10.4, 1.9, 0.3, colorMat(0x050505), 0, 0.6, 3.66); hd.add(hm);
  hd.add(box(8.6, 0.5, 1.6, M.black, 0, 1.2, 3.0));
  hd.position.copy(at(12.4, 26.6)); board.add(hd);
  // micro-USB x2
  for (const x of [41.4, 54.0]) {
    const u = new THREE.Group();
    u.add(rbox(7.6, 2.7, 5.6, 0.8, M.steel));
    u.add(box(6.6, 1.5, 0.3, colorMat(0x050505), 0, 0.6, 2.72));
    u.add(box(4.0, 0.5, 1.0, M.black, 0, 1.1, 2.3));
    u.position.copy(at(x, 27.4)); board.add(u);
  }
  addPin(board, 'PWR_IN', 54.0, t + 1.3, -(30 - 30.6), 'usb', [0, 0, 1]);
  // microSD push-pull socket
  const sd = new THREE.Group();
  sd.add(box(11.5, 1.45, 12.0, colorMat(0xc7ccd1, { metalness: 0.9, roughness: 0.32 })));
  sd.add(box(0.3, 0.8, 10.4, colorMat(0x050505), -5.75, 0.3, 0));
  sd.position.copy(at(6.0, 15.0)); board.add(sd);
  // camera FPC connector on the right end
  const csi = new THREE.Group();
  csi.add(box(4.2, 1.2, 17.0, M.black));
  csi.add(box(1.4, 0.4, 16.0, colorMat(0xd9c9a3), 1.6, 1.2, 0));
  csi.position.copy(at(62.4, 15.0)); board.add(csi);
  // passives and small ICs (deterministic layout)
  let s = 11; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 70; i++) {
    const x = 9 + rnd() * 52, y = 7.5 + rnd() * 14.5;
    if (x > 18 && x < 34 && y > 8 && y < 23) continue;
    if (x > 36 && x < 49 && y > 7 && y < 19) continue;
    const cap = rnd() > 0.45;
    const p = new THREE.Group();
    p.add(box(1.0, 0.5, 0.5, cap ? M.capTan : M.black));
    for (const u of [-1, 1]) p.add(box(0.2, 0.52, 0.5, M.tin, u * 0.45, 0, 0));
    p.position.copy(at(x, y)); p.rotation.y = rnd() > 0.5 ? Math.PI / 2 : 0; board.add(p);
  }
  for (const [x, y, w, d] of [[52, 11, 3, 3], [55.5, 16, 2, 2], [50.5, 17.5, 2.5, 2.5], [36, 21, 2.5, 2.5]]) { const c = box(w, 0.8, d, M.chip); c.position.copy(at(x, y)); board.add(c); }
  const ind = rbox(4, 1.8, 4, 0.4, colorMat(0x2a2a2c)); ind.position.copy(at(48.0, 22.0)); board.add(ind);
  const act = box(1.6, 0.6, 0.8, new THREE.MeshStandardMaterial({ color: 0xa6ffad, emissive: 0x000000 })); act.position.copy(at(58.5, 22.5)); board.add(act);
  board.userData.act = act;
  board.userData.kind = 'pizero';
  return board;
}

// --------------------------------------------------------------------------- Elechouse ST25R3916B module
export function makeNFC() {
  const W = 42.81, H = 40.26;
  const spec = { name: 'nfc', bbox: [0, 0, W, H], outline: 'rect', radius: 1.2, holes: [{ x: 2.6, y: H - 37.6, d: 2.2 }, { x: W - 2.6, y: H - 37.6, d: 2.2 }], th: [], mask: '#18469a' };
  const board = makePCB(spec, { tex: loadTex('assets/nfc_top.jpg'), botColor: '#18469a' });
  const t = board.userData.top;
  const at = (x, yd) => new THREE.Vector3(x, t, -(H - yd));
  const ic = box(5, 0.9, 5, M.chip); ic.position.copy(at(29.0, 33.2)); board.add(ic);
  const xtal = rbox(3.2, 0.8, 2.5, 0.3, M.steel); xtal.position.copy(at(35.0, 33.0)); board.add(xtal);
  const ldo = box(2.9, 1.0, 1.6, M.chip); ldo.position.copy(at(8.0, 33.5)); board.add(ldo);
  let s = 3; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 22; i++) {
    const x = 5 + rnd() * 33, y = 31.6 + rnd() * 6.8;
    if (x > 11 && x < 22) continue; if (x > 26 && x < 37 && y < 36) continue;
    const p = new THREE.Group(); const cap = rnd() > 0.35;
    p.add(box(1.0, 0.5, 0.5, cap ? M.capTan : M.black)); for (const u of [-1, 1]) p.add(box(0.2, 0.52, 0.5, M.tin, u * 0.45, 0, 0));
    p.position.copy(at(x, y)); board.add(p);
  }
  const led = box(1.6, 0.6, 0.8, new THREE.MeshStandardMaterial({ color: 0xbfe0ff, emissive: 0x000000 })); led.position.copy(at(24.5, 37.6)); board.add(led); board.userData.led = led;
  // MX1.25 / PicoBlade 7-pin vertical receptacle
  const con = new THREE.Group();
  con.add(box(10.6, 4.2, 3.4, M.natural));
  con.add(box(8.9, 0.2, 2.0, colorMat(0x4a4436), 0, 4.15, 0));
  for (let i = 0; i < 7; i++) con.add(box(0.3, 3.6, 0.3, M.gold, (i - 3) * 1.25, 0.6, 0));
  con.position.copy(at(16.35, 36.6)); board.add(con);
  addPin(board, 'CONN', 16.35, t + 4.2, -(H - 36.6), 'pico', [0, 1, 0]);
  board.userData.kind = 'nfc';
  return board;
}

// --------------------------------------------------------------------------- LiPo 2500 mAh with protection board and JST-PH lead
export function makeBattery() {
  const g = new THREE.Group();
  const L = 60, W = 50, T = 7.3;
  const pouch = rbox(W, T, L, 3, M.pouch); g.add(pouch);
  // folded seal edges
  g.add(box(W + 1.6, 0.4, 1.8, M.pouch, 0, T / 2 - 0.2, -L / 2 - 0.4));
  const lab = new THREE.Mesh(new THREE.PlaneGeometry(36, 30), new THREE.MeshStandardMaterial({ map: labelTex('3.7V  2500mAh\nLi-Polymer\nPCM protected', { w: 512, h: 420, fg: '#2c2c2c', bg: '#f4f4f2', font: 'bold 46px Arial' }), roughness: 0.6 }));
  lab.rotation.x = -Math.PI / 2; lab.position.set(0, T + 0.02, 4); g.add(lab);
  // yellow kapton over the PCM at the lead end
  const kap = rbox(W - 6, 1.0, 7, 1, M.kapton); kap.position.set(0, T / 2 - 0.5, -L / 2 - 3.0); g.add(kap);
  addPin(g, 'LEAD', 0, T / 2, -L / 2 - 6.5, 'lead', [0, 0, -1]);
  g.userData.kind = 'battery';
  return g;
}

// --------------------------------------------------------------------------- GLB parts (toggle switch, magnetic connector halves)
const gltf = new GLTFLoader();
const glbCache = {};
export function loadGLB(url) {
  // GLB shipped as base64 text (artifact hosting serves text, not binary models)
  return glbCache[url] || (glbCache[url] = fetch(url.replace('.glb', '.b64.txt')).then(r => r.text()).then(t => {
    const bin = Uint8Array.from(atob(t.trim()), c => c.charCodeAt(0));
    return new Promise((res, rej) => gltf.parse(bin.buffer, '', (g) => res(g.scene), rej));
  }));
}
export async function makeToggle() {
  const sc = (await loadGLB('assets/3221.glb')).clone(true);
  sc.scale.setScalar(1000);
  sc.traverse(o => { if (o.isMesh) { o.material = o.material.clone(); const c = o.material.color; if (c.b > 0.8 && c.r < 0.4) { o.material.color.set(0x2a5bd7); o.material.roughness = 0.5; } else { o.material.metalness = 0.9; o.material.roughness = 0.3; o.material.color.set(0xb9bec4); } } });
  // CAD long axis is z: turn it so the lever points up (+y)
  const g = new THREE.Group(); sc.rotation.x = -Math.PI / 2; g.add(sc);
  // lugs at local z -13.5..-11.3 -> after rotation at y -13.5..-11.3; lug spacing along y(CAD) -> -z here
  for (const [n, y] of [['L1', -4.7], ['COM', 0], ['L2', 4.7]]) addPin(g, n, 0, -13.0, y, 'lug', [0, -1, 0]);
  g.userData.kind = 'toggle';
  g.userData.lever = sc;
  return g;
}
export async function makeMagnetic(half) {
  const sc = (await loadGLB(`assets/5413${half}.glb`)).clone(true);
  sc.scale.setScalar(1000);
  sc.traverse(o => { if (o.isMesh) { o.material = o.material.clone(); const c = o.material.color; if (c.r > 0.8 && c.g > 0.5 && c.b < 0.4) { o.material.color.set(0xdcb05a); o.material.metalness = 1; o.material.roughness = 0.25; } else if (c.r > 0.5) { o.material.metalness = 0.9; o.material.roughness = 0.3; } } });
  const g = new THREE.Group(); sc.rotation.x = -Math.PI / 2; g.add(sc);
  for (let i = 0; i < 5; i++) addPin(g, 'P' + (i + 1), (i - 2) * 2.54, -1.6, 0, 'tail', [0, -1, 0]);
  g.userData.kind = 'magnetic-' + half;
  return g;
}
