// Part model library: every board and part at true scale in millimetres.
// Eagle board coordinates (x right, y up) map to world (x, height, -y).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const MM = 1;
const TAU = Math.PI * 2;

// ------------------------------------------------------------------ materials
const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0, ...o });
export const M = {
  gold: std(0xd9ae55, { metalness: 1, roughness: 0.28 }),
  tin: std(0xd3d7dc, { metalness: 1, roughness: 0.22 }),
  solder: std(0xc4c9cf, { metalness: 1, roughness: 0.18 }),
  steel: std(0xb9bec4, { metalness: 0.9, roughness: 0.35 }),
  nickel: std(0xc8ccd0, { metalness: 0.95, roughness: 0.3 }),
  copper: std(0xc77b4a, { metalness: 1, roughness: 0.35 }),
  black: std(0x161617, { roughness: 0.62 }),
  blackGloss: std(0x1b1b1d, { roughness: 0.32 }),
  chip: std(0x202022, { roughness: 0.48 }),
  white: std(0xf1efe8, { roughness: 0.5 }),
  natural: std(0xeee7d4, { roughness: 0.55 }),
  capTan: std(0xb89b72, { roughness: 0.6 }),
  capBrown: std(0x8a6a48, { roughness: 0.6 }),
  ledLens: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.15, transmission: 0.6, thickness: 0.5, transparent: true, opacity: 0.85 }),
  glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.05, transmission: 0.92, thickness: 1.2, ior: 1.5, transparent: true, opacity: 0.35, depthWrite: false }),
  nylon: std(0xf3f0e6, { roughness: 0.7 }),
  fr4: std(0xc9b98a, { roughness: 0.8 }),
  blueTerm: std(0x1f6fd1, { roughness: 0.5 }),
  kapton: new THREE.MeshStandardMaterial({ color: 0xe8a22c, roughness: 0.35, transparent: true, opacity: 0.88 }),
  shrinkBlack: std(0x111112, { roughness: 0.75 }),
  pouch: std(0xc9cdd1, { metalness: 0.65, roughness: 0.38 }),
  rubberBlack: std(0x0f0f10, { roughness: 0.9 }),
};
const matCache = {};
export function colorMat(hex, o = {}) {
  const k = hex + JSON.stringify(o);
  return matCache[k] || (matCache[k] = std(hex, o));
}

// ------------------------------------------------------------------ helpers
export function box(w, h, d, mat, x = 0, y = 0, z = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y + h / 2, z);
  return m;
}
export function cyl(r, h, mat, seg = 20, x = 0, y = 0, z = 0, open = false) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, seg, 1, open), mat);
  m.position.set(x, y + h / 2, z);
  return m;
}
export function rbox(w, h, d, r, mat) {
  // rounded rectangle extruded along Y (height h), centred, bottom at y=0
  const s = new THREE.Shape();
  const x = -w / 2, z = -d / 2; r = Math.min(r, w / 2, d / 2);
  s.moveTo(x + r, z); s.lineTo(x + w - r, z); s.quadraticCurveTo(x + w, z, x + w, z + r);
  s.lineTo(x + w, z + d - r); s.quadraticCurveTo(x + w, z + d, x + w - r, z + d);
  s.lineTo(x + r, z + d); s.quadraticCurveTo(x, z + d, x, z + d - r); s.lineTo(x, z + r); s.quadraticCurveTo(x, z, x + r, z);
  const g = new THREE.ExtrudeGeometry(s, { depth: h, bevelEnabled: false, curveSegments: 6 });
  g.rotateX(Math.PI / 2); g.translate(0, h, 0);
  return new THREE.Mesh(g, mat);
}
export function canvasTex(w, h, draw, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8; return t;
}
export function labelTex(text, opts = {}) {
  const { w = 256, h = 64, bg = null, fg = '#e8e8e8', font = 'bold 40px "DejaVu Sans", Arial, sans-serif' } = opts;
  return canvasTex(w, h, (g) => {
    if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
    g.fillStyle = fg; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle';
    String(text).split('\n').forEach((l, i, a) => g.fillText(l, w / 2, h / 2 + (i - (a.length - 1) / 2) * h / a.length));
  });
}
function topDecal(w, d, tex, y) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshStandardMaterial({ map: tex, transparent: true, roughness: 0.6, depthWrite: false }));
  m.rotation.x = -Math.PI / 2; m.position.y = y + 0.01; return m;
}
const texLoader = new THREE.TextureLoader();
export function loadTex(url) {
  const t = texLoader.load(url); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
// Pins registry helper: every part exposes userData.pins[name] = {p: Vector3 (local), dir: Vector3 (wire exit dir), kind}
export function addPin(obj, name, x, y, z, kind = 'hole', dir = [0, 1, 0], extra = {}) {
  obj.userData.pins = obj.userData.pins || {};
  obj.userData.pins[name] = { p: new THREE.Vector3(x, y, z), dir: new THREE.Vector3(...dir).normalize(), kind, ...extra };
}

// ------------------------------------------------------------------ PCB from a spec
export const PCB_T = 1.6;
export function makePCB(spec, opts = {}) {
  const g = new THREE.Group(); g.name = spec.name;
  const [x0, y0, x1, y1] = spec.bbox;
  const t = opts.thickness || PCB_T;
  const shape = new THREE.Shape();
  if (spec.outline === 'rect' || !spec.outline) {
    const r = spec.radius || 1;
    shape.moveTo(x0 + r, y0); shape.lineTo(x1 - r, y0); shape.absarc(x1 - r, y0 + r, r, -Math.PI / 2, 0);
    shape.lineTo(x1, y1 - r); shape.absarc(x1 - r, y1 - r, r, 0, Math.PI / 2);
    shape.lineTo(x0 + r, y1); shape.absarc(x0 + r, y1 - r, r, Math.PI / 2, Math.PI);
    shape.lineTo(x0, y0 + r); shape.absarc(x0 + r, y0 + r, r, Math.PI, Math.PI * 1.5);
  } else {
    const o = spec.outline; shape.moveTo(o[0][0], o[0][1]);
    for (let i = 1; i < o.length; i++) shape.lineTo(o[i][0], o[i][1]);
  }
  const holes = [];
  for (const h of spec.th || []) holes.push({ x: h.x, y: h.y, r: h.drill / 2, plated: true, dia: h.dia || h.drill * 1.9 });
  for (const h of spec.holes || []) holes.push({ x: h.x, y: h.y, r: h.d / 2, plated: false });
  for (const h of opts.extraHoles || []) holes.push(h);
  for (const h of holes) { const p = new THREE.Path(); p.absarc(h.x, h.y, h.r, 0, TAU, true); shape.holes.push(p); }
  const seg = holes.length > 100 ? 3 : 5;
  const uvfix = (geo, flip) => {
    const pos = geo.attributes.position, uv = geo.attributes.uv;
    for (let i = 0; i < pos.count; i++) uv.setXY(i, (pos.getX(i) - x0) / (x1 - x0), (pos.getY(i) - y0) / (y1 - y0));
    uv.needsUpdate = true;
  };
  const topGeo = new THREE.ShapeGeometry(shape, seg); uvfix(topGeo);
  topGeo.rotateX(-Math.PI / 2); topGeo.translate(0, t, 0);
  const botGeo = new THREE.ShapeGeometry(shape, seg); uvfix(botGeo);
  botGeo.rotateX(Math.PI / 2); botGeo.scale(1, 1, -1);
  // bottom faces must point down: rotateX(+90) maps (x,y)->(x,0,y); scale z -1 -> (x,0,-y); flip winding
  const idx = botGeo.index.array; for (let i = 0; i < idx.length; i += 3) { const a = idx[i]; idx[i] = idx[i + 1]; idx[i + 1] = a; }
  const sideGeo = new THREE.ExtrudeGeometry(shape, { depth: t, bevelEnabled: false, curveSegments: seg });
  sideGeo.rotateX(-Math.PI / 2);
  const topMat = new THREE.MeshStandardMaterial({ map: opts.tex || null, color: opts.tex ? 0xffffff : (spec.mask || '#202020'), roughness: 0.42, metalness: 0.05 });
  const botTex = opts.botTex || bottomTexture(spec, holes, opts);
  const botMat = new THREE.MeshStandardMaterial({ map: botTex, roughness: 0.45 });
  const edge = new THREE.MeshStandardMaterial({ color: new THREE.Color(spec.mask || '#202020').lerp(new THREE.Color(0xc9b98a), 0.35), roughness: 0.8 });
  g.add(new THREE.Mesh(topGeo, topMat), new THREE.Mesh(botGeo, botMat), new THREE.Mesh(sideGeo, [new THREE.MeshBasicMaterial({ visible: false }), edge]));
  // plated barrels
  const plated = holes.filter(h => h.plated);
  if (plated.length) {
    const bg = new THREE.CylinderGeometry(1, 1, t, 10, 1, true);
    const inst = new THREE.InstancedMesh(bg, new THREE.MeshStandardMaterial({ color: 0xc9a25a, metalness: 1, roughness: 0.35, side: THREE.BackSide }), plated.length);
    const m4 = new THREE.Matrix4();
    plated.forEach((h, i) => { m4.makeScale(h.r, 1, h.r); m4.setPosition(h.x, t / 2, -h.y); inst.setMatrixAt(i, m4); });
    g.add(inst);
  }
  g.userData.top = t; g.userData.spec = spec;
  return g;
}
function bottomTexture(spec, holes, opts) {
  const [x0, y0, x1, y1] = spec.bbox; const ppm = 12;
  const W = Math.ceil((x1 - x0) * ppm), H = Math.ceil((y1 - y0) * ppm);
  return canvasTex(W, H, (g) => {
    g.fillStyle = opts.botColor || spec.mask || '#202020'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#d2a858';
    for (const h of holes) {
      if (!h.plated && !h.ring) continue;
      g.beginPath(); g.arc((h.x - x0) * ppm, (y1 - h.y) * ppm, (h.dia || h.r * 3.4) / 2 * ppm, 0, TAU); g.fill();
    }
    if (opts.botDraw) opts.botDraw(g, ppm, x0, y1);
  });
}

// ------------------------------------------------------------------ SMD bodies from Eagle specs
function leadsAlong(w, d, n, side, pitch, mat, len = 0.45, th = 0.18, y = 0) {
  // gull-wing style lead stubs; side: 'x' leads exit along +-x
  const grp = new THREE.Group();
  for (let i = 0; i < n; i++) {
    const off = (i - (n - 1) / 2) * pitch;
    for (const s of [-1, 1]) {
      const l = new THREE.Mesh(new THREE.BoxGeometry(side === 'x' ? len : th * 1.8, th, side === 'x' ? th * 1.8 : len), mat);
      if (side === 'x') l.position.set(s * (w / 2 + len / 2 - 0.05), y + th / 2, off);
      else l.position.set(off, y + th / 2, s * (d / 2 + len / 2 - 0.05));
      grp.add(l);
    }
  }
  return grp;
}
export function smdBody(b, ctx = {}) {
  const g = new THREE.Group();
  const t = b.type, w = b.w, d = b.d, h = b.h;
  const pkg = (b.package || '').toUpperCase(), val = (b.value || '').toUpperCase(), name = (b.name || '').toUpperCase();
  if (t === 'res' || t === 'fuse') {
    const L = Math.max(w, d), S = Math.min(w, d);
    const core = box(L * 0.72, h * 0.95, S, M.black); g.add(core);
    const top = box(L * 0.7, 0.02, S * 0.96, M.black); top.position.y = h * 0.95; g.add(top);
    for (const s of [-1, 1]) g.add(box(L * 0.16, h, S, M.tin, s * (L / 2 - L * 0.08), 0, 0));
    if (w < d) g.rotation.y = Math.PI / 2;
  } else if (t === 'cap') {
    const L = Math.max(w, d), S = Math.min(w, d);
    const big = /10UF|22UF/.test(val);
    g.add(box(L * 0.74, h, S * 0.98, big ? M.capBrown : M.capTan));
    for (const s of [-1, 1]) g.add(box(L * 0.14, h * 1.01, S, M.tin, s * (L / 2 - L * 0.07), 0, 0));
    if (w < d) g.rotation.y = Math.PI / 2;
  } else if (t === 'led') {
    const L = Math.max(w, d), S = Math.min(w, d);
    g.add(box(L, h * 0.55, S, M.white));
    const col = /RED/.test(val) ? 0xff6a5a : /GREEN/.test(val) ? 0x9cf09c : /YEL|AMB/.test(val) ? 0xffd36a : 0xfff6d8;
    const lens = box(L * 0.8, h * 0.45, S * 0.8, new THREE.MeshStandardMaterial({ color: col, roughness: 0.2, transparent: true, opacity: 0.85, emissive: 0x000000 }));
    lens.position.y = h * 0.55; lens.userData.ledLens = true; g.add(lens);
    for (const s of [-1, 1]) g.add(box(L * 0.1, h * 0.3, S * 0.9, M.tin, s * (L / 2 - 0.05), 0, 0));
    if (w < d) g.rotation.y = Math.PI / 2;
    g.userData.led = lens;
  } else if (t === 'diode') {
    const L = Math.max(w, d), S = Math.min(w, d);
    const sma = /SMA/.test(pkg);
    const bl = sma ? L * 0.68 : L * 0.62;
    g.add(box(bl, h, S * 0.9, M.chip));
    g.add(box(bl * 0.12, 0.02, S * 0.86, M.tin, -bl / 2 + bl * 0.12, h, 0));
    for (const s of [-1, 1]) g.add(box((L - bl) / 2 + 0.2, 0.2, S * (sma ? 0.55 : 0.35), M.tin, s * (bl / 2 + (L - bl) / 4), 0, 0));
    if (w < d) g.rotation.y = Math.PI / 2;
  } else if (t === 'inductor') {
    g.add(rbox(w * 0.98, h, d * 0.98, 0.5, colorMat(0x2c2c2e, { roughness: 0.75 })));
    g.add(topDecal(w * 0.6, d * 0.4, labelTex(/1UH/.test(val) ? '1R0' : 'R', { fg: '#cfcfcf' }), h));
  } else if (t === 'crystal') {
    g.add(box(w * 0.95, h * 0.7, d * 0.9, M.black));
    g.add(box(w * 0.85, h * 0.3, d * 0.78, M.steel, 0, h * 0.7, 0));
  } else if (t === 'sot') {
    const L = Math.max(w, d), S = Math.min(w, d);
    const n = /SOT23-5|SOT23-6|SOT363|SOT563|SC70|SOT-363/.test(pkg) ? 3 : 2;
    const bw = /SOT563|SOT363/.test(pkg) ? 1.6 : 2.9, bd = /SOT563|SOT363/.test(pkg) ? 1.2 : 1.6;
    const body = box(bw, h * 0.9, bd, M.chip, 0, 0.1, 0); g.add(body);
    g.add(leadsAlong(bw, bd, n, 'z', /SOT563|SOT363/.test(pkg) ? 0.5 : 0.95, M.tin, 0.45, 0.14, 0));
    g.add(box(0.22, 0.01, 0.22, M.tin, -bw / 2 + 0.35, h, bd / 2 - 0.35));
    if (w < d) g.rotation.y = Math.PI / 2;
  } else if (t === 'soic') {
    const bw = 4.9, bd = 3.9;
    g.add(box(bw, 1.45, bd, M.chip, 0, 0.1, 0));
    g.add(leadsAlong(bw, bd, 4, 'z', 1.27, M.tin, 0.9, 0.2, 0));
    const dot = cyl(0.3, 0.02, M.black, 12, -bw / 2 + 0.7, 1.55, bd / 2 - 0.7); dot.material = colorMat(0x0b0b0b); g.add(dot);
    g.add(topDecal(3.6, 1.4, labelTex('PCF8523T', { fg: '#8a8a8a', font: 'bold 36px Arial' }), 1.55));
    if (b.w > b.d) g.rotation.y = Math.PI / 2;
  } else if (t === 'ic') {
    if (/RESPACK/.test(pkg)) {
      const L = Math.max(w, d), S = Math.min(w, d);
      g.add(box(L * 0.92, 0.5, S * 0.55, M.black));
      for (let i = 0; i < 4; i++) for (const s of [-1, 1]) g.add(box(0.35, 0.5, 0.25, M.tin, (i - 1.5) * 0.8, 0, s * S * 0.3));
      if (w < d) g.rotation.y = Math.PI / 2;
    } else if (/BME680/.test(pkg + val)) {
      g.add(box(3.0, 0.93, 3.0, M.steel));
      const hole = cyl(0.25, 0.02, colorMat(0x050505), 12, -0.8, 0.93, 0.8); g.add(hole);
    } else if (/AS7341/.test(pkg + val)) {
      g.add(box(3.1, 1.0, 2.0, colorMat(0x2a2620, { roughness: 0.4 })));
      g.add(box(1.0, 0.02, 1.0, new THREE.MeshPhysicalMaterial({ color: 0x334455, roughness: 0.05, metalness: 0.2, clearcoat: 1 }), 0.55, 1.0, 0));
    } else {
      const qfn = /QFN|DFN|SON/.test(pkg);
      g.add(box(w, h, d, M.chip));
      if (qfn) for (let side = 0; side < 4; side++) {
        const n = Math.max(2, Math.round((side % 2 ? d : w) / 0.65) - 1);
        for (let i = 0; i < n; i++) {
          const o = (i - (n - 1) / 2) * 0.55;
          const p = box(0.28, 0.2, 0.08, M.tin);
          if (side === 0) p.position.set(o, 0, d / 2); else if (side === 1) { p.position.set(w / 2, 0, o); p.rotation.y = Math.PI / 2; }
          else if (side === 2) p.position.set(o, 0, -d / 2); else { p.position.set(-w / 2, 0, o); p.rotation.y = Math.PI / 2; }
          g.add(p);
        }
      }
      g.add(cyl(Math.min(w, d) * 0.07, 0.02, colorMat(0x3a3a3a), 12, -w / 2 + w * 0.18, h, d / 2 - d * 0.18));
    }
  } else if (t === 'stemma') {
    // JST SH 4-pin side-entry receptacle: opening on local +x
    const L = 4.25, W = 6.0, H = 2.95;
    const body = box(L, H, W, M.black); g.add(body);
    const mouth = box(0.5, H * 0.62, W * 0.72, colorMat(0x050505), L / 2 - 0.2, H * 0.2, 0); g.add(mouth);
    for (let i = 0; i < 4; i++) g.add(box(0.2, 0.9, 0.3, M.gold, L / 2 - 0.5, H * 0.32, (i - 1.5) * 1.0));
    for (let i = 0; i < 4; i++) g.add(box(0.8, 0.15, 0.32, M.tin, -L / 2 - 0.35, 0, (i - 1.5) * 1.0));
    for (const s of [-1, 1]) g.add(box(1.4, 0.8, 0.25, M.tin, L / 2 - 1.0, 0, s * (W / 2 + 0.12)));
    g.userData.port = { open: new THREE.Vector3(1, 0, 0), y: H * 0.5, depth: L };
  } else if (t === 'jstph') {
    // JST PH 2-pin right-angle receptacle; opening on local +x after orientation fix
    const L = 7.5, W = 6.0, H = 4.8;
    g.add(box(L, H, W, M.natural));
    g.add(box(0.6, H * 0.62, W * 0.78, colorMat(0x4a4436), L / 2 - 0.25, H * 0.2, 0));
    for (let i = 0; i < 2; i++) g.add(box(L * 0.7, 0.5, 0.5, M.tin, -0.5, 1.2, (i - 0.5) * 2.0));
    for (const s of [-1, 1]) g.add(box(2, 0.25, 1.2, M.tin, -L / 2 + 1, 0, s * (W / 2 + 0.3)));
    g.userData.port = { open: new THREE.Vector3(1, 0, 0), y: H * 0.45, depth: L };
  } else if (t === 'usbc') {
    const L = 7.35, W = 8.94, H = 3.2;
    const s = rbox(L, H, W, 1.3, M.steel); s.rotation.z = 0; g.add(s);
    g.add(box(0.3, H * 0.65, W * 0.75, colorMat(0x111111), L / 2 - 0.1, H * 0.18, 0));
    g.add(box(0.4, 0.7, W * 0.55, M.black, L / 2 - 0.3, H * 0.4, 0));
    g.userData.port = { open: new THREE.Vector3(1, 0, 0), y: H / 2, depth: L };
  } else if (t === 'dcjack') {
    const L = 14.0, W = 9.0, H = 6.5;
    g.add(box(L, H, W, M.black));
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 0.3, 24), M.black); ring.rotation.z = Math.PI / 2; ring.position.set(L / 2 + 0.15, H / 2, 0); g.add(ring);
    const hole = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 0.32, 24), colorMat(0x050505)); hole.rotation.z = Math.PI / 2; hole.position.set(L / 2 + 0.16, H / 2, 0); g.add(hole);
    const pin = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 4, 12), M.tin); pin.rotation.z = Math.PI / 2; pin.position.set(L / 2 - 1.8, H / 2, 0); g.add(pin);
    g.userData.port = { open: new THREE.Vector3(1, 0, 0), y: H / 2, depth: L };
  } else if (t === 'termblock') {
    // 3.5 mm pitch PCB screw terminal: pins along local x; entry on local -z side (fixed later)
    const n = Math.round(w / 3.5), W = 3.5 * n, D = 7.2, H = 8.5;
    const body = new THREE.Group();
    body.add(box(W, H * 0.62, D, M.blueTerm));
    for (let i = 0; i < n; i++) {
      const x = (i - (n - 1) / 2) * 3.5;
      body.add(box(3.1, H * 0.38, D * 0.55, M.blueTerm, x, H * 0.62, D * 0.18));
      const sc = cyl(1.35, 0.6, M.nickel, 20, x, H - 0.5, D * 0.18); body.add(sc);
      const slot = box(2.2, 0.2, 0.35, colorMat(0x3a3a3a), x, H + 0.1 - 0.01, D * 0.18); body.add(slot);
      body.add(box(2.4, 2.4, 0.3, colorMat(0x0a0a0a), x, 1.6, -D / 2 - 0.12));
      const cage = box(2.6, 2.6, 0.2, M.nickel, x, 1.5, -D / 2 + 0.25); body.add(cage);
      body.add(box(0.8, 3.4, 0.5, M.tin, x, -3.4, 0));
    }
    g.add(body);
    g.userData.entry = new THREE.Vector3(0, 0, -1);
  } else if (t === 'switch') {
    g.add(box(w * 0.9, h, d * 0.9, M.black));
  } else {
    g.add(box(w, h, d, M.chip));
  }
  return g;
}

// Place all Eagle bodies on a board group; orient connectors toward the nearest board edge.
export function populateBoard(board, spec) {
  const t = board.userData.top;
  const [x0, y0, x1, y1] = spec.bbox;
  board.userData.parts = {};
  for (const b of spec.bodies || []) {
    const m = smdBody(b);
    m.position.set(b.cx, t, -b.cy);
    let rot = b.rot * Math.PI / 180;
    if (b.type === 'jstph' || b.type === 'usbc' || b.type === 'dcjack' || b.type === 'termblock') {
      // face the opening toward the closest edge
      const dl = b.cx - x0, dr = x1 - b.cx, db = b.cy - y0, dt = y1 - b.cy;
      const mn = Math.min(dl, dr, db, dt);
      const ang = mn === dr ? 0 : mn === dt ? Math.PI / 2 : mn === dl ? Math.PI : -Math.PI / 2;
      if (b.type === 'termblock') {
        // entry is on local -z; rotate so -z points to the edge: world dir of local -z after rot r is (−sin r, 0, −cos r)
        rot = { 0: Math.PI / 2, [Math.PI / 2]: 0, [Math.PI]: -Math.PI / 2, [-Math.PI / 2]: Math.PI }[ang];
        m.position.set(b.cx, t, -b.cy);
      } else {
        rot = ang;
        const L = b.type === 'jstph' ? 7.5 : b.type === 'usbc' ? 7.35 : 14.0;
        // keep the mouth flush with (or slightly over) the board edge
        const ex = Math.cos(ang), ey = Math.sin(ang);
        let cx = b.cx, cy = b.cy;
        if (b.type === 'dcjack') { cx = ang === Math.PI ? x0 + L / 2 - 0.6 : cx; }
        if (b.type === 'usbc') { cx = ang === Math.PI ? x0 + L / 2 - 0.8 : cx; }
        m.position.set(cx, t, -cy);
      }
    }
    if (b.type === 'stemma') rot = b.rot * Math.PI / 180;
    m.rotation.y += rot;
    m.userData.body = b;
    board.add(m);
    board.userData.parts[b.name] = m;
  }
}

// ------------------------------------------------------------------ headers and sockets
export function maleHeader(n, opts = {}) {
  // straight 2.54 mm header strip along +x, pin 1 at x=0; plastic sits on y=0, pins 6 mm above plastic, tail below
  const { rows = 1, above = 6.0, tail = 3.0, plastic = 2.5 } = opts;
  const g = new THREE.Group();
  const pb = box(2.54 * n, plastic, 2.54 * rows, M.black, 2.54 * (n - 1) / 2, 0, -2.54 * (rows - 1) / 2);
  g.add(pb);
  const pinGeo = new THREE.BoxGeometry(0.64, plastic + above + tail, 0.64);
  pinGeo.translate(0, (plastic + above + tail) / 2 - tail, 0);
  // chamfer tips visually with a small cone
  const inst = new THREE.InstancedMesh(pinGeo, M.gold, n * rows);
  const m4 = new THREE.Matrix4(); let k = 0;
  for (let r = 0; r < rows; r++) for (let i = 0; i < n; i++) { m4.makeTranslation(2.54 * i, 0, -2.54 * r); inst.setMatrixAt(k++, m4); }
  g.add(inst);
  g.userData.pinTop = plastic + above;
  return g;
}
export function femaleSocket(n, opts = {}) {
  const { rows = 1, height = 8.5 } = opts;
  const g = new THREE.Group();
  const W = 2.54 * n, D = 2.54 * rows;
  const tex = canvasTex(64 * n, 64 * rows, (c, w, h) => {
    c.fillStyle = '#141414'; c.fillRect(0, 0, w, h);
    c.fillStyle = '#020202';
    for (let r = 0; r < rows; r++) for (let i = 0; i < n; i++) c.fillRect(i * 64 + 20, r * 64 + 20, 24, 24);
    c.strokeStyle = '#2a2a2a'; c.lineWidth = 2;
    for (let i = 1; i < n; i++) { c.beginPath(); c.moveTo(i * 64, 0); c.lineTo(i * 64, h); c.stroke(); }
  });
  const mats = [M.black, M.black, new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 }), M.black, M.black, M.black];
  const b = new THREE.Mesh(new THREE.BoxGeometry(W, height, D), mats);
  b.position.set(2.54 * (n - 1) / 2, height / 2, -2.54 * (rows - 1) / 2);
  g.add(b);
  g.userData.top = height;
  return g;
}

// ------------------------------------------------------------------ through-hole parts
export function to92(markText = '', opts = {}) {
  // TO-92: flat face toward local +z; legs at x = -2.54, 0, +2.54 after forming to 0.1" pitch
  const g = new THREE.Group();
  const lift = opts.lift ?? 3.0; // body bottom above board
  const r = 2.4, H = 4.8;
  const shape = new THREE.Shape();
  shape.moveTo(-2.3, 0.6);
  shape.absarc(0, 0, r, Math.asin(0.6 / r) + 0.0, Math.PI - Math.asin(0.6 / r), true);
  shape.lineTo(-2.3, 0.6);
  // body cross-section: half-round with flat face (z=+1.3)
  const s2 = new THREE.Shape();
  s2.moveTo(-2.25, 1.3); s2.lineTo(2.25, 1.3);
  s2.absarc(0, -0.1, 2.45, Math.atan2(1.4, 2.25), Math.PI - Math.atan2(1.4, 2.25), true);
  const geo = new THREE.ExtrudeGeometry(s2, { depth: H, bevelEnabled: true, bevelSize: 0.15, bevelThickness: 0.15, bevelSegments: 2, curveSegments: 24 });
  geo.rotateX(-Math.PI / 2); // extrude along +y
  const body = new THREE.Mesh(geo, M.chip);
  body.position.y = lift; body.scale.z = -1;
  body.rotation.y = Math.PI;
  g.add(body);
  if (markText) {
    const d = new THREE.Mesh(new THREE.PlaneGeometry(4.0, 3.2), new THREE.MeshStandardMaterial({ map: labelTex(markText, { w: 256, h: 192, fg: '#bdbdbd', font: 'bold 44px Arial' }), transparent: true, depthWrite: false }));
    d.position.set(0, lift + H / 2 + 0.2, 1.32); g.add(d);
  }
  // legs: three 0.45 mm tinned leads; outer legs kinked out to 2.54 mm pitch
  for (const i of [-1, 0, 1]) {
    const pts = [new THREE.Vector3(i * 1.27, lift + 0.2, 0), new THREE.Vector3(i * 1.27, lift - 0.8, 0), new THREE.Vector3(i * 2.54, lift - 1.8, 0), new THREE.Vector3(i * 2.54, -2.2, 0)];
    const c = new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.1);
    g.add(new THREE.Mesh(new THREE.TubeGeometry(c, 16, 0.22, 6), M.tin));
  }
  return g;
}
export function radialCap(opts = {}) {
  // 1 uF X7R ceramic, 2.54 mm radial: yellow/blue epoxy dip body
  const g = new THREE.Group();
  const lift = opts.lift ?? 2.5;
  const body = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 14), colorMat(opts.color || 0x2a64b8, { roughness: 0.4 }));
  body.scale.set(2.3, 2.4, 1.3); body.position.y = lift + 2.4; g.add(body);
  const d = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.3), new THREE.MeshStandardMaterial({ map: labelTex('105', { fg: '#f2f2f2', font: 'bold 46px Arial' }), transparent: true, depthWrite: false }));
  d.position.set(0, lift + 2.5, 1.32); g.add(d);
  for (const s of [-1, 1]) g.add(cyl(0.25, lift + 2.2 + 2.5, M.tin, 6, s * 1.27, -2.5, 0));
  return g;
}
export function axialResistor(bands, opts = {}) {
  // 1/4 W carbon-film resistor, beige body, colour bands; leads bent for `span` mm pitch, standing `lift` above board
  const g = new THREE.Group();
  const span = opts.span ?? 10.16, lift = opts.lift ?? 1.4, L = 6.3, R = 1.2;
  const pts = [];
  for (let i = 0; i <= 24; i++) {
    const t = i / 24, x = (t - 0.5) * L;
    const bulge = Math.abs(x) > L * 0.36 ? 1.0 : 0.88;
    pts.push(new THREE.Vector2(R * bulge * Math.sqrt(Math.max(0.02, 1 - Math.pow(Math.abs(x) / (L / 2), 8))), x));
  }
  const geo = new THREE.LatheGeometry(pts, 24); geo.rotateZ(Math.PI / 2);
  const tex = canvasTex(256, 16, (c) => {
    c.fillStyle = '#d8c49a'; c.fillRect(0, 0, 256, 16);
    const col = { black: '#141414', brown: '#6b3a16', red: '#c22a1f', orange: '#e2771c', yellow: '#e6c21c', green: '#2a8a38', blue: '#2a50b8', violet: '#7a3fa8', grey: '#8a8a8a', white: '#eeeeee', gold: '#c8a03a' };
    const xs = [46, 78, 108, 196];
    bands.forEach((b, i) => { c.fillStyle = col[b]; c.fillRect(xs[i], 0, i === 3 ? 18 : 16, 16); });
  });
  const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.55 });
  // LatheGeometry UV: u around, v along; we want bands along the axis -> swap via custom uv
  const uv = geo.attributes.uv; for (let i = 0; i < uv.count; i++) { const u = uv.getX(i), v = uv.getY(i); uv.setXY(i, v, u); }
  const body = new THREE.Mesh(geo, mat); body.position.y = lift + R; g.add(body);
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-span / 2, -2.2, 0), new THREE.Vector3(-span / 2, lift + R - 0.6, 0), new THREE.Vector3(-span / 2 + 0.6, lift + R, 0), new THREE.Vector3(-L / 2, lift + R, 0)
  ], false, 'catmullrom', 0.05);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 16, 0.3, 6), M.tin));
  const c2 = curve.clone(); c2.points = c2.points.map(p => new THREE.Vector3(-p.x, p.y, p.z));
  g.add(new THREE.Mesh(new THREE.TubeGeometry(c2, 16, 0.3, 6), M.tin));
  return g;
}
export function led5mmRGB(opts = {}) {
  const g = new THREE.Group();
  const lens = new THREE.MeshPhysicalMaterial({ color: 0xf4f4f4, roughness: 0.55, transmission: 0.35, thickness: 3, emissive: 0x000000 });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(2.5, 28, 14, 0, TAU, 0, Math.PI / 2), lens); dome.position.y = 8.6 - 2.5 + 0.1; g.add(dome);
  g.add(cyl(2.5, 6.1, lens, 28, 0, 0.5));
  g.add(cyl(2.9, 1.0, lens, 28, 0, 0.0));
  const flat = box(0.6, 1.0, 5.8, lens, 2.6, 0, 0); g.add(flat); // flat flange edge
  // 4 legs: R, common anode (longest), G, B at 1.27 mm pitch (bent to 2.54 at the board)
  const legs = [['R', -1.9, 25], ['A', -0.635, 28], ['G', 0.635, 25], ['B', 1.9, 25]];
  for (const [n, x, L] of legs) g.add(cyl(0.22, L, M.tin, 6, x, -L, 0));
  g.userData.lens = lens;
  return g;
}
export function led3mm(opts = {}) {
  const g = new THREE.Group();
  const lens = new THREE.MeshPhysicalMaterial({ color: 0xf6f6f6, roughness: 0.5, transmission: 0.35, thickness: 2, emissive: 0x000000 });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1.5, 24, 12, 0, TAU, 0, Math.PI / 2), lens); dome.position.y = 4.3; g.add(dome);
  g.add(cyl(1.5, 4.3, lens, 24, 0, 0.0));
  g.add(cyl(1.8, 0.8, lens, 24, 0, 0.0));
  g.add(cyl(0.2, 27, M.tin, 6, -1.27, -27, 0));
  g.add(cyl(0.2, 25, M.tin, 6, 1.27, -25, 0));
  g.userData.lens = lens;
  return g;
}
export function reedSwitch() {
  // Littelfuse MDSR-7: 7 mm glass envelope, 1.8 mm dia, leads
  const g = new THREE.Group();
  const geo = new THREE.CapsuleGeometry(0.9, 5.6, 8, 20); geo.rotateZ(Math.PI / 2);
  g.add(new THREE.Mesh(geo, new THREE.MeshPhysicalMaterial({ color: 0xe6f2f0, roughness: 0.05, transmission: 0.9, thickness: 0.4, transparent: true, opacity: 0.45 })));
  for (const s of [-1, 1]) {
    const reed = box(3.6, 0.08, 0.5, M.nickel, s * 1.4, -0.04, 0); g.add(reed);
    const lead = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 9, 8), M.tin); lead.rotation.z = Math.PI / 2; lead.position.x = s * 8.0; g.add(lead);
  }
  g.add(box(1.6, 0.06, 0.4, colorMat(0xb98a45, { metalness: 0.8 }), 0, -0.03, 0));
  return g;
}
export function pt1000() {
  // TE PTFM102T1A0 thin-film element: 2.0 x 2.3 x 1.0 mm alumina chip, glass glaze, two 10 mm leads
  const g = new THREE.Group();
  g.add(box(2.3, 0.65, 2.0, colorMat(0xf1efe9, { roughness: 0.7 })));
  g.add(box(1.7, 0.08, 1.6, new THREE.MeshPhysicalMaterial({ color: 0xe8e2c8, roughness: 0.1, transmission: 0.3, transparent: true, opacity: 0.7 }), -0.1, 0.65, 0));
  g.add(box(0.5, 0.75, 1.9, colorMat(0xd8d2c0), 0.95, 0, 0));
  for (const z of [-0.5, 0.5]) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 10, 6), M.nickel); l.rotation.z = Math.PI / 2; l.position.set(6.1, 0.35, z); g.add(l); }
  return g;
}
export function fuseRadial() {
  // Littelfuse RXEF110 PTC: yellow disc, 5.1 mm lead spacing
  const g = new THREE.Group();
  const disc = rbox(9.5, 3.0, 9.0, 3.5, colorMat(0xe8b81f, { roughness: 0.45 }));
  disc.rotation.x = Math.PI / 2; disc.position.set(0, 8.5, 1.5); g.add(disc);
  const d = new THREE.Mesh(new THREE.PlaneGeometry(6, 2.4), new THREE.MeshStandardMaterial({ map: labelTex('X110', { fg: '#2a2a2a', font: 'bold 46px Arial' }), transparent: true, depthWrite: false }));
  d.position.set(0, 8.5, 1.52 + 0.01); g.add(d);
  for (const s of [-1, 1]) {
    const c = new THREE.CatmullRomCurve3([new THREE.Vector3(s * 2.54, -2.2, 0), new THREE.Vector3(s * 2.54, 2.2, 0), new THREE.Vector3(s * 1.6, 4.0, 0), new THREE.Vector3(s * 1.6, 5.2, 0)]);
    g.add(new THREE.Mesh(new THREE.TubeGeometry(c, 10, 0.3, 6), M.tin));
  }
  return g;
}
export function coinCell(r = 6.25, h = 2.0) {
  const g = new THREE.Group();
  g.add(cyl(r, h, M.steel, 40));
  g.add(topDecal(r * 1.4, r * 0.7, labelTex('CR1220\n3V', { w: 256, h: 128, fg: '#3a3a3a', font: 'bold 40px Arial' }), h));
  return g;
}
export function nylonStandoff(h = 12, thread = 6) {
  const g = new THREE.Group();
  const hex = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, h, 6), M.nylon); hex.position.y = h / 2; g.add(hex);
  const th = cyl(1.2, thread, M.nylon, 12, 0, h); g.add(th);
  return g;
}
export function nylonNut() {
  const g = new THREE.Group();
  const hex = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 2.0, 6), M.nylon); hex.position.y = 1.0; g.add(hex);
  return g;
}
export function nylonScrewHead() {
  const g = new THREE.Group();
  const head = new THREE.Mesh(new THREE.SphereGeometry(2.3, 16, 8, 0, TAU, 0, Math.PI / 2), M.nylon); head.scale.y = 0.6; g.add(head);
  g.add(box(3.2, 0.3, 0.5, colorMat(0xd8d3c2), 0, 1.2, 0));
  g.add(box(0.5, 0.3, 3.2, colorMat(0xd8d3c2), 0, 1.2, 0));
  return g;
}
export function solderFillet(r = 0.9) {
  const geo = new THREE.ConeGeometry(r, 1.0, 14, 1, true); geo.translate(0, 0.5, 0);
  const m = new THREE.Mesh(geo, M.solder); return m;
}
export function solderBlob(w = 1.4, h = 0.5) {
  const m = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 8, 0, TAU, 0, Math.PI / 2), M.solder);
  m.scale.set(w / 2, h, w / 2.6); return m;
}

// ------------------------------------------------------------------ wires and cables
export function wireMesh(curve, radius, color, opts = {}) {
  const len = curve.getLength();
  const seg = Math.max(12, Math.min(400, Math.round(len / 1.5)));
  const geo = new THREE.TubeGeometry(curve, seg, radius, opts.radial || 7, false);
  const mat = new THREE.MeshStandardMaterial({ color, roughness: opts.rough ?? 0.6, metalness: 0 });
  const m = new THREE.Mesh(geo, mat);
  m.userData.len = len; m.userData.baseColor = new THREE.Color(color);
  return m;
}
export function dupontHousing(kind) {
  // 2.54 mm Dupont single housing: female (socket) or male (pin out)
  const g = new THREE.Group();
  const L = 14.0;
  const b = box(2.5, L, 2.5, M.blackGloss); b.position.y = 0; g.add(b);
  if (kind === 'M') {
    const pin = cyl(0.32, 6, M.gold, 8, 0, -6); g.add(pin);
  } else {
    const hole = box(1.0, 0.05, 1.0, colorMat(0x000000), 0, -0.02, 0); g.add(hole);
  }
  g.add(box(0.8, 3, 0.3, M.tin, 0, L - 4.5, 1.27)); // latch window detail
  g.userData.len = L;
  return g;
}
export function qtPlug() {
  // JST SH 4-pin plug: local +x = insertion direction
  const g = new THREE.Group();
  g.add(box(4.2, 2.6, 5.4, M.black, 0, -1.3, 0));
  g.add(box(1.2, 0.6, 3.0, colorMat(0x232323), -1.0, 1.3, 0));
  return g;
}
export function jstphPlug() {
  const g = new THREE.Group();
  g.add(box(6.0, 4.2, 5.8, M.natural, 0, -2.1, 0));
  g.add(box(2.0, 1.0, 4.2, colorMat(0xe2d9c0), -1.6, 2.1, 0));
  return g;
}
export function picoBladePlug(n = 7) {
  const g = new THREE.Group();
  const W = 1.25 * (n - 1) + 2.6;
  g.add(box(3.2, 3.4, W, M.natural, 0, -1.7, 0));
  for (let i = 0; i < n; i++) g.add(box(0.4, 0.4, 0.5, M.tin, 1.6, 0, (i - (n - 1) / 2) * 1.25));
  return g;
}
export function heatShrink(len = 10, r = 0.9, color = 0x111112) {
  const g = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 12), colorMat(color, { roughness: 0.8 }));
  return g;
}
