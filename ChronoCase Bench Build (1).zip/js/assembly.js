// Bench assembly: where every part sits, every wire, and the one-action-per-step build sequence.
import * as THREE from 'three';
import * as X from './models.js';
import * as D from './devices.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);

export class Bench {
  constructor(scene, specs) {
    this.scene = scene; this.specs = specs;
    this.root = new THREE.Group(); scene.add(this.root);
    this.parts = {};    // id -> { obj, label, ref, step }
    this.items = [];    // every revealable object: { obj, step, anim, kind }
    this.wires = {};    // id -> wire record
    this.steps = [];
    this.testPoints = {}; // name -> { get():Vector3, net, label }
  }
  // ------------------------------------------------------------------ registry helpers
  add(id, obj, label, ref, pos, rotY = 0) {
    obj.position.copy(pos); obj.rotation.y = rotY; obj.name = id;
    this.root.add(obj); obj.updateMatrixWorld(true);
    this.parts[id] = { id, obj, label, ref };
    return obj;
  }
  P(id) { return this.parts[id].obj; }
  hole(pp, row, col) { const b = this.P(pp); return b.localToWorld(b.userData.hole(row, col).clone()); }
  pinWorld(id, pin) {
    const o = this.P(id); const p = o.userData.pins?.[pin];
    if (!p) throw new Error(`no pin ${id}.${pin}`);
    o.updateMatrixWorld(true);
    const pos = o.localToWorld(p.p.clone());
    const q = new THREE.Quaternion(); o.getWorldQuaternion(q);
    return { pos, dir: p.dir.clone().applyQuaternion(q), kind: p.kind };
  }
  // ------------------------------------------------------------------ end frames for wires
  endFrame(e) {
    if (e.local) {
      const o = this.P(e.p); o.updateMatrixWorld(true);
      const q = new THREE.Quaternion(); o.getWorldQuaternion(q);
      return { pos: o.localToWorld(e.local.clone()), dir: e.ldir.clone().applyQuaternion(q).normalize(), style: e.style || 'free' };
    }
    if (e.pt) return { pos: e.pt.clone(), dir: (e.dir || UP).clone(), style: e.style || 'free' };
    if (e.h) {
      const pos = this.hole(e.p, e.h[0], e.h[1]);
      return { pos: pos.add(V(0, 0.15, 0)), dir: UP.clone(), style: 'hole', hole: pos.clone() };
    }
    const w = this.pinWorld(e.p, e.pin);
    if (w.kind === 'socket') return { pos: w.pos.clone().add(V(0, 14, 0)), dir: UP.clone(), style: 'male', at: w.pos };
    if (w.kind === 'pin') return { pos: w.pos.clone().add(V(0, 5.5, 0)), dir: UP.clone(), style: 'female', at: w.pos };
    if (w.kind === 'rpin') return { pos: w.pos.clone().addScaledVector(w.dir, 8.5), dir: w.dir, style: 'femaleH', at: w.pos };
    if (w.kind === 'qt') return { pos: w.pos.clone().addScaledVector(w.dir, 3.4), dir: w.dir, style: 'qt', at: w.pos };
    if (w.kind === 'jstph') return { pos: w.pos.clone().addScaledVector(w.dir, 5.0), dir: w.dir, style: 'jstph', at: w.pos };
    if (w.kind === 'hole') return { pos: w.pos.clone().add(V(0, 0.15, 0)), dir: UP.clone(), style: 'hole', hole: w.pos.clone() };
    if (w.kind === 'term') return { pos: w.pos.clone().addScaledVector(w.dir, 0.5), dir: w.dir, style: 'term', at: w.pos };
    if (w.kind === 'lug') return { pos: w.pos.clone(), dir: w.dir, style: 'lug' };
    if (w.kind === 'tail') return { pos: w.pos.clone(), dir: w.dir, style: 'lug' };
    if (w.kind === 'lead') return { pos: w.pos.clone(), dir: w.dir, style: 'free' };
    if (w.kind === 'pico') return { pos: w.pos.clone().add(V(0, 3.4, 0)), dir: UP.clone(), style: 'pico', at: w.pos };
    if (w.kind === 'usb') return { pos: w.pos.clone().addScaledVector(w.dir, 9), dir: w.dir, style: 'usb', at: w.pos };
    return { pos: w.pos.clone(), dir: w.dir, style: 'free' };
  }
  // ------------------------------------------------------------------ wires
  route(a, b, len, opts = {}) {
    const lead = opts.lead ?? Math.min(14, a.pos.distanceTo(b.pos) * 0.25);
    const arc = (h) => {
      const p0 = a.pos, p1 = b.pos;
      const q0 = p0.clone().addScaledVector(a.dir, lead), q1 = p1.clone().addScaledVector(b.dir, lead);
      const mid = q0.clone().lerp(q1, 0.5); mid.y = Math.max(q0.y, q1.y) + h;
      const pts = [p0, p0.clone().addScaledVector(a.dir, lead * 0.35), q0, mid, q1, p1.clone().addScaledVector(b.dir, lead * 0.35), p1];
      return new THREE.CatmullRomCurve3(pts, false, 'centripetal');
    };
    if (!len) return arc(opts.h ?? Math.min(30, 3 + a.pos.distanceTo(b.pos) * 0.12));
    // fixed-length cable: it droops to the bench and takes up slack in a sideways loop, like a real lead
    const gy = opts.ground ?? 0.9;
    const flat = new THREE.Vector3(b.pos.x - a.pos.x, 0, b.pos.z - a.pos.z);
    const dist = flat.length(); flat.normalize();
    const perp = new THREE.Vector3(-flat.z, 0, flat.x).multiplyScalar(opts.sideSign ?? (hash(opts.id || '') % 2 ? 1 : -1));
    const build = (h) => {
      const p0 = a.pos, p1 = b.pos;
      const L0 = Math.max(6, lead), q0 = p0.clone().addScaledVector(a.dir, L0), q1 = p1.clone().addScaledVector(b.dir, L0);
      const drop0 = Math.min(18, Math.max(4, (q0.y - gy) * 0.6)), drop1 = Math.min(18, Math.max(4, (q1.y - gy) * 0.6));
      const g0 = new THREE.Vector3(q0.x, gy, q0.z).addScaledVector(flat, drop0 + 4);
      const g1 = new THREE.Vector3(q1.x, gy, q1.z).addScaledVector(flat, -(drop1 + 4));
      const m0 = g0.clone().lerp(g1, 0.2).addScaledVector(perp, h), m1 = g0.clone().lerp(g1, 0.8).addScaledVector(perp, h);
      const pts = h > 8 ? [p0, q0, g0, m0, m1, g1, q1, p1] : [p0, q0, g0, g0.clone().lerp(g1, 0.5).addScaledVector(perp, h), g1, q1, p1];
      if (dist < 25) pts.splice(2, 3, new THREE.Vector3((q0.x + q1.x) / 2, gy, (q0.z + q1.z) / 2).addScaledVector(perp, h));
      return new THREE.CatmullRomCurve3(pts, false, 'centripetal', 0.5);
    };
    let c = build(0);
    if (c.getLength() >= len) { const c2 = arc(0); return c2.getLength() <= len || c.getLength() > c2.getLength() ? c2 : c; }
    let lo = 0, hi = len;
    for (let i = 0; i < 28; i++) { const m = (lo + hi) / 2; c = build(m); if (c.getLength() < len) lo = m; else hi = m; }
    return c;
  }
  wire(id, a, b, o) {
    const fa = this.endFrame(a), fb = this.endFrame(b);
    if (o.off !== undefined && fa.style === 'pico') { fa.pos.x += o.off * 1.25; if (o.off !== 0) fa.style = 'none'; fa.at = fa.at.clone(); }
    const g = new THREE.Group(); g.name = id;
    const radius = { awg30: 0.33, jumper: 0.6, qt: 0.45, jst: 0.55, pico: 0.4, usb: 1.6, rtd: 0.33 }[o.kind || 'awg30'];
    const curve = this.podRoute ? this.podRoute(fa, fb, { ...o, id }) : this.route(fa, fb, o.len, { ...o, id });
    let tube;
    if (o.kind === 'qt' || o.kind === 'pico4') {
      // four conductors laid side by side: black, red, blue, yellow
      const cols = [0x111111, 0xc8241c, 0x1f5fd0, 0xe8c51a];
      const N = 90, pts = curve.getSpacedPoints(N);
      const sides = pts.map((p, k) => { const t = curve.getTangentAt(k / N); let sd = new THREE.Vector3().crossVectors(t, UP); if (sd.lengthSq() < 0.05) sd.set(1, 0, 0).cross(t); return sd.normalize(); });
      cols.forEach((c, i) => {
        const off = (i - 1.5) * 0.95;
        const p2 = pts.map((p, k) => p.clone().addScaledVector(sides[k], off));
        const cc = new THREE.CatmullRomCurve3(p2);
        const m = X.wireMesh(cc, 0.45, c); g.add(m);
      });
      tube = g.children[0];
    } else if (o.twin) {
      const N = 120, pts = curve.getSpacedPoints(N), frames = curve.computeFrenetFrames(N, false);
      for (const s of [0, Math.PI]) {
        const p2 = pts.map((p, k) => p.clone().addScaledVector(frames.normals[k], Math.cos(k * 0.55 + s) * 0.38).addScaledVector(frames.binormals[k], Math.sin(k * 0.55 + s) * 0.38));
        const m = X.wireMesh(new THREE.CatmullRomCurve3(p2), radius, o.color); g.add(m);
      }
      tube = g.children[0];
    } else {
      tube = X.wireMesh(curve, radius, o.color); g.add(tube);
    }
    // terminations
    for (const f of [fa, fb]) this.termination(g, f, o, curve, f === fa);
    if (o.chain) {
      // two extension jumpers joined: male end pushed into the next female housing at mid-length
      const t = 0.5, p = curve.getPointAt(t), tg = curve.getTangentAt(t);
      const h = new THREE.Group(); h.add(X.box(2.5, 26, 2.5, X.M.blackGloss, 0, -13, 0));
      h.position.copy(p); h.quaternion.setFromUnitVectors(UP, tg); g.add(h);
    }
    if (o.splice) {
      const t = o.splice, p = curve.getPointAt(t), tg = curve.getTangentAt(t);
      const s = X.heatShrink(14, radius + 0.55, 0x111112); s.position.copy(p); s.quaternion.setFromUnitVectors(UP, tg); g.add(s);
    }
    if (o.inlineR) {
      const t = o.inlineR.t, p = curve.getPointAt(t), tg = curve.getTangentAt(t);
      const r = X.axialResistor(o.inlineR.bands, { span: 6.3, lift: -1.2 }); r.children.slice(1).forEach(c => c.visible = false);
      const holder = new THREE.Group(); holder.add(r); r.rotation.z = Math.PI / 2; r.position.set(0, 0, 0);
      const sl = new THREE.Mesh(new THREE.CylinderGeometry(1.75, 1.75, 12, 16), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, transparent: true, opacity: 0.55, roughness: 0.8 }));
      holder.add(sl);
      holder.position.copy(p); holder.quaternion.setFromUnitVectors(UP, tg); g.add(holder);
    }
    (this.parentFor ? this.parentFor(a, b) : this.root).add(g);
    const rec = { id, obj: g, curve, tube, a, b, ...o, fa, fb, len: curve.getLength(), args: [a, b, o] };
    this.wires[id] = rec;
    return rec;
  }
  rebuild(id) {
    const old = this.wires[id]; const vis = old.obj.visible;
    old.obj.parent?.remove(old.obj);
    old.obj.traverse(m => { if (m.geometry) m.geometry.dispose(); });
    const rec = this.wire(id, ...old.args); rec.obj.visible = vis; return rec;
  }
  termination(g, f, o, curve, isStart) {
    const put = (obj, pos, dir) => { obj.position.copy(pos); obj.quaternion.setFromUnitVectors(UP, dir.clone().normalize()); g.add(obj); };
    if (f.style === 'male') { const h = X.dupontHousing('M'); put(h, f.at.clone().add(V(0, 0.2, 0)), UP); }
    else if (f.style === 'female') { const h = X.dupontHousing('F'); put(h, f.at.clone().add(V(0, -8.5, 0)), UP); }
    else if (f.style === 'femaleH') { const h = X.dupontHousing('F'); put(h, f.at.clone().addScaledVector(f.dir, -5.5), f.dir); }
    else if (f.style === 'qt') {
      const p = X.qtPlug(); const q = new THREE.Group(); q.add(p); p.position.y = 0;
      q.position.copy(f.at.clone().addScaledVector(f.dir, 0.6)); q.quaternion.setFromUnitVectors(V(1, 0, 0), f.dir.clone().normalize()); g.add(q);
    } else if (f.style === 'jstph') {
      const p = X.jstphPlug(); const q = new THREE.Group(); q.add(p);
      q.position.copy(f.at.clone().addScaledVector(f.dir, 1.5)); q.quaternion.setFromUnitVectors(V(1, 0, 0), f.dir.clone().normalize()); g.add(q);
    } else if (f.style === 'pico') { const p = X.picoBladePlug(7); p.rotation.y = Math.PI / 2; const q = new THREE.Group(); q.add(p); put(q, f.at.clone().add(V(0, 3.4, 0)), UP); }
    else if (f.style === 'hole') {
      // insulation stops 1 mm above the hole; bright stripped tip goes in; solder fillet underneath appears on the solder step
      const tip = X.cyl(0.18, 3.6, X.M.copper, 6); tip.position.copy(f.hole.clone().add(V(0, -2.4, 0))); g.add(tip);
      const fil = X.solderFillet(0.85); fil.rotation.x = Math.PI; fil.position.copy(f.hole.clone().add(V(0, -1.6 + 0.0, 0))); fil.scale.y = 0.9; g.add(fil);
    } else if (f.style === 'free' && o.kind === 'qt') {
      const s = X.heatShrink(12, 2.6, 0x111112); put(s, f.pos.clone().addScaledVector(f.dir, -5), f.dir);
    } else if (f.style === 'lug') {
      const b = X.solderBlob(1.6, 0.9); b.position.copy(f.pos); g.add(b);
    } else if (f.style === 'usb') {
      const p = new THREE.Group(); p.add(X.box(6.8, 1.8, 9, X.M.steel, 0, -0.9, 4.5)); p.add(X.rbox(10.5, 6.5, 16, 2.5, X.M.blackGloss)); p.children[1].rotation.x = Math.PI / 2; p.children[1].position.set(0, 0, 17);
      p.position.copy(f.at); p.quaternion.setFromUnitVectors(V(0, 0, 1), f.dir.clone().normalize()); g.add(p);
    }
  }
}

// =========================================================================== the build
export async function buildBench(scene, specs) {
  const B = new Bench(scene, specs);
  const S = specs;
  // ---------------------------------------------------------------- parts at their final bench positions
  // nRF5340 DK on four 12 mm standoffs
  const dk = B.add('dk', D.makeDK(), 'nRF5340 DK', 'A1', V(-68, 12, -40));
  D.setSlide(dk.userData.sw9, -1); D.setSlide(dk.userData.sw10, 1); D.setSlide(dk.userData.swPower, 1);
  const pp1 = B.add('pp1', D.makePermaProto(S.permaproto, 'pp1'), 'Perma-Proto #1 · power & light board', 'A11', V(0, 6, 15));
  const pp2 = B.add('pp2', D.makePermaProto(S.permaproto, 'pp2'), 'Perma-Proto #2 · SPI backbone', 'A11', V(-10, 6, -150));
  const pp3 = B.add('pp3', D.makePermaProto(S.permaproto, 'pp3'), 'Perma-Proto #3 · dock board', 'A11', V(250, 6, 130));
  const ada = (id, kind, label, ref, cx, cz, rotY = 0, y = 6) => {
    const sp = S[kind]; const [x0, y0, x1, y1] = sp.bbox; const w = x1 - x0, d = y1 - y0;
    const o = D.makeAdafruit(kind, sp);
    // rotate about the board centre
    const c = V(-w / 2, 0, d / 2).applyAxisAngle(UP, rotY);
    return B.add(id, o, label, ref, V(cx + c.x, y, cz + c.z), rotY);
  };
  ada('as7341', 'as7341', 'AS7341 colour sensor', 'B1', 60, -150);
  ada('lsm6', 'lsm6dsox', 'LSM6DSOX IMU', 'B3', 115, -150);
  ada('h3lis', 'h3lis331', 'H3LIS331 high-g accelerometer', 'B4', 170, -150);
  ada('bme', 'bme688', 'BME688 gas sensor', 'B2', 240, -150);
  ada('rtc', 'pcf8523', 'PCF8523 real-time clock', 'B5', 295, -150);
  ada('gauge', 'max17048', 'MAX17048 fuel gauge', 'A4', 190, -40, -Math.PI / 2);
  ada('chg', 'bq24074', 'bq24074 LiPo charger', 'A6', 200, 30);
  ada('boost', 'miniboost', 'MiniBoost 5 V', 'A10', 0, 0, 0, 0); // placed on PP1 below
  ada('core', 'max31865', 'MAX31865 · CORE (CS = D10)', 'C1', 0, 0, 0, 0);
  ada('amb', 'max31865', 'MAX31865 · AMB (CS = D9)', 'C1', 0, 0, 0, 0);
  const bat = B.add('bat', D.makeBattery(), 'LiPo 3.7 V 2,500 mAh', 'A3', V(270, 0, -40), Math.PI / 2);
  const nfc = B.add('nfc', D.makeNFC(), 'ST25R3916B NFC module', 'C3', V(-121.4, 6, -130), 0);
  const tog = B.add('tog', await D.makeToggle(), 'Mini SPDT toggle switch', 'A7', V(130, 18, 40), 0);
  const magPod = B.add('magPod', await D.makeMagnetic('pads'), 'Magnetic connector · pod half', 'B14', V(250, 2.4, 75), 0);
  const magDock = B.add('magDock', await D.makeMagnetic('pins'), 'Magnetic connector · dock half', 'B14', V(0, 0, 0), 0);
  const pi = B.add('pi', D.makePiZero(S.pizero), 'Raspberry Pi Zero 2 W', 'B10', V(215, 6, 215), 0);

  // MiniBoost on PP1: header pins at E20..E23 (VIN, GND, 5V, EN); board 2.5 mm above PP1 on the header plastic
  {
    const p = B.hole('pp1', 'E', 20); const boost = B.P('boost');
    // board pad VIN is at local x=1.9, y=2.54 -> origin = hole - (1.9, 0, -2.54)
    boost.position.set(p.x - 1.9, p.y + 2.5, p.z + 2.54); boost.updateMatrixWorld(true);
  }
  // MAX31865s on PP2: VIN at E2 (core) and E13 (amb); pad VIN at local (3.81, 2.67)
  for (const [id, col] of [['core', 2], ['amb', 13]]) {
    const p = B.hole('pp2', 'E', col); const o = B.P(id);
    o.position.set(p.x - 3.81, p.y + 2.5, p.z + 2.67); o.updateMatrixWorld(true);
  }
  // dock half: tails in PP3 J13..J17 (pin 1 at J13)
  { const p = B.hole('pp3', 'J', 15); magDock.position.set(p.x, p.y, p.z); magDock.updateMatrixWorld(true); }

  {
    const chg = B.P('chg'); const t = chg.userData.top;
    const cut = X.box(0.25, 0.06, 1.3, new THREE.MeshStandardMaterial({ color: 0xc8d0d8, metalness: 1, roughness: 0.2 }));
    cut.position.set(20.574, t, -8.636); chg.add(cut); B.parts.cut1a = { id: 'cut1a', obj: cut, label: 'Cut 1.0A trace', ref: '' };
    const blob = X.solderBlob(1.6, 0.45); blob.position.set(20.574, t, -6.35); chg.add(blob); B.parts.blob05 = { id: 'blob05', obj: blob, label: 'Solder bridge 0.5A', ref: '' };
    B.chgJumpers = () => chg.localToWorld(V(20.574, t, -8.0));
  }
  // ---------------------------------------------------------------- through-hole parts on the Perma-Protos
  const at = (pp, r, c) => B.hole(pp, r, c);
  const thPart = (id, obj, label, ref, pos, rotY = 0) => B.add(id, obj, label, ref, pos, rotY);
  thPart('ldo', X.to92('1700\n3302E'), 'MCP1700-3302E 3.3 V LDO', 'A8', at('pp1', 'C', 11), 0);
  thPart('cin', X.radialCap({ color: 0x2a64b8 }), '1 µF input capacitor', 'A9', at('pp1', 'B', 10).lerp(at('pp1', 'B', 11), 0.5), 0);
  thPart('cout', X.radialCap({ color: 0x2a64b8 }), '1 µF output capacitor', 'A9', at('pp1', 'D', 12).lerp(at('pp1', 'D', 13), 0.5), 0);
  const q = [['q1', 3, 'red'], ['q2', 6, 'green'], ['q3', 15, 'blue'], ['q4', 27, 'white']];
  for (const [id, c, col] of q) thPart(id, X.to92('P2N\n2222A'), `PN2222 driver · ${col}`, 'C7', at('pp1', 'I', c), 0);
  const rb = [['rb1', 3], ['rb2', 6], ['rb3', 15], ['rb4', 27]];
  for (const [id, c] of rb) {
    const r = X.axialResistor(['brown', 'black', 'red', 'gold'], { span: 10.16 });
    thPart(id, r, '1 kΩ base resistor', 'C9', at('pp1', 'G', c).lerp(at('pp1', 'E', c), 0.5), Math.PI / 2);
  }
  thPart('rw', X.axialResistor(['red', 'red', 'brown', 'gold'], { span: 12.7 }), '220 Ω white-LED resistor', 'C8', at('pp1', 'C', 28).lerp(B.hole('pp1', 'RB0', 28), 0.5), Math.PI / 2);
  thPart('fuse', X.fuseRadial(), 'RXEF110 resettable fuse', 'B13', at('pp3', 'C', 11).lerp(at('pp3', 'C', 13), 0.5), 0);
  thPart('rtx', X.axialResistor(['brown', 'black', 'red', 'gold'], { span: 10.16 }), '1 kΩ · Pi TX → pod RX', 'C9', at('pp3', 'D', 16).lerp(at('pp3', 'F', 16), 0.5), Math.PI / 2);
  thPart('rrx', X.axialResistor(['brown', 'black', 'red', 'gold'], { span: 10.16 }), '1 kΩ · pod TX → Pi RX (new)', 'C9', at('pp3', 'D', 15).lerp(at('pp3', 'F', 15), 0.5), Math.PI / 2);

  // single male harness pins
  const harness = [
    ['h_p21p', 'pp1', 'A', 12, 'P21 +'], ['h_p21n', 'pp1', 'B', 13, 'P21 −'], ['h_en', 'pp1', 'C', 23, 'EN → D5'],
    ['h_a1', 'pp1', 'B', 3, 'A1 red'], ['h_a2', 'pp1', 'B', 6, 'A2 green'], ['h_a3', 'pp1', 'B', 15, 'A3 blue'], ['h_a4', 'pp1', 'B', 27, 'A4 white'],
    ['h_gnd1', 'pp1', 'RB1', 26, 'GND'],
    ['h_sck', 'pp2', 'D', 5, 'SCK'], ['h_miso', 'pp2', 'D', 6, 'MISO'], ['h_mosi', 'pp2', 'D', 7, 'MOSI'], ['h_cs10', 'pp2', 'D', 8, 'CS core (D10)'], ['h_cs9', 'pp2', 'D', 19, 'CS amb (D9)'],
    ['h_3v3', 'pp2', 'RB0', 26, '3V3 IN'], ['h_gnd2', 'pp2', 'RB1', 26, 'GND IN'],
  ];
  for (const [id, pp, r, c, lab] of harness) {
    const h = X.maleHeader(1); addPinTop(h, 'pin');
    thPart(id, h, `Header pin · ${lab}`, 'A15', at(pp, r, c), 0);
  }
  // single pins on breakout boards (INT lines)
  for (const [id, board, pin] of [['h_i1', 'lsm6', 'I1'], ['h_int3', 'h3lis', 'INT'], ['h_alrt', 'gauge', 'INT']]) {
    const w = B.pinWorld(board, pin); const h = X.maleHeader(1); addPinTop(h, 'pin');
    thPart(id, h, `Header pin · ${B.parts[board].label.split(' ')[0]} ${pin}`, 'A15', w.pos, 0);
  }
  // header strips (MiniBoost 4, MAX31865 8+8)
  {
    const p = B.hole('pp1', 'E', 20); const h = X.maleHeader(4); thPart('hdr_boost', h, '4-pin header (MiniBoost)', 'A15', p, 0);
    for (const [id, col] of [['hdr_core', 2], ['hdr_amb', 13]]) thPart(id, X.maleHeader(8), '8-pin header (MAX31865)', 'A15', B.hole('pp2', 'E', col), 0);
  }
  // standoffs (visual) under boards
  const so = (id, positions, h, label) => {
    const g = new THREE.Group();
    for (const p of positions) { const s = X.nylonStandoff(h, 0); s.position.set(p.x, 0, p.z); g.add(s); const n = X.nylonScrewHead(); n.position.set(p.x, h + 1.6, p.z); g.add(n); }
    B.add(id, g, label, 'A16', V(0, 0, 0));
  };
  const holesW = (id) => {
    const o = B.P(id); o.updateMatrixWorld(true); const sp = o.userData.spec;
    const hs = (sp.holes || []).map(h => [h.x, h.y]);
    for (const t of sp.th || []) if (t.drill >= 2) hs.push([t.x, t.y]);
    return hs.map(([x, y]) => o.localToWorld(V(x, 0, -y)));
  };
  so('so_dk', holesW('dk').filter((_, i) => [0, 2, 5, 6].includes(i)), 12, 'Four 12 mm nylon standoffs (DK)');
  for (const id of ['pp1', 'pp2', 'pp3']) so('so_' + id, holesW(id), 6, `Two 6 mm nylon standoffs (${B.parts[id].label.split(' · ')[0]})`);
  for (const id of ['as7341', 'lsm6', 'h3lis', 'bme', 'rtc', 'gauge', 'chg', 'pi']) so('so_' + id, holesW(id), 6, `6 mm nylon standoffs (${B.parts[id].label.split(' ')[0]})`);
  so('so_nfc', holesW('nfc'), 6, 'Two 6 mm nylon standoffs (NFC module)');

  // free parts on the bench
  const rgb = X.led5mmRGB(); const stand = (o, h) => { const g = new THREE.Group(); g.add(X.box(14, h, 10, X.colorMat(0x1b1b1c, { roughness: 0.8 }), 0, 0, 0)); o.position.y = h + 0.2; g.add(o); return g; };
  B.add('rgb', stand(rgb, 9), 'RGB LED, common anode (in a scrap-PETG test stand)', 'C5', V(-30, 0, 92));
  B.parts.rgb.lens = rgb.userData.lens;
  const wl = X.led3mm(); B.add('wled', stand(wl, 9), '3 mm white LED (test stand)', 'C6', V(25, 0, 92));
  B.parts.wled.lens = wl.userData.lens;
  const reed = X.reedSwitch(); const reedG = new THREE.Group(); reed.position.y = 1.2; reedG.add(reed);
  B.add('reed', reedG, 'Reed switch MDSR-7', 'C4', V(-100, 0, -118));
  const ptCore = X.pt1000(); B.add('ptcore', ptCore, 'PT1000 element · CORE probe', 'C2', V(-100, 0.5, -215), 0);
  const ptAmb = X.pt1000(); B.add('ptamb', ptAmb, 'PT1000 element · AMB probe', 'C2', V(60, 0.5, -212), Math.PI);
  const kap1 = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.3, 12, 16), X.M.kapton); kap1.rotation.z = Math.PI / 2; const kg1 = new THREE.Group(); kg1.add(kap1); B.add('kap_core', kg1, 'Kapton wrap (core probe)', 'C10', V(-89, 1.8, -215));
  const kap2 = kap1.clone(); const kg2 = new THREE.Group(); kg2.add(kap2); B.add('kap_amb', kg2, 'Kapton wrap (ambient probe)', 'C10', V(49, 1.8, -212));
  B.parts.cr1220 = { id: 'cr1220', obj: B.P('rtc').userData.coin, label: 'CR1220 coin cell', ref: 'B6' };
  // toggle bracket (scrap PETG plate the switch's bushing passes through)
  const br = new THREE.Group(); br.add(X.box(22, 2.5, 22, X.colorMat(0x1b1b1c, { roughness: 0.8 }), 0, 16, 0)); br.add(X.box(22, 16, 2.5, X.colorMat(0x1b1b1c, { roughness: 0.8 }), 0, 0, -9.75));
  B.add('bracket', br, 'Switch test bracket (scrap PETG)', 'D1', V(130, 0, 40));
  // microSD and the Pi supply cable
  const sd = new THREE.Group(); sd.add(X.box(15, 0.7, 11, X.colorMat(0x2a2a2e), 0, 0, 0)); sd.add(X.box(5, 0.02, 9, X.colorMat(0xd23a2a), -4.5, 0.7, 0));
  B.add('sd', sd, 'microSD 32 GB with Raspberry Pi OS Lite', 'B12', V(215 + 4.5, 6 + 1.6 + 0.35, 200));

  // ---------------------------------------------------------------- wires (net + current role drive the electrical view)
  const C = { red: 0xc8241c, black: 0x151515, brown: 0x6b3a16, orange: 0xe2771c, yellow: 0xe8c51a, green: 0x2a8a38, blue: 0x2050c8, purple: 0x7a3fa8, grey: 0x8a8a8a, white: 0xeeeeee };
  const W = (id, a, b, o) => B.wire(id, a, b, o);
  const h = (p, r, c) => ({ p, h: [r, c] });
  const pin = (p, n) => ({ p, pin: n });
  // PP1 power board
  W('w_ldo_gnd', h('pp1', 'A', 10), h('pp1', 'RB1', 10), { color: C.black, net: 'GND', role: 'none' });
  W('w_ldo_vin1', h('pp1', 'E', 11), h('pp1', 'F', 11), { color: C.red, net: 'VSYS', role: 'ldo_in', rev: true });
  W('w_ldo_vin2', h('pp1', 'J', 11), h('pp1', 'RT1', 11), { color: C.red, net: 'VSYS', role: 'ldo_in', rev: true });
  W('w_cout_gnd', h('pp1', 'A', 13), h('pp1', 'RB1', 13), { color: C.black, net: 'GND', role: 'none' });
  W('w_gnd_join1', h('pp1', 'RT0', 1), h('pp1', 'RB1', 1), { color: C.black, net: 'GND', role: 'gnd_ret' });
  W('w_boost_vin', h('pp1', 'D', 20), h('pp1', 'RT1', 18), { color: C.red, net: 'VSYS', role: 'boost_in', rev: true, h: 14 });
  W('w_boost_gnd', h('pp1', 'A', 21), h('pp1', 'RB1', 21), { color: C.black, net: 'GND', role: 'none' });
  W('w_boost_out', h('pp1', 'A', 22), h('pp1', 'RB0', 22), { color: C.red, net: '5V_SW', role: 'v5_out' });
  // charger -> switch -> VSYS, doubled 30 AWG (twisted pair)
  W('w_out_sw', pin('chg', 'OUT'), pin('tog', 'COM'), { color: C.red, net: 'OUT', role: 'sys', twin: true, len: 120 });
  W('w_sw_vsys', pin('tog', 'L1'), h('pp1', 'RT1', 30), { color: C.red, net: 'VSYS', role: 'sys', twin: true, len: 140 });
  W('w_chg_gnd', pin('chg', 'GND'), h('pp1', 'RT0', 29), { color: C.black, net: 'GND', role: 'sys_ret', twin: true, len: 190, rev: true });
  // battery chain
  W('w_bat', pin('bat', 'LEAD'), pin('gauge', 'JST_X2'), { color: C.red, kind: 'jst', net: 'BAT', role: 'bat', len: 70, twinColors: true });
  W('w_jst', pin('gauge', 'JST_X1'), pin('chg', 'JST_BATT'), { color: C.red, kind: 'jst', net: 'BAT', role: 'bat', len: 110 });
  // DK power + EN
  W('j_p21p', pin('h_p21p', 'pin'), pin('dk', 'P21+'), { color: C.red, kind: 'jumper', net: '3V3', role: 'v33', len: 150 });
  W('j_p21n', pin('h_p21n', 'pin'), pin('dk', 'P21-'), { color: C.black, kind: 'jumper', net: 'GND', role: 'v33_ret', len: 150, rev: true });
  W('j_en', pin('h_en', 'pin'), pin('dk', 'D5'), { color: C.orange, kind: 'jumper', net: 'D5', role: 'sig', len: 150, rev: true });
  W('j_gnd1', pin('h_gnd1', 'pin'), pin('dk', 'GND2'), { color: C.black, kind: 'jumper', net: 'GND', role: 'none', len: 150 });
  // PP2 backbone
  W('j_3v3', pin('dk', 'VDD3'), pin('h_3v3', 'pin'), { color: C.red, kind: 'jumper', net: 'VDD', role: 'pp2_3v3', len: 150 });
  W('j_gnd2', pin('dk', 'GND_T'), pin('h_gnd2', 'pin'), { color: C.black, kind: 'jumper', net: 'GND', role: 'none', len: 150 });
  // I2C: QT-to-header cable on the DK, then the chain
  W('qt_dk', pin('as7341', 'QT_L'), { p: 'dk', local: V(23, 28, -35), ldir: V(0, -1, 0) }, { kind: 'qt', net: 'I2C', role: 'i2c', len: 120, h: 30 });
  B.qtFan = { from: V(-45, 40, -75), pins: ['GND1', 'VDD1', 'SDA', 'SCL'] };
  W('qt_1', pin('as7341', 'QT_R'), pin('lsm6', 'QT_L'), { kind: 'qt', net: 'I2C', role: 'i2c', len: 100 });
  W('qt_2', pin('lsm6', 'QT_R'), pin('h3lis', 'QT_L'), { kind: 'qt', net: 'I2C', role: 'i2c', len: 100 });
  W('qt_3', pin('h3lis', 'QT_R'), pin('bme', 'QT_L'), { kind: 'qt', net: 'I2C', role: 'i2c', len: 200 });
  W('qt_4', pin('bme', 'QT_R'), pin('rtc', 'QT_L'), { kind: 'qt', net: 'I2C', role: 'i2c', len: 100 });
  W('qt_5', pin('rtc', 'QT_R'), pin('gauge', 'QT_L'), { kind: 'qt', net: 'I2C', role: 'i2c', len: 200 });
  // interrupt lines (two extension jumpers chained where the run is long)
  W('j_d2', pin('h_i1', 'pin'), pin('dk', 'D2'), { color: C.green, kind: 'jumper', net: 'D2', role: 'sig', len: 300, chain: true });
  W('j_d3', pin('h_int3', 'pin'), pin('dk', 'D3'), { color: C.yellow, kind: 'jumper', net: 'D3', role: 'sig', len: 300, chain: true });
  W('j_a5', pin('h_alrt', 'pin'), pin('dk', 'A5'), { color: C.purple, kind: 'jumper', net: 'A5', role: 'sig', len: 300, chain: true });
  // dock board
  W('w_pi5v', pin('pi', 'GPIO2'), h('pp3', 'A', 11), { color: C.red, net: 'PI5V', role: 'vbus', len: 75 });
  W('w_fuse_x', h('pp3', 'E', 13), h('pp3', 'F', 13), { color: C.red, net: 'VBUS', role: 'vbus' });
  W('w_pigd', pin('pi', 'GPIO6'), h('pp3', 'H', 14), { color: C.black, net: 'GND', role: 'vbus_ret', len: 95, rev: true });
  W('w_pitx', pin('pi', 'GPIO8'), h('pp3', 'A', 16), { color: C.black, net: 'PI_TX', role: 'uart', len: 70 });
  W('w_pirx', pin('pi', 'GPIO10'), h('pp3', 'A', 15), { color: C.black, net: 'PI_RX', role: 'uart', len: 70 });
  W('w_detect', h('pp3', 'H', 17), h('pp3', 'I', 14), { color: C.black, net: 'GND', role: 'none' });
  // pod half of the dock link
  W('w_m1', pin('magPod', 'P1'), pin('chg', 'VBUS'), { color: C.red, net: 'VBUS', role: 'vbus', len: 110 });
  W('w_m2', pin('magPod', 'P2'), pin('chg', 'GND3'), { color: C.black, net: 'GND', role: 'vbus_ret', len: 110, rev: true });
  W('w_m3', pin('magPod', 'P3'), pin('dk', 'D1'), { color: C.black, net: 'D1', role: 'uart', len: 420, splice: 0.93 });
  W('w_m4', pin('magPod', 'P4'), pin('dk', 'D0'), { color: C.black, net: 'D0', role: 'uart', len: 420, splice: 0.93 });
  W('w_m5', pin('magPod', 'P5'), pin('dk', 'A0'), { color: C.black, net: 'A0', role: 'sig', len: 360, splice: 0.93 });
  // SPI backbone
  for (const [id, a, b, net] of [['w_core_vin', ['A', 2], ['RB0', 2], 'VDD'], ['w_core_gnd', ['A', 3], ['RB1', 3], 'GND'], ['w_amb_vin', ['A', 13], ['RB0', 13], 'VDD'], ['w_amb_gnd', ['A', 14], ['RB1', 14], 'GND']])
    W(id, h('pp2', ...a), h('pp2', ...b), { color: net === 'GND' ? C.black : C.red, net, role: net === 'GND' ? 'none' : 'rtd_sup', rev: net !== 'GND' });
  W('w_bus_sck', h('pp2', 'B', 5), h('pp2', 'B', 16), { color: C.black, net: 'SCK', role: 'spi', h: 6 });
  W('w_bus_miso', h('pp2', 'B', 6), h('pp2', 'B', 17), { color: C.black, net: 'MISO', role: 'spi', h: 8 });
  W('w_bus_mosi', h('pp2', 'B', 7), h('pp2', 'B', 18), { color: C.black, net: 'MOSI', role: 'spi', h: 10 });
  W('j_sck', pin('dk', 'D13'), pin('h_sck', 'pin'), { color: C.blue, kind: 'jumper', net: 'SCK', role: 'spi', len: 150 });
  W('j_miso', pin('h_miso', 'pin'), pin('dk', 'D12'), { color: C.green, kind: 'jumper', net: 'MISO', role: 'spi', len: 150 });
  W('j_mosi', pin('dk', 'D11'), pin('h_mosi', 'pin'), { color: C.yellow, kind: 'jumper', net: 'MOSI', role: 'spi', len: 150 });
  W('j_cs10', pin('dk', 'D10'), pin('h_cs10', 'pin'), { color: C.orange, kind: 'jumper', net: 'D10', role: 'sig', len: 150 });
  W('j_cs9', pin('dk', 'D9'), pin('h_cs9', 'pin'), { color: C.brown, kind: 'jumper', net: 'D9', role: 'sig', len: 150 });
  // RTD probes (4-wire: two wires per element lead; core in red/white pair colours, amb in blue/white)
  const rtd = (pfx, board, el, len, c1, c2) => {
    const leadA = { p: el, local: V(11.0, 0.35, -0.5), ldir: V(1, 0, 0) }, leadB = { p: el, local: V(11.0, 0.35, 0.5), ldir: V(1, 0, 0) };
    W(pfx + '_fp', leadA, pin(board, 'F+'), { color: c1, kind: 'rtd', net: pfx + '_F+', role: 'rtd_f', len: len });
    W(pfx + '_rp', leadA, pin(board, 'RTD+'), { color: c1, kind: 'rtd', net: pfx + '_R+', role: 'none', len: len + 4 });
    W(pfx + '_rn', leadB, pin(board, 'RTD-'), { color: c2, kind: 'rtd', net: pfx + '_R-', role: 'none', len: len + 8 });
    W(pfx + '_fn', leadB, pin(board, 'F-'), { color: c2, kind: 'rtd', net: pfx + '_F-', role: 'rtd_f', len: len + 12, rev: true });
  };
  // NFC pigtail: 7 wires spliced to 30 AWG
  W('n_irq', pin('nfc', 'CONN'), pin('dk', 'D6'), { color: C.black, kind: 'pico', net: 'D6', role: 'sig', len: 190, splice: 0.25, off: -3 });
  W('n_cs', pin('nfc', 'CONN'), pin('dk', 'D7'), { color: C.black, kind: 'pico', net: 'D7', role: 'sig', len: 195, splice: 0.25, off: -2 });
  W('n_sck', pin('nfc', 'CONN'), h('pp2', 'C', 5), { color: C.black, kind: 'pico', net: 'SCK', role: 'spi', len: 110, splice: 0.35, off: -1 });
  W('n_mosi', pin('nfc', 'CONN'), h('pp2', 'C', 7), { color: C.black, kind: 'pico', net: 'MOSI', role: 'spi', len: 115, splice: 0.35, off: 0 });
  W('n_miso', pin('nfc', 'CONN'), h('pp2', 'C', 6), { color: C.black, kind: 'pico', net: 'MISO', role: 'spi', len: 112, splice: 0.35, off: 1 });
  W('n_5v', pin('nfc', 'CONN'), h('pp1', 'RB0', 2), { color: C.red, kind: 'pico', net: '5V_SW', role: 'nfc', len: 280, splice: 0.15, off: 2, rev: true });
  W('n_gnd', pin('nfc', 'CONN'), h('pp1', 'RB1', 3), { color: C.black, kind: 'pico', net: 'GND', role: 'nfc_ret', len: 280, splice: 0.15, off: 3 });
  // reed switch
  const reedPos = B.P('reed').position;
  W('w_reed1', { p: 'reed', local: V(12.5, 1.2, 0), ldir: V(1, 0, 0) }, pin('dk', 'D4'), { color: C.black, net: 'D4', role: 'sig', len: 210, splice: 0.92 });
  W('w_reed2', { p: 'reed', local: V(-12.5, 1.2, 0), ldir: V(-1, 0, 0) }, h('pp2', 'RB1', 28), { color: C.black, net: 'GND', role: 'none', len: 200 });
  // LED drivers on PP1
  for (const [i, c] of [[1, 3], [2, 6], [3, 15], [4, 27]]) {
    W('w_e' + i, h('pp1', 'J', c - 1), h('pp1', 'RT0', c - 1), { color: C.black, net: 'GND', role: 'led_ret' + i });
    W('j_a' + i, pin('h_a' + i, 'pin'), pin('dk', 'A' + i), { color: [0, C.red, C.green, C.blue, C.white][i], kind: 'jumper', net: 'A' + i, role: 'base' + i, len: 150, rev: true });
  }
  const rgbP = B.P('rgb'); rgbP.updateMatrixWorld(true);
  const leg = (dx) => ({ p: 'rgb', local: V(dx * 1.6, 4.5, -5.2), ldir: V(0, 0, -1) });
  W('w_rgb_a', leg(-0.635), h('pp1', 'RB0', 30), { color: C.red, net: '5V_SW', role: 'led_a', len: 110, rev: true });
  W('w_rgb_r', leg(-1.9), h('pp1', 'J', 4), { color: C.black, net: 'LED_R', role: 'led1', len: 250, inlineR: { t: 0.12, bands: ['red', 'red', 'brown', 'gold'] } });
  W('w_rgb_g', leg(0.635), h('pp1', 'J', 7), { color: C.black, net: 'LED_G', role: 'led2', len: 250, inlineR: { t: 0.12, bands: ['red', 'red', 'brown', 'gold'] } });
  W('w_rgb_b', leg(1.9), h('pp1', 'J', 16), { color: C.black, net: 'LED_B', role: 'led3', len: 250, inlineR: { t: 0.12, bands: ['red', 'red', 'brown', 'gold'] } });
  const wP = B.P('wled'); wP.updateMatrixWorld(true);
  W('w_wl_a', { p: 'wled', local: V(-2.0, 4.5, -5.2), ldir: V(0, 0, -1) }, h('pp1', 'A', 28), { color: C.red, net: 'LED_WA', role: 'led4', len: 110, rev: true });
  W('w_wl_k', { p: 'wled', local: V(2.0, 4.5, -5.2), ldir: V(0, 0, -1) }, h('pp1', 'J', 28), { color: C.black, net: 'LED_W', role: 'led4', len: 250 });
  rtd('core', 'core', 'ptcore', 250, 0xc8241c, 0xf0f0f0);
  rtd('amb', 'amb', 'ptamb', 150, 0x2050c8, 0xf0f0f0);
  // USB cable for flashing (visible only on the flashing steps)
  W('usb', pin('dk', 'USB_IF'), { pt: V(-180, 0.8, -60), dir: V(1, 0, 0) }, { kind: 'usb', color: 0x1c1c1c, net: 'USB', role: 'none', len: 150 });
  W('usb_pi', pin('pi', 'PWR_IN'), { p: 'pi', local: V(54, 0.8, 115), ldir: V(0, 0, -1) }, { kind: 'usb', color: 0xf2f2f2, net: 'PI5V', role: 'pi_in', len: 120, rev: true });

  // QT-to-header fan-out: four single wires with male pins into the DK sockets
  {
    const from = V(-45, 40, -75);
    const cols = { GND1: C.black, VDD1: C.red, SDA: C.blue, SCL: C.yellow };
    for (const [n, c] of Object.entries(cols))
      W('qt_' + n, { p: 'dk', local: V(23, 28, -35), ldir: V(0, -1, 0) }, pin('dk', n), { color: c, kind: 'jumper', net: n === 'GND1' ? 'GND' : n === 'VDD1' ? 'VDD' : 'I2C', role: n === 'VDD1' ? 'i2c_pwr' : n === 'GND1' ? 'i2c_ret' : 'none', rev: n === 'VDD1', len: n.startsWith('S') ? 60 : 55 });
  }
  return B;
}
function hash(s) { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; }
function addPinTop(h, name) { X.addPin(h, name, 0, h.userData.pinTop, 0, 'pin', [0, 1, 0]); }
