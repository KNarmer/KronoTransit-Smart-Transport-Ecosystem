import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import * as X from './models.js';
import { buildBench } from './assembly.js';
import { STEPS, BUILDS } from './steps.js';
import { defaultState, solve, wireCurrent, TP, meterRead, AS_CH, colourCounts } from './sim.js';
import { COMPAT, POWER, NEWPARTS } from './compat.js';
import { buildPod, makePodController, POD_STEPS, HIDE_IN_POD } from './pod.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const css = () => getComputedStyle(document.documentElement);
const tok = (n) => css().getPropertyValue(n).trim();
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

// ------------------------------------------------------------------ renderer + scene
const vp = $('#vp');
const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.localClippingEnabled = true;
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
renderer.shadowMap.enabled = false;
vp.prepend(renderer.domElement);
const labels = new CSS2DRenderer(); labels.domElement.className = 'labels'; vp.appendChild(labels.domElement);
const scene = new THREE.Scene();
scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
const camera = new THREE.PerspectiveCamera(30, 1, 2, 6000);
camera.position.set(140, 420, 520);
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.09; controls.minDistance = 12; controls.maxDistance = 2200;
controls.target.set(20, 0, -20);
controls.zoomToCursor = true;
const sun = new THREE.DirectionalLight(0xffffff, 1.35); sun.position.set(-200, 600, 300); scene.add(sun);
const fill = new THREE.DirectionalLight(0xffffff, 0.35); fill.position.set(300, 200, -400); scene.add(fill);
scene.add(new THREE.HemisphereLight(0xffffff, 0x8a9099, 0.35));

// bench mat (grey-blue ESD mat with a 10 mm grid)
const matTex = X.canvasTex(1024, 1024, (g, w, h) => {
  g.fillStyle = '#5f6f7a'; g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(255,255,255,0.10)'; g.lineWidth = 1;
  for (let i = 0; i <= 64; i++) { const p = i * w / 64; g.beginPath(); g.moveTo(p, 0); g.lineTo(p, h); g.stroke(); g.beginPath(); g.moveTo(0, p); g.lineTo(w, p); g.stroke(); }
  g.strokeStyle = 'rgba(255,255,255,0.22)'; g.lineWidth = 2;
  for (let i = 0; i <= 64; i += 10) { const p = i * w / 64; g.beginPath(); g.moveTo(p, 0); g.lineTo(p, h); g.stroke(); g.beginPath(); g.moveTo(0, p); g.lineTo(w, p); g.stroke(); }
});
matTex.wrapS = matTex.wrapT = THREE.RepeatWrapping; matTex.repeat.set(1, 1);
const mat = new THREE.Mesh(new THREE.PlaneGeometry(800, 640), new THREE.MeshStandardMaterial({ map: matTex, roughness: 0.92 }));
mat.rotation.x = -Math.PI / 2; mat.position.set(20, -0.05, 0); scene.add(mat);
function applyTheme() { scene.background = new THREE.Color(tok('--stage') || '#d9dee2'); }
applyTheme();
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
new MutationObserver(applyTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

function resize() {
  const r = vp.getBoundingClientRect();
  renderer.setSize(r.width, r.height); labels.setSize(r.width, r.height);
  camera.aspect = r.width / Math.max(1, r.height); camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(vp); resize();

// ------------------------------------------------------------------ load
const specs = await (await fetch('assets/boards.json')).json();
const B = await buildBench(scene, specs);
window.B = B;
STEPS.push(...POD_STEPS);
const POD = makePodController(buildPod(B, scene));
window.POD = POD;
const BENCH_LAST = STEPS.findIndex(s => s.scene === 'pod');   // last bench step number
const podIntro = {};
STEPS.forEach((st, i) => { if (st.scene === 'pod') for (const id of st.show || []) podIntro[id] ??= i + 1; });

// cartridge (vial + printed collar + magnet + NTAG215 sticker) for the simulation
const vial = new THREE.Group(); {
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(12.7, 12.7, 52, 40, 1, true), X.M.glass); glass.position.y = 26; vial.add(glass);
  const bot = new THREE.Mesh(new THREE.SphereGeometry(12.7, 32, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), X.M.glass); vial.add(bot);
  const liq = new THREE.Mesh(new THREE.CylinderGeometry(11.9, 11.9, 40, 32), new THREE.MeshPhysicalMaterial({ color: 0x3f9a5a, roughness: 0.1, transmission: 0.4, transparent: true, opacity: 0.85 })); liq.position.y = 20; vial.add(liq); vial.userData.liq = liq;
  const cap = X.cyl(13.4, 9, X.colorMat(0x101010, { roughness: 0.5 }), 40, 0, 52); vial.add(cap);
  const collar = X.cyl(15.5, 8, X.colorMat(0x18181a, { roughness: 0.85 }), 40, 0, 40); vial.add(collar);
  const mag = X.cyl(3.175, 3.175, X.M.nickel, 20); mag.rotation.z = Math.PI / 2; mag.position.set(15.5, 44, 0); vial.add(mag);
  const tag = new THREE.Mesh(new THREE.CylinderGeometry(12.5, 12.5, 0.3, 40), new THREE.MeshStandardMaterial({ color: 0xf4f4f0, map: X.labelTex('CV:2:0001', { w: 256, h: 256, fg: '#333', bg: '#f4f4f0', font: 'bold 30px Arial' }) })); tag.position.y = 61.2; vial.add(tag);
}
vial.rotation.z = Math.PI / 2; vial.rotation.y = Math.PI / 2;
const vialIn = V(-100, 21, -175), vialOut = V(-100, 120, -175);
vial.position.copy(vialOut); vial.visible = false; scene.add(vial);

// ------------------------------------------------------------------ reveal schedule
const items = {}; // id -> { obj, intro, hideAt: [] , showAgain: [] }
function reg(id, obj) { items[id] = items[id] || { obj, events: [] }; return items[id]; }
for (const [id, p] of Object.entries(B.parts)) reg(id, p.obj);
for (const [id, w] of Object.entries(B.wires)) reg(id, w.obj);
const solderSets = [];
STEPS.forEach((st, i) => {
  const n = i + 1;
  for (const id of st.show || []) { if (!items[id]) console.warn('missing', id); else items[id].events.push([n, 1]); }
  for (const id of st.hide || []) items[id]?.events.push([n, 0]);
  if (st.solder) {
    const g = new THREE.Group(); g.name = 'solder' + n;
    for (const [r, c] of st.solder.holes) {
      const p = B.hole(st.solder.pp, r, c);
      const f = X.solderFillet(0.95); f.rotation.x = Math.PI; f.position.copy(p).add(V(0, -1.6, 0)); g.add(f);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.2, 6, 16), X.M.solder); ring.rotation.x = Math.PI / 2; ring.position.copy(p).add(V(0, 0.08, 0)); g.add(ring);
    }
    scene.add(g); st.solderObj = g; g.userData.pp = st.solder.pp; items['solder' + n] = { obj: g, events: [[n, 1]], pp: st.solder.pp }; solderSets.push(g); POD.solderGroups.push(g);
  }
});
// objects never shown by any step stay hidden (none expected); wires shown only on some steps (usb) handled by events
const firstShow = (it) => it.events.find(e => e[1] === 1)?.[0] ?? 1e9;
function visibleAt(it, n) {
  if (n === 0) return it.events.some(e => e[1] === 1) && !it.events.some(e => e[1] === 0 && !it.events.some(f => f[1] === 1 && f[0] > e[0])) ? true : false;
  let v = false; for (const [k, s] of it.events.sort((a, b) => a[0] - b[0])) if (k <= n) v = !!s; return v;
}
// state replay
function stateAt(n) {
  const st = defaultState();
  const last = n === 0 ? STEPS.length : n;
  for (let i = 0; i < last; i++) Object.assign(st, STEPS[i].state || {});
  st.built = new Set(Object.keys(items).filter(id => visibleAt(items[id], last) || (items[id].events.some(e => e[1] === 1 && e[0] <= last) && id !== 'usb' && id !== 'usb_pi')));
  if (n === 0) { st.toggle = 1; st.usb = 0; st.pi = 1; st.bat = 1; st.fw = 'app'; st.cartridge = 1; st.docked = 0; st.boost = 1; }
  return st;
}

// ------------------------------------------------------------------ highlight + callout
const hiBox = new THREE.Box3Helper(new THREE.Box3(), new THREE.Color(0xf2b01e)); hiBox.visible = false; scene.add(hiBox);
const callDiv = document.createElement('div'); callDiv.className = 'callout3d'; const call = new CSS2DObject(callDiv); call.visible = false; scene.add(call);
const pulsing = [];
function setHighlight(objs, text) {
  for (const m of pulsing) { m.material.emissive?.setHex(0x000000); } pulsing.length = 0;
  if (!objs.length) { hiBox.visible = false; call.visible = false; return; }
  const bb = new THREE.Box3(); objs.forEach(o => bb.expandByObject(o));
  bb.expandByScalar(1.2); hiBox.box.copy(bb); hiBox.visible = true;
  callDiv.textContent = text; call.position.set((bb.min.x + bb.max.x) / 2, bb.max.y + 4, (bb.min.z + bb.max.z) / 2); call.visible = !!text;
  for (const o of objs) o.traverse(m => { if (m.isMesh && m.material && m.material.emissive && B.wiresByObj?.has(o)) pulsing.push(m); });
}
B.wiresByObj = new Set(Object.values(B.wires).map(w => w.obj));

// ------------------------------------------------------------------ camera framing
let camTween = null;
function frame(box, view = 'iso', zoom) {
  const c = box.getCenter(new THREE.Vector3()); const size = box.getSize(new THREE.Vector3());
  const r = Math.max(size.x, size.y, size.z, 8);
  const dist = zoom ? Math.max(zoom * 2.4, r * 1.7) : Math.max(60, r * 1.9);
  const dirs = { iso: V(0.3, 0.85, 0.7), top: V(0.02, 1, 0.18), under: V(0.3, -0.75, 0.6), front: V(0, 0.45, 1), back: V(0, 0.6, -1) };
  const d = (dirs[view] || dirs.iso).clone().normalize();
  const to = c.clone().addScaledVector(d, dist);
  if (reduced) { camera.position.copy(to); controls.target.copy(c); return; }
  camTween = { t: 0, p0: camera.position.clone(), p1: to, c0: controls.target.clone(), c1: c };
}
function focusBox(tokens) {
  const bb = new THREE.Box3();
  for (const t of tokens || []) {
    const [id, sub] = t.split(':');
    const addPt = (p, s = 5) => bb.expandByPoint(p.clone().addScalar(s)).expandByPoint(p.clone().addScalar(-s));
    if (sub) {
      const part = B.parts[id]?.obj; const w = B.wires[id];
      if (w && sub === 'end') { addPt(w.fb.pos, 8); continue; }
      if (sub === 'jumpers') { addPt(B.chgJumpers(), 4); continue; }
      if (sub === 'leds') { part.userData.leds.forEach(l => bb.expandByObject(l)); continue; }
      if (part?.userData[sub]?.isObject3D) { bb.expandByObject(part.userData[sub]); continue; }
      if (part?.userData.parts?.[sub]) { bb.expandByObject(part.userData.parts[sub]); continue; }
      try { addPt(B.pinWorld(id, sub).pos, 6); } catch { }
      continue;
    }
    const o = B.parts[id]?.obj || B.wires[id]?.obj; if (o) { const was = o.visible; o.visible = true; bb.expandByObject(o); o.visible = was; }
  }
  return bb;
}
let _ov = null; function overviewBox() {
  if (POD.mode === 'pod') { const b = new THREE.Box3(); b.expandByObject(B.parts.e_shell.obj); b.expandByObject(B.parts.e_dock.obj); return b.isEmpty() ? new THREE.Box3(V(-200, 0, -70), V(240, 170, 70)) : b; }
  if (!_ov) { _ov = new THREE.Box3(); for (const p of Object.values(B.parts)) if (p.obj.parent === B.root && !p.pod) _ov.expandByObject(p.obj); _ov.expandByScalar(-20); } return _ov; }

// ------------------------------------------------------------------ step player
let cur = 0; let anim = [];
const total = STEPS.length;
function podShown(id, n) { const r = POD.rootPart(id); return n === 0 || (podIntro[r] ?? 1e9) <= n; }
function podVisible(id, it, n) {
  if (HIDE_IN_POD.has(id) || id === 'usb') return false;
  if (id === 'e_lid' && POD.lidOff) return false;
  if (id === 'e_vial') return podShown(id, n) && !!stateAt(n).cartridge;
  if (it.pp) return podShown(it.pp, n);
  const w = B.wires[id];
  if (w) { const [a, b] = w.args; return (a.p ? podShown(a.p, n) : true) && (b.p ? podShown(b.p, n) : true); }
  return podShown(id, n);
}
function applyVisibility(n) {
  const pod = POD.mode === 'pod';
  for (const [id, it] of Object.entries(items)) {
    const v = pod ? podVisible(id, it, n) : (B.parts[id]?.pod ? false : visibleAt(it, n));
    it.obj.visible = v;
    if (it.obj.userData._y0 === undefined) it.obj.userData._y0 = it.obj.position.y;
    it.obj.position.y = it.obj.userData._y0;
    it.obj.scale.setScalar(1);
    setGrow(it.obj, 1);
  }
}
function setGrow(o, f) {
  o.traverse(m => { if (m.isMesh && m.geometry?.type === 'TubeGeometry' && m.geometry.index) { const n = m.geometry.index.count; m.geometry.setDrawRange(0, f >= 1 ? Infinity : Math.floor(n * f / 3) * 3); } });
}
function applyModelState(st, R) {
  const dk = B.P('dk').userData;
  for (const k of ['sw9', 'sw10', 'swPower']) if (st[k] !== undefined) { dk[k].userData.knob.position.x = st[k] * dk[k].userData.span; }
  const tog = B.P('tog').userData.lever; tog.scale.z = st.toggle ? -1 : 1;
  // power LEDs on breakouts glow when their VDD is up
  const glow = (m, hex, on) => { if (!m) return; m.material.emissive.setHex(on ? hex : 0x000000); m.material.emissiveIntensity = on ? 2.2 : 0; };
  for (const id of ['lsm6', 'h3lis', 'bme', 'rtc', 'gauge']) glow(B.P(id).userData.parts?.D1?.userData.led, 0x22ff44, R.on?.[id === 'gauge' ? 'gauge' : id]);
  glow(B.P('as7341').userData.parts?.D1?.userData.led, 0x22ff44, false);
  const chgP = B.P('chg').userData.parts;
  glow(chgP.D3?.userData.led, 0xff2a1a, R.dockOK && R.I.chg > 0);
  glow(chgP.D1?.userData.led, 0x22ff44, R.dockOK);
  const dl = dk.leds; dl.forEach((l, i) => { l.material.emissive.setHex(0x000000); });
  if (R.fwRun && st._blink) dl[0].material.emissive.setHex(0x22ff55);
  B.P('pi').userData.act.material.emissive.setHex(st.pi && st._piAct ? 0x33ff44 : 0x000000);
  const rgb = B.parts.rgb.lens; const I = R.I.led;
  const rc = new THREE.Color(I.r ? 1 : 0, I.g ? 0.85 : 0, I.b ? 1 : 0);
  rgb.emissive.copy(rc); rgb.emissiveIntensity = (I.r || I.g || I.b) ? 1.6 : 0;
  const wl = B.parts.wled.lens; wl.emissive.setHex(I.w ? 0xfff6e0 : 0); wl.emissiveIntensity = I.w ? 2.2 : 0;
  const nl = B.P('nfc').userData.led; nl.material.emissive.setHex(st._nfcLed ? 0x3399ff : 0);
  const coin = B.P('rtc').userData.coin; coin.visible = st.built.has('cr1220');
  // docking
  const wantDock = !!st.docked;
  if (POD.mode === 'pod') POD.dock(wantDock);
  else if (B._docked !== wantDock) {
    const pod = B.P('magPod'), dock = B.P('magDock');
    if (wantDock) { pod.position.set(dock.position.x, dock.position.y + 4 + 4 + 1.0, dock.position.z); pod.rotation.set(Math.PI, 0, 0); }
    else { pod.position.set(250, 2.4, 75); pod.rotation.set(0, 0, 0); }
    pod.userData._y0 = pod.position.y; pod.updateMatrixWorld(true);
    for (const id of ['w_m1', 'w_m2', 'w_m3', 'w_m4', 'w_m5']) { const r = B.rebuild(id); items[id].obj = r.obj; }
    B.wiresByObj = new Set(Object.values(B.wires).map(w => w.obj));
    B._docked = wantDock; flow.rebuild();
  }
  vial.visible = POD.mode !== 'pod' && !!st.cartridge; if (st.cartridge && !vial.userData.anim) vial.position.copy(vialIn);
  const pv = B.parts.e_vial.obj; if (POD.mode === 'pod') { pv.visible = !!st.cartridge && podShown('e_vial', cur); pv.userData.liq.material.color.set({ yellow: 0xd9c21e, green: 0x4f9a4a, blue: 0x2a5bb8 }[st.color]); }
  if (POD.pipe) { POD.pipe.material.emissive.copy(rc); POD.pipe.material.emissiveIntensity = (I.r || I.g || I.b) ? 1.2 : 0; }
  if (vial.userData.liq) vial.userData.liq.material.color.set({ yellow: 0xd9c21e, green: 0x4f9a4a, blue: 0x2a5bb8 }[st.color]);
}

function setMode(m) {
  if (m === POD.mode) return;
  if (m === 'pod') POD.enter(); else POD.exit();
  for (const it of Object.values(items)) it.obj.userData._y0 = undefined;
  syncWires(); _ov = null;
  $$('.podonly').forEach(e => e.hidden = m !== 'pod');
  $('#mPod').setAttribute('aria-pressed', m === 'pod'); $('#mBench').setAttribute('aria-pressed', m !== 'pod');
}
function syncWires() { for (const [id, w] of Object.entries(B.wires)) if (items[id]) items[id].obj = w.obj; B.wiresByObj = new Set(Object.values(B.wires).map(w => w.obj)); }
POD.onRebuild = () => { syncWires(); };
function go(n, animate = true) {
  n = Math.max(0, Math.min(total, n)); cur = n;
  setMode(n === 0 || STEPS[n - 1].scene === 'pod' ? 'pod' : 'bench');
  applyVisibility(n);
  const st = stateAt(n); simState = null;
  const R = solve(st); lastSolve = { st, R };
  applyModelState(st, R);
  anim = [];
  const step = STEPS[n - 1];
  if (n > 0 && animate && !reduced) {
    for (const id of step.show || []) {
      const o = items[id]?.obj; if (!o) continue;
      if (B.wiresByObj.has(o)) anim.push({ t: 0, dur: 1.1, f: (k) => setGrow(o, k) });
      else { const y0 = o.userData._y0; anim.push({ t: 0, dur: 0.8, f: (k) => { o.position.y = y0 + (1 - easeOut(k)) * 45; } }); }
    }
    if (step.solderObj) step.solderObj.children.forEach((c, i) => { c.scale.setScalar(0.001); anim.push({ t: -i * 0.18, dur: 0.35, f: (k) => c.scale.setScalar(Math.max(0.001, k)) }); });
  }
  // highlight
  const hl = []; if (step) { for (const id of step.show || []) if (items[id]) hl.push(items[id].obj); if (step.solderObj) hl.push(step.solderObj); }
  const ref = step?.show?.map(id => B.parts[id]?.ref ? `${B.parts[id].ref} · ${B.parts[id].label}` : null).find(Boolean) || '';
  setHighlight(hl, ref);
  // camera
  if (n === 0) { const ob = overviewBox(); frame(ob, 'iso', ob.getSize(new THREE.Vector3()).length() * 0.95); }
  else { let bb = focusBox(step.focus); if (bb.isEmpty()) bb = overviewBox(); frame(bb, step.view || 'iso', step.zoom); }
  mat.visible = true;
  renderStep(n, st, R);
  // auto-run the step's meter test
  if (step?.test) runTest(step.test); else hideProbes();
  try { localStorage.setItem('cc-step', String(n)); } catch { }
  flow.rebuild(); refreshViews();
}
const easeOut = (k) => 1 - Math.pow(1 - k, 3);

// ------------------------------------------------------------------ panel rendering
const CATALOG = {
  wire30r: ['30 AWG silicone wire, red', 'A12'], wire30b: ['30 AWG silicone wire, black', 'A12'], wire30w: ['30 AWG wire, second colour', 'A12'],
  jFF: ['Female/female jumper 150 mm', 'A14'], jFM: ['Female/male extension jumper 150 mm', 'A18 · new'], qt100: ['STEMMA QT cable 100 mm', 'B7'], qt200: ['STEMMA QT cable 200 mm', 'B8'],
  qt_dk: ['STEMMA QT to male-header cable', 'B9'], w_jst: ['JST-PH 2-pin jumper', 'A5'], usb: ['USB-A to micro-B cable, 6 in', 'A2'], usb_pi: ['Pi micro-USB supply 5.1 V 2.5 A', 'B11'],
  pico: ['Molex PicoBlade 7-pin cable, cut in half', 'C11 · new'], kapton: ['Kapton tape', 'C10'], r220: ['220 Ω resistor + heat-shrink', 'C8 · A13'],
};
function partInfo(id) {
  if (CATALOG[id]) return { label: CATALOG[id][0], ref: CATALOG[id][1] };
  const p = B.parts[id]; return p ? { label: p.label, ref: p.ref } : { label: id, ref: '' };
}
function renderStep(n, st, R) {
  const box = $('#step');
  $('#stepNo').textContent = n === 0 ? 'Overview' : `Step ${n}`;
  $('#stepOf').textContent = `of ${total}`;
  $('#scrub').value = n;
  if (n === 0) {
    box.innerHTML = `<p class="eyebrow">ChronoCase Kit B · finished product</p><h2>The finished pod</h2>
      <p class="body">Every board, wire and solder joint at true scale, mounted where it lives in the pod: power and the DK in the base tray, the cartridge cradle and its sensors in the insulated well, the SPI backbone standing on the right. The front is cut away so you can see in. The dock sits to the right.</p>
      <p class="body">Drag to orbit, scroll or pinch to zoom, right-drag to pan. Use <b>Explode</b> to pull the layers apart, <b>Lid off</b>, or <b>Cutaway</b> to close the shell.</p>
      <ul class="facts"><li><b>${total}</b> steps, one action each</li><li><b>${Object.keys(B.wires).length}</b> wires and cables</li><li>Builds A–C on the bench, then Build D moves everything into the pod</li></ul>
      <p>Press <kbd>→</kbd> or <b>Next</b> to start the build from an empty bench.</p>`;
    $('#buildTag').textContent = 'All builds'; return;
  }
  const s = STEPS[n - 1]; const b = BUILDS[s.build];
  $('#buildTag').textContent = `${b.name} · ${b.week}`;
  const parts = (s.parts || []).map(id => { const p = partInfo(id); return `<li><span class="ref">${p.ref || '—'}</span><span>${p.label}</span></li>`; }).join('');
  let html = `<p class="eyebrow">${b.week}</p><h2>${s.title}</h2><p class="body">${s.text}</p>`;
  if (parts) html += `<div class="partsbox"><p class="label">Parts for this step</p><ul>${parts}</ul></div>`;
  if (s.test) html += `<div class="testbox" id="testbox"><p class="label">Check</p><div id="testline">${testLine(s.test)}</div></div>`;
  if (s.fw) html += `<div class="console"><p class="label">Console</p><pre>${s.fw.map(l => l.replace(/</g, '&lt;')).join('\n')}</pre></div>`;
  box.innerHTML = html;
}
function testLine(t) {
  const a = TP[t.a]?.label || t.a, b = TP[t.b]?.label || t.b;
  const exp = t.expect === 'OL' ? 'open (OL, no beep)' : Array.isArray(t.expect) ? (t.mode === 'V' ? `${t.expect[0].toFixed(2)}–${t.expect[1].toFixed(2)} V` : `${t.expect[0]}–${t.expect[1]} Ω`) : t.expect;
  return `<span class="probe red"></span>${a} <span class="probe blk"></span>${b}<br>Expect <b>${exp}</b> · reading <b id="liveRead">—</b> <span id="verdict"></span>`;
}

// ------------------------------------------------------------------ meter + probes
const probes = new THREE.Group(); scene.add(probes); probes.visible = false;
function makeProbe(color) {
  const g = new THREE.Group();
  g.add(X.cyl(0.35, 6, X.M.steel, 10, 0, 0, 0));
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.2, 10), X.M.steel); tip.rotation.x = Math.PI; tip.position.y = -0.6; g.add(tip);
  g.add(X.cyl(2.2, 45, X.colorMat(color, { roughness: 0.4 }), 16, 0, 6));
  g.add(X.cyl(2.8, 2, X.colorMat(color, { roughness: 0.4 }), 16, 0, 9));
  return g;
}
const pRed = makeProbe(0xd02018), pBlk = makeProbe(0x141414); probes.add(pRed, pBlk);
function tpPos(name) {
  const tp = TP[name]; if (!tp) return null; const w = tp.where;
  if (w[0] === 'chgj') return B.chgJumpers().add(V(0, 0, w[1] * 0.5));
  if (w.length === 3) return B.hole(...w).add(V(0, 0.3, 0));
  try { const p = B.pinWorld(w[0], w[1]); return p.kind === 'socket' ? p.pos.clone() : p.pos.clone().add(V(0, 0.2, 0)); } catch { return null; }
}
let activeTest = null;
function placeProbe(p, pos, lean) { p.position.copy(pos); p.rotation.set(-0.42, 0, 0.22 * lean); }
function runTest(t) {
  activeTest = t; meter.mode = t.mode === 'ohm' ? 'ohm' : 'V'; meter.a = t.a; meter.b = t.b; syncMeterUI();
  const a = tpPos(t.a), b = tpPos(t.b);
  if (a && b) { placeProbe(pRed, a, 1); placeProbe(pBlk, b, -1); probes.visible = true; }
}
function hideProbes() { activeTest = null; if (!$('#tab-meter').classList.contains('on')) probes.visible = false; }
const meter = { mode: 'V', a: 'pp1:VSYS', b: 'pp1:GND' };
function populateTP() {
  const opts = Object.entries(TP).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('');
  $('#mA').innerHTML = opts; $('#mB').innerHTML = opts;
}
function syncMeterUI() { $('#mA').value = meter.a; $('#mB').value = meter.b; $$('#meterModes button').forEach(b => b.setAttribute('aria-pressed', b.dataset.m === meter.mode)); }
function meterTick() {
  const { st, R } = current();
  const r = meterRead(meter.mode, meter.a, meter.b, st, R, st.built);
  $('#lcd').textContent = r.text; $('#lcdUnit').textContent = r.unit || '';
  $('#lcdNote').textContent = r.note || (r.beep ? 'beep' : '');
  $('#lcdWrap').classList.toggle('beep', !!r.beep);
  const live = $('#liveRead');
  if (live && activeTest) {
    live.textContent = `${r.text} ${r.unit || ''}`;
    const e = activeTest.expect; let ok;
    if (e === 'OL') ok = !!r.ol; else if (Array.isArray(e)) ok = r.value !== undefined ? r.value >= e[0] && r.value <= e[1] : parseFloat(r.text) >= e[0] && parseFloat(r.text) <= e[1];
    $('#verdict').textContent = ok ? 'PASS' : 'CHECK'; $('#verdict').className = ok ? 'pass' : 'fail';
  }
}

// ------------------------------------------------------------------ current flow + voltage map
const FLOWCOL = { power: 0xff4a3a, gnd: 0x2f8cff, sig: 0x47e08a, v5: 0xffb020, bat: 0xff7ad0 };
const flow = {
  on: false, volt: false, inst: null, list: [],
  rebuild() {
    if (this.inst) { scene.remove(this.inst); this.inst.geometry.dispose(); }
    this.list = []; if (!this.on) return;
    const { R } = current();
    for (const w of Object.values(B.wires)) {
      if (!w.obj.visible) continue;
      const I = Math.abs(wireCurrent(w, R)); if (I < 0.005) continue;
      const pm = w.obj.parent ? w.obj.parent.matrixWorld : new THREE.Matrix4();
      const pts = w.curve.getSpacedPoints(160).map(p => p.clone().applyMatrix4(pm));
      const n = Math.max(2, Math.min(40, Math.round(w.len / 9)));
      const cat = /ret|^none$/.test(w.role) || w.net === 'GND' ? 'gnd' : w.net === '5V_SW' || /led|nfc|v5/.test(w.role) ? 'v5' : /bat|sys|vbus|pi_in/.test(w.role) ? 'bat' : /base|sig|spi|uart|i2c$/.test(w.role) ? 'sig' : 'power';
      const charging = w.role === 'bat' && R.I.bat > 0;
      const dir = (w.rev ? -1 : 1) * (charging ? -1 : 1);
      const speed = 12 + 22 * Math.log10(1 + I);
      for (let i = 0; i < n; i++) this.list.push({ pts, u: i / n, speed: speed / w.len, dir, col: FLOWCOL[cat] });
    }
    const g = new THREE.SphereGeometry(0.75, 8, 6);
    this.inst = new THREE.InstancedMesh(g, new THREE.MeshBasicMaterial({ toneMapped: false }), Math.max(1, this.list.length));
    this.list.forEach((p, i) => this.inst.setColorAt(i, new THREE.Color(p.col)));
    this.inst.count = this.list.length; scene.add(this.inst);
  },
  tick(dt) {
    if (!this.inst || !this.on) return;
    const m4 = new THREE.Matrix4();
    this.list.forEach((p, i) => {
      p.u = (p.u + p.dir * p.speed * dt + 1) % 1;
      const f = p.u * 159, k = Math.floor(f), a = p.pts[k], b = p.pts[Math.min(159, k + 1)];
      m4.makeTranslation(a.x + (b.x - a.x) * (f - k), a.y + (b.y - a.y) * (f - k) + 0.4, a.z + (b.z - a.z) * (f - k));
      this.inst.setMatrixAt(i, m4);
    });
    this.inst.instanceMatrix.needsUpdate = true;
  },
};
function voltColor(v) { // 0 V deep blue -> 3.3 green -> 4.2 orange -> 5.2 red
  const stops = [[0, [0.12, 0.2, 0.55]], [1.5, [0.1, 0.55, 0.75]], [3.3, [0.25, 0.8, 0.3]], [4.2, [1.0, 0.6, 0.1]], [5.3, [0.95, 0.15, 0.1]]];
  for (let i = 1; i < stops.length; i++) if (v <= stops[i][0]) { const [v0, c0] = stops[i - 1], [v1, c1] = stops[i]; const k = (v - v0) / (v1 - v0); return new THREE.Color(...c0.map((c, j) => c + (c1[j] - c) * k)); }
  return new THREE.Color(0.95, 0.15, 0.1);
}
const nodeLabels = [];
function refreshViews() {
  const { R } = current();
  for (const w of Object.values(B.wires)) {
    w.obj.traverse(m => {
      if (!m.isMesh || !m.userData.baseColor) return;
      if (flow.volt) { const v = R.V[w.net] ?? 0; m.material.color.copy(voltColor(v)); m.material.emissive.copy(voltColor(v)).multiplyScalar(0.35); }
      else { m.material.color.copy(m.userData.baseColor); m.material.emissive.setHex(0); }
    });
  }
  nodeLabels.forEach(l => scene.remove(l)); nodeLabels.length = 0;
  if (flow.on || flow.volt) {
    const pts = [['pp1:VSYS', 'VSYS', R.V.VSYS, R.I.sys], ['pp1:A12', '3V3', R.V['3V3'], R.I.v33], ['pp1:5V_SW', '5V_SW', R.V['5V_SW'], R.I.v5], ['chg:LIPO', 'BAT', R.V.BAT, R.I.bat], ['chg:VBUS', 'VBUS', R.V.VBUS, R.I.vbus], ['pp2:3V3', 'PP2 3V3', R.V.VDD, R.I.core + R.I.amb]];
    for (const [tp, name, v, i] of pts) {
      const p = tpPos(tp); if (!p || !(v > 0 || i)) continue;
      const d = document.createElement('div'); d.className = 'vlab';
      d.innerHTML = `<b>${name}</b> ${v.toFixed(2)} V${i ? ` · ${Math.abs(i) < 10 ? Math.abs(i).toFixed(1) : Math.round(Math.abs(i))} mA${name === 'BAT' ? (i > 0 ? ' in' : ' out') : ''}` : ''}`;
      const o = new CSS2DObject(d); o.position.copy(p).add(V(0, 10, 0)); scene.add(o); nodeLabels.push(o);
    }
  }
  $('#legend').hidden = !flow.volt && !flow.on;
  $('#legendV').hidden = !flow.volt; $('#legendI').hidden = !flow.on;
  renderBudget(R);
}
function renderBudget(R) {
  const I = R.I, V = R.V;
  const row = (k, v, i) => `<tr><td>${k}</td><td class="num">${v === null ? '' : v.toFixed(2) + ' V'}</td><td class="num">${i === null ? '' : (Math.abs(i) < 10 ? i.toFixed(2) : i.toFixed(0)) + ' mA'}</td></tr>`;
  $('#budget').innerHTML = `<table><thead><tr><th>Rail</th><th class="num">Voltage</th><th class="num">Current</th></tr></thead><tbody>
    ${row('Battery (+ = charging)', V.BAT, I.bat)}${row('VBUS from dock', V.VBUS, I.vbus)}${row('VSYS (after switch)', V.VSYS, I.sys)}
    ${row('3V3 / DK VDD', V.VDD, I.v33)}${row('· nRF5340', null, I.nrf)}${row('· I2C sensors + LEDs', null, I.sensors)}${row('· two MAX31865', null, I.core + I.amb)}
    ${row('5V_SW', V['5V_SW'], I.v5)}${row('· NFC module', null, I.nfc)}${row('· status + white LEDs', null, I.led.r + I.led.g + I.led.b + I.led.w)}</tbody></table>`;
}

// ------------------------------------------------------------------ system simulation
let simState = null, lastSolve = null, simT = 0, simSpeed = 4, simPlaying = false, simLog = [], hist = [];
function current() {
  if (simState) { const R = solve(simState); return { st: simState, R }; }
  return lastSolve;
}
function log(s) { const t = new Date(Date.UTC(2026, 10, 23, 9, 0, 0) + simT * 1000).toISOString().slice(11, 19); simLog.push(`${t}  ${s}`); if (simLog.length > 120) simLog.shift(); const el = $('#simLog'); if (el) { el.textContent = simLog.join('\n'); el.scrollTop = el.scrollHeight; } }
const queue = []; // timed actions {at, fn}
function after(sec, fn) { queue.push({ at: simT + sec, fn }); }
function startSim() {
  go(0, false);
  simState = stateAt(0); simState.toggle = 1; simState.fw = 'app'; simState.pi = 1; simState.boost = 1; simState.nfc = 'pd';
  simState.soc = 72; simState.battV = 3.92; simState.cartridge = 0; simState.docked = 0; simState.color = 'green'; POD.lidOff = true; applyVisibility(0);
  simT = 0; simLog = []; hist = []; queue.length = 0; lastSample = -5; peak = 0;
  for (const s of STEPS.slice(0)) Object.assign(simState, {}); // keep built set from final state
  simState.built = stateAt(0).built;
  log('power on · nRF Connect SDK v2 · ChronoCase pod v0.1-conrad');
  log('i2c: 0x18 H3LIS331, 0x36 MAX17048, 0x39 AS7341, 0x68 PCF8523, 0x6A LSM6DSOX, 0x77 BME688');
  log('spi: MAX31865 core + amb ready (4-wire, Rref 4300 Ω, 60 Hz filter); NFC power-down');
  log('status: green · logging every 5 s');
  frame(overviewBox(), 'iso'); applyModelState(simState, solve(simState)); flow.rebuild(); refreshViews();
  simPlaying = true; $('#simPlay').textContent = 'Pause'; updateReadouts();
}
let lastSample = -5, peak = 0, heat = 0;
function simTick(dt) {
  if (!simState || !simPlaying) return;
  const s = simState; const step = dt * simSpeed; simT += step;
  for (let i = queue.length - 1; i >= 0; i--) if (queue[i].at <= simT) { const q = queue.splice(i, 1)[0]; q.fn(); }
  // thermal model: core sits in the cold-pack well (τ ≈ 6 h toward 4 °C); "warm" injects heat
  const target = 4.0 + heat * 14;
  s.tCore += (target - s.tCore) * Math.min(1, step / (heat ? 240 : 2400));
  heat = Math.max(0, heat - step / 600);
  s.tAmb = 22 + Math.sin(simT / 900) * 0.4;
  // battery
  const R = solve(s);
  s.soc = Math.max(0, Math.min(100, s.soc + (R.I.bat / 2500) * 100 * step / 3600 * (s._drain ? 400 : 1)));
  s.battV = 3.45 + 0.75 * Math.pow(s.soc / 100, 0.8);
  if (s.soc < 6 && !s._alert) { s._alert = 1; log('MAX17048 ALRT (A5 low): SOC 5 %, 3.50 V · closing log block, signing, sleeping'); s.boost = 0; s.led = ''; s.fw = 'app'; s._sleep = 1; }
  // heartbeat
  s._blink = (simT % 5) < 0.15;
  if (!s._sleep && (simT % 5) < step && (simT % 5) >= 0) {}
  if (simT - lastSample >= 5 && !s._sleep) {
    lastSample = simT;
    const tc = s.tCore + (Math.random() - 0.5) * 0.02, ta = s.tAmb + (Math.random() - 0.5) * 0.05;
    s.gas = Math.max(20, s.gas + (190 - s.gas) * 0.05 + (Math.random() - 0.5) * 2 - (s._voc ? 18 : 0));
    hist.push({ t: simT, tc, ta, soc: s.soc, ib: R.I.bat, g: peak, gas: s.gas }); if (hist.length > 240) hist.shift();
    peak = 0;
    const alarm = s.tCore > 8;
    if (alarm && !s._alarm) { s._alarm = 1; log(`EXCURSION: core ${s.tCore.toFixed(2)} °C > 8 °C · status red`); }
    if (!alarm && s._alarm) { s._alarm = 0; log(`core back in range ${s.tCore.toFixed(2)} °C`); }
    if (!s.docked) { s.led = s._alarm ? 'r' : 'g'; after(0.25, () => { if (!s.docked) s.led = ''; }); }
  }
  s._piAct = s.pi && (s.docked ? (simT * 3) % 1 < 0.5 : (simT % 7) < 0.2);
  if (s.docked) { s.led = 'b'; }
  applyModelState(s, R);
  if (Math.floor(simT * 2) !== Math.floor((simT - step) * 2)) { flow.rebuild(); refreshViews(); updateReadouts(); }
}
const EV = {
  insert() {
    const s = simState; if (s.cartridge) return;
    s.cartridge = 1; if (POD.mode === 'pod') { const pv = B.parts.e_vial.obj; pv.visible = true; pv.userData.drop = { t: 0, y0: pv.userData.podM.elements[13] }; } else { vial.visible = true; vial.userData.anim = { t: 0 }; } log('cartridge seated: reed closed, D4 low');
    after(0.2, () => { s.nfc = 'idle'; s.boost = 1; log('nfc: wake, field on'); });
    after(0.5, () => { s.nfc = 'rf'; s._nfcLed = 1; });
    after(0.9, () => { s.nfc = 'poll'; log('nfc: NTAG215 UID 04:A2:5F:1A:3C:6B:80 · NDEF text "CV:2:0001" (specimen type 2, serial 0001)'); });
    after(1.2, () => { s.nfc = 'pd'; s._nfcLed = 0; log('nfc: power-down (≈10 µA)'); EV.read(); });
  },
  remove() { const s = simState; if (!s.cartridge) return; s.cartridge = 0; vial.visible = false; B.parts.e_vial.obj.visible = false; log('cartridge removed: D4 high'); },
  read() {
    const s = simState; if (!s.cartridge) { log('colour read skipped: no cartridge'); return; }
    s.led = 'w'; s.colorRead = 1; log('colour: white LED on, AS7341 10-channel read (100 ms)');
    after(0.35, () => {
      const c = colourCounts(s.color), dk = colourCounts(s.color, true);
      s._counts = c.map((v, i) => v - dk[i]); s.led = ''; s.colorRead = 0;
      const blue = s._counts[1] + s._counts[2], yel = s._counts[5] + s._counts[6];
      const ratio = blue / Math.max(1, yel); const cls = ratio > 1.15 ? 'blue (alkaline)' : ratio < 0.45 ? 'yellow (acidic)' : 'green (neutral)';
      log(`colour: dark frame subtracted · blue/yellow ratio ${ratio.toFixed(2)} → ${cls}`); updateReadouts();
    });
  },
  colour() { const order = ['yellow', 'green', 'blue']; const s = simState; s.color = order[(order.indexOf(s.color) + 1) % 3]; log(`indicator changed to ${s.color}`); EV.read(); },
  warm() { heat = 1; log('hand on the pod: heat flowing into the well'); },
  drop() {
    const s = simState; peak = 38.6; s._shake = 0.6;
    log('LSM6DSOX INT1 (D2): wake-up · peak clipped at 16 g'); log('H3LIS331 INT1 (D3): impact 38.6 g, 4 ms · logged with timestamp');
    s.led = 'rg'; after(0.4, () => { s.led = ''; });
  },
  gas() { simState._voc = 1; log('isopropyl swab at the vent: BME688 gas resistance falling'); after(60, () => { simState._voc = 0; }); },
  dock() {
    const s = simState; if (s.docked) return; s.docked = 1;
    log('docked: A0 low · VBUS 4.96 V · bq24074 charging 500 mA'); log('TX HELLO v0.1 → RX ACK · GET_FRAMES');
    after(1.5, () => log('sync: 1,284 frames · hash chain OK · PSA signature OK · PCF8523 set from dock UTC'));
    after(2.5, () => log('dock: FHIR Observation bundle posted (201 Created)'));
  },
  undock() { const s = simState; if (!s.docked) return; s.docked = 0; s.led = ''; log('undocked: A0 high · on battery'); },
  drain() { simState._drain = 1; log('fast-forward battery drain (×400)'); },
};
function updateReadouts() {
  if (!simState) return; const s = simState, R = solve(s);
  const set = (id, v) => { const e = $(id); if (e) e.textContent = v; };
  set('#rVsys', R.V.VSYS.toFixed(2) + ' V'); set('#r33', R.V.VDD.toFixed(2) + ' V'); set('#r5', R.V['5V_SW'].toFixed(2) + ' V');
  set('#rIb', `${R.I.bat >= 0 ? '+' : '−'}${Math.abs(R.I.bat).toFixed(Math.abs(R.I.bat) < 100 ? 1 : 0)} mA`);
  set('#rSoc', s.soc.toFixed(1) + ' %'); set('#rTc', s.tCore.toFixed(2) + ' °C'); set('#rTa', s.tAmb.toFixed(2) + ' °C');
  set('#rGas', (s.gas).toFixed(0) + ' kΩ'); set('#rD4', s.cartridge ? 'closed (low)' : 'open (high)'); set('#rDock', s.docked ? 'docked' : 'on battery');
  set('#simClock', new Date(Date.UTC(2026, 10, 23, 9, 0, 0) + simT * 1000).toISOString().slice(11, 19));
  drawCharts(); drawBars();
}
function drawLine(cv, series, opts) {
  const g = cv.getContext('2d'); const W = cv.width = cv.clientWidth * devicePixelRatio, H = cv.height = cv.clientHeight * devicePixelRatio;
  g.clearRect(0, 0, W, H); const pad = 26 * devicePixelRatio, top = 8 * devicePixelRatio;
  const [lo, hi] = opts.range; const x = (i, n) => pad + (W - pad - 6) * (n <= 1 ? 1 : i / (n - 1)); const y = (v) => top + (H - top - 14 * devicePixelRatio) * (1 - (v - lo) / (hi - lo));
  g.font = `${10 * devicePixelRatio}px "IBM Plex Mono", monospace`; g.fillStyle = tok('--muted'); g.strokeStyle = tok('--rule'); g.lineWidth = 1;
  for (const v of opts.ticks) { g.beginPath(); g.moveTo(pad, y(v)); g.lineTo(W - 6, y(v)); g.stroke(); g.fillText(String(v), 2, y(v) + 3 * devicePixelRatio); }
  if (opts.limit !== undefined) { g.strokeStyle = tok('--bad'); g.setLineDash([4, 4]); g.beginPath(); g.moveTo(pad, y(opts.limit)); g.lineTo(W - 6, y(opts.limit)); g.stroke(); g.setLineDash([]); }
  for (const s of series) {
    if (!s.data.length) continue; g.strokeStyle = s.color; g.lineWidth = 2 * devicePixelRatio; g.beginPath();
    s.data.forEach((v, i) => { const X0 = x(i, s.data.length), Y0 = y(Math.max(lo, Math.min(hi, v))); i ? g.lineTo(X0, Y0) : g.moveTo(X0, Y0); }); g.stroke();
    const lv = s.data.at(-1); g.fillStyle = s.color; g.beginPath(); g.arc(x(s.data.length - 1, s.data.length), y(Math.max(lo, Math.min(hi, lv))), 3 * devicePixelRatio, 0, 7); g.fill();
  }
}
function drawCharts() {
  const c1 = $('#chTemp'), c2 = $('#chBat'), c3 = $('#chG'); if (!c1 || !c1.clientWidth) return;
  drawLine(c1, [{ data: hist.map(h => h.ta), color: tok('--c2') }, { data: hist.map(h => h.tc), color: tok('--c1') }], { range: [0, 25], ticks: [0, 8, 16, 24], limit: 8 });
  drawLine(c2, [{ data: hist.map(h => h.soc), color: tok('--c1') }], { range: [0, 100], ticks: [0, 50, 100] });
  drawLine(c3, [{ data: hist.map(h => h.g), color: tok('--c3') }], { range: [0, 50], ticks: [0, 16, 50] });
}
function drawBars() {
  const cv = $('#chCol'); if (!cv || !cv.clientWidth) return; const g = cv.getContext('2d');
  const W = cv.width = cv.clientWidth * devicePixelRatio, H = cv.height = cv.clientHeight * devicePixelRatio; g.clearRect(0, 0, W, H);
  const c = simState?._counts; const n = AS_CH.length, bw = W / n;
  const wl = (nm) => nm < 440 ? '#7a4cff' : nm < 490 ? '#2f6bff' : nm < 530 ? '#18b06a' : nm < 570 ? '#9ccc1a' : nm < 600 ? '#f2b01e' : nm < 650 ? '#f06a1a' : nm < 700 ? '#d62a1a' : '#8a1a1a';
  g.font = `${9 * devicePixelRatio}px "IBM Plex Mono", monospace`; g.textAlign = 'center';
  AS_CH.forEach(([name, nm], i) => {
    const v = c ? c[i] : 0, h = (H - 16 * devicePixelRatio) * Math.min(1, v / 5200);
    g.fillStyle = name === 'Clear' ? tok('--muted') : name === 'NIR' ? '#6a2020' : wl(nm);
    g.fillRect(i * bw + 3, H - 14 * devicePixelRatio - h, bw - 6, h);
    g.fillStyle = tok('--muted'); g.fillText(name, i * bw + bw / 2, H - 3 * devicePixelRatio);
  });
}

// ------------------------------------------------------------------ compatibility + parts tabs
function renderCompat() {
  $('#compatNew').innerHTML = NEWPARTS.map(p => `<li><b>${p.id}</b> ${p.name} · <span class="num">$${p.price.toFixed(2)}</span><br><span class="muted">${p.why}</span></li>`).join('');
  $('#compatTable').innerHTML = `<table><thead><tr><th>Part</th><th>Supply · logic</th><th>Connected to</th><th>Verdict</th></tr></thead><tbody>${COMPAT.map(r => `<tr><td><b>${r.id}</b> ${r.part}</td><td>${r.supply}</td><td>${r.link}</td><td><span class="pill ${r.v}">${{ ok: 'OK', fix: 'OK with fix', new: 'needs new part' }[r.v]}</span> ${r.note}</td></tr>`).join('')}</tbody></table>`;
  $('#powerTable').innerHTML = `<table><thead><tr><th>Rail</th><th class="num">Peak load</th><th class="num">Limit</th><th class="num">Margin</th></tr></thead><tbody>${POWER.map(r => `<tr><td>${r.rail}</td><td class="num">${r.load}</td><td class="num">${r.limit}</td><td class="num">${r.margin}</td></tr>`).join('')}</tbody></table>`;
}
function renderParts() {
  const rows = Object.entries(B.parts).filter(([id, p]) => p.ref && !id.startsWith('so_') && !id.startsWith('h_') && !id.startsWith('hdr')).map(([id, p]) => `<li data-id="${id}" tabindex="0"><span class="ref">${p.ref}</span>${p.label}</li>`).join('');
  $('#partsList').innerHTML = rows;
  $$('#partsList li').forEach(li => li.addEventListener('click', () => { const id = li.dataset.id; frame(focusBox([id]), 'iso'); setHighlight([B.parts[id].obj], `${B.parts[id].ref} · ${B.parts[id].label}`); }));
}

// ------------------------------------------------------------------ UI wiring
$('#prev').onclick = () => go(cur - 1); $('#next').onclick = () => go(cur + 1);
$('#scrub').max = total; $('#scrub').oninput = (e) => go(+e.target.value, false);
for (const b of $$('.buildjump')) b.onclick = () => { const i = STEPS.findIndex(s => s.build === b.dataset.b); go(i + 1); };
addEventListener('keydown', (e) => { if (e.target.closest('input,select,textarea')) return; if (e.key === 'ArrowRight') go(cur + 1); if (e.key === 'ArrowLeft') go(cur - 1); });
$$('.tabs button').forEach(b => b.onclick = () => {
  $$('.tabs button').forEach(x => x.setAttribute('aria-selected', x === b)); $$('.tabpanel').forEach(p => p.classList.toggle('on', p.id === b.dataset.tab));
  probes.visible = b.dataset.tab === 'tab-meter' || !!activeTest;
  if (b.dataset.tab === 'tab-sim' && !simState) startSim();
  if (b.dataset.tab === 'tab-meter') placeMeterProbes();
  if (b.dataset.tab === 'tab-manual' && simState) { simState = null; simPlaying = false; go(cur, false); }
  setTimeout(() => { drawCharts(); drawBars(); }, 30);
});
$('#tFlow').onclick = (e) => { flow.on = !flow.on; e.currentTarget.setAttribute('aria-pressed', flow.on); flow.rebuild(); refreshViews(); };
$('#tVolt').onclick = (e) => { flow.volt = !flow.volt; e.currentTarget.setAttribute('aria-pressed', flow.volt); refreshViews(); };
$('#tFit').onclick = () => { if (cur === 0 || simState) frame(overviewBox(), 'iso'); else { const s = STEPS[cur - 1]; frame(focusBox(s.focus), s.view || 'iso', s.zoom); } };
$('#tTop').onclick = () => frame(controlsBox(), 'top'); $('#tFront').onclick = () => frame(controlsBox(), 'front'); $('#tUnder').onclick = () => frame(controlsBox(), 'under');
function controlsBox() { const c = controls.target, d = camera.position.distanceTo(c) / 2.4; return new THREE.Box3(c.clone().addScalar(-d / 2), c.clone().addScalar(d / 2)); }
$('#tAll').onclick = () => { const ob = overviewBox(); frame(ob, 'iso', ob.getSize(new THREE.Vector3()).length() * 0.95); };
$('#mPod').onclick = () => go(0);
$('#mBench').onclick = () => go(BENCH_LAST);
$('#tCut').onclick = (e) => { POD.setCut(!POD.cut); e.currentTarget.setAttribute('aria-pressed', POD.cut); };
$('#tLid').onclick = (e) => { POD.lidOff = !POD.lidOff; e.currentTarget.setAttribute('aria-pressed', POD.lidOff); applyVisibility(cur); applyModelState(current().st, current().R); };
$('#tExp').oninput = (e) => { POD.setExplode(+e.target.value, true); };
$('#tExp').onchange = (e) => { POD.setExplode(+e.target.value); flow.rebuild(); refreshViews(); };
populateTP();
$('#mA').onchange = (e) => { meter.a = e.target.value; placeMeterProbes(); };
$('#mB').onchange = (e) => { meter.b = e.target.value; placeMeterProbes(); };
$$('#meterModes button').forEach(b => b.onclick = () => { meter.mode = b.dataset.m; syncMeterUI(); });
function placeMeterProbes() { const a = tpPos(meter.a), b = tpPos(meter.b); if (a && b) { placeProbe(pRed, a, 1); placeProbe(pBlk, b, -1); probes.visible = true; } }
$('#mGo').onclick = () => { placeMeterProbes(); const p = tpPos(meter.a), q = tpPos(meter.b); if (p && q) frame(new THREE.Box3().setFromPoints([p, q]).expandByScalar(15), 'iso'); };
for (const [k, v] of Object.entries({ simInsert: 'insert', simRemove: 'remove', simRead: 'read', simColour: 'colour', simWarm: 'warm', simDrop: 'drop', simGas: 'gas', simDock: 'dock', simUndock: 'undock', simDrain: 'drain' }))
  $('#' + k).onclick = () => { if (!simState) startSim(); EV[v](); flow.rebuild(); refreshViews(); updateReadouts(); };
$('#simPlay').onclick = () => { if (!simState) return startSim(); simPlaying = !simPlaying; $('#simPlay').textContent = simPlaying ? 'Pause' : 'Play'; };
$('#simReset').onclick = () => startSim();
$('#simSpeed').oninput = (e) => { simSpeed = +e.target.value; $('#simSpeedOut').textContent = `×${simSpeed}`; };
$('#simDemo').onclick = () => {
  startSim(); const at = (t, f) => queue.push({ at: t, fn: f });
  at(8, EV.insert); at(20, EV.colour); at(32, EV.warm); at(70, EV.drop); at(85, EV.gas); at(110, EV.dock); at(150, EV.undock); at(160, EV.drain);
  log('demo: full test script queued (insert → colour → warm → drop → gas → dock → undock → low battery)');
};
renderCompat(); renderParts();

// ------------------------------------------------------------------ main loop
const clock = new THREE.Clock(); let meterAcc = 0;
function loop() {
  const dt = Math.min(0.05, clock.getDelta());
  if (camTween) {
    camTween.t = Math.min(1, camTween.t + dt / 0.9); const k = easeOut(camTween.t);
    camera.position.lerpVectors(camTween.p0, camTween.p1, k); controls.target.lerpVectors(camTween.c0, camTween.c1, k);
    if (camTween.t >= 1) camTween = null;
  }
  controls.update();
  for (const a of anim) { a.t += dt; const k = Math.max(0, Math.min(1, a.t / a.dur)); if (a.t >= 0) a.f(easeOut(k)); }
  anim = anim.filter(a => a.t < a.dur + 0.05);
  if (hiBox.visible) hiBox.material.opacity = 0.55 + 0.45 * Math.sin(performance.now() / 260);
  hiBox.material.transparent = true;
  for (const m of pulsing) m.material.emissive.setRGB(0.55 * (0.5 + 0.5 * Math.sin(performance.now() / 230)), 0.38 * (0.5 + 0.5 * Math.sin(performance.now() / 230)), 0);
  if (vial.userData.anim) { const a = vial.userData.anim; a.t += dt; const k = easeOut(Math.min(1, a.t / 0.9)); vial.position.lerpVectors(vialOut, vialIn, k); if (a.t > 0.9) vial.userData.anim = null; }
  if (simState?._shake) { const tgt = POD.mode === 'pod' ? POD.podRoot : B.root; const base = POD.mode === 'pod' ? (POD.docked ? POD.dockHome.clone().add(V(0, 35, 0)) : POD.podHome) : V(0, 0, 0); simState._shake -= dt; tgt.position.set(base.x + (Math.random() - 0.5) * 2.4, base.y, base.z + (Math.random() - 0.5) * 2.4); if (simState._shake <= 0) { simState._shake = 0; tgt.position.copy(base); } }
  POD.tick(dt);
  { const pv = B.parts.e_vial.obj; if (pv.userData.drop) { const d = pv.userData.drop; d.t += dt; const k = easeOut(Math.min(1, d.t / 1.0)); pv.position.y = d.y0 + (1 - k) * 110; if (d.t > 1) pv.userData.drop = null; } }
  simTick(dt); flow.tick(dt);
  mat.visible = camera.position.y > -1;
  meterAcc += dt; if (meterAcc > 0.25) { meterAcc = 0; meterTick(); }
  renderer.render(scene, camera); labels.render(scene, camera);
  requestAnimationFrame(loop);
}
let start = 0;
go(start, false);
$('#loading').hidden = true;
window.go = go; window.frame = frame; window.focusBox = focusBox; window.items = items; window.EV = EV; window.startSim = startSim; window.__ready = true;
loop();
