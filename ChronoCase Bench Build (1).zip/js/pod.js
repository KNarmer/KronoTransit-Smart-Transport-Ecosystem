// The finished pod: printed enclosure, insulation, cradle, cartridge and dock, with every board moved
// from the bench into its pod position and the harness re-routed inside the shell.
// Pod coordinates (mm): origin at the centre of the base underside, x right, y up, z toward the front.
// Shell 190 × 130 × 160 (146 body + 14 lid), 3 mm walls; mid deck at 45 mm; XPS block above it.
import * as THREE from 'three';
import * as X from './models.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);
const PETG = () => new THREE.MeshStandardMaterial({ color: 0x1e1f21, roughness: 0.52, metalness: 0.02, map: layerTex });
const layerTex = X.canvasTex(64, 256, (g, w, h) => {
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h);
  for (let y = 0; y < h; y += 2) { g.fillStyle = y % 4 ? 'rgba(0,0,0,0.10)' : 'rgba(255,255,255,0.06)'; g.fillRect(0, y, w, 1); }
});
layerTex.wrapS = layerTex.wrapT = THREE.RepeatWrapping; layerTex.repeat.set(1, 30);
const foamTex = X.canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#f2a9b8'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 1800; i++) { g.fillStyle = `rgba(${200 + Math.random() * 40},${120 + Math.random() * 40},${140 + Math.random() * 30},0.35)`; g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }
});
foamTex.wrapS = foamTex.wrapT = THREE.RepeatWrapping; foamTex.repeat.set(0.02, 0.02);

function rrect(w, d, r, cx = 0, cz = 0) { // shape in (x, -z) plane
  const s = new THREE.Shape(); const x0 = cx - w / 2, y0 = -cz - d / 2;
  s.moveTo(x0 + r, y0); s.lineTo(x0 + w - r, y0); s.absarc(x0 + w - r, y0 + r, r, -Math.PI / 2, 0);
  s.lineTo(x0 + w, y0 + d - r); s.absarc(x0 + w - r, y0 + d - r, r, 0, Math.PI / 2);
  s.lineTo(x0 + r, y0 + d); s.absarc(x0 + r, y0 + d - r, r, Math.PI / 2, Math.PI);
  s.lineTo(x0, y0 + r); s.absarc(x0 + r, y0 + r, r, Math.PI, Math.PI * 1.5); return s;
}
function rpath(w, d, r, cx = 0, cz = 0) { const p = new THREE.Path(); const s = rrect(w, d, r, cx, cz); p.curves = s.curves; return p; }
function rectPath(x0, z0, x1, z1) { const p = new THREE.Path(); p.moveTo(x0, -z0); p.lineTo(x0, -z1); p.lineTo(x1, -z1); p.lineTo(x1, -z0); p.lineTo(x0, -z0); return p; }
function extrudeY(shape, y0, y1, mat, seg = 8) {
  const g = new THREE.ExtrudeGeometry(shape, { depth: y1 - y0, bevelEnabled: false, curveSegments: seg });
  g.rotateX(-Math.PI / 2); g.translate(0, y0, 0);
  // planar UVs from world position so print lines run horizontally on walls
  const pos = g.attributes.position, uv = g.attributes.uv;
  for (let i = 0; i < pos.count; i++) uv.setXY(i, (pos.getX(i) + pos.getZ(i)) / 64, pos.getY(i) / 256);
  return new THREE.Mesh(g, mat);
}

export function buildPod(B, scene) {
  const P = { B, enclosure: {}, mode: 'bench', explode: 0, cut: true, lidOff: false, docked: false };
  const podRoot = new THREE.Group(); podRoot.name = 'podRoot'; scene.add(podRoot);
  const dockRoot = new THREE.Group(); dockRoot.name = 'dockRoot'; scene.add(dockRoot);
  P.podRoot = podRoot; P.dockRoot = dockRoot;
  P.podHome = V(-110, 0, 0); P.dockHome = V(140, 0, 0);
  const clipPlane = new THREE.Plane(V(0, 0, -1), 14);
  P.clipMats = [];
  const enc = (id, obj, label, ref, root = podRoot, group = 'base', clip = true) => {
    obj.name = id; obj.visible = false; root.add(obj);
    obj.userData.podM = obj.matrix.clone(); obj.userData.xg = group; obj.userData.encl = true;
    if (clip) obj.traverse(m => { if (m.isMesh && !m.userData.noclip) { m.material = m.material.clone(); m.material.userData.clipKind = m.userData.clipKind || (typeof clip === 'string' ? clip : 'mid'); P.clipMats.push(m.material); } });
    B.parts[id] = { id, obj, label, ref, pod: true };
    P.enclosure[id] = obj; return obj;
  };
  const petg = PETG();

  // ---------------------------------------------------------------- shell
  {
    const g = new THREE.Group();
    const ring = rrect(190, 130, 8); ring.holes.push(rpath(184, 124, 5));
    const wall = extrudeY(ring, 3, 146, petg); wall.userData.clipKind = 'front'; g.add(wall);
    const floor = rrect(190, 130, 8); floor.holes.push(rectPath(-8, 16, 8, 24));
    const fl = extrudeY(floor, 0, 3, petg); fl.userData.noclip = true; g.add(fl);
    // deck ledges and corner bosses
    for (const sx of [-1, 1]) g.add(X.box(4, 3, 110, petg, sx * 90, 42, 0));
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      g.add(X.cyl(5, 46, petg, 20, sx * 87, 100, sz * 57));
      const ins = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 4, 16, 1, true), X.colorMat(0xc9a24a, { metalness: 1, roughness: 0.3 })); ins.position.set(sx * 87, 144, sz * 57); g.add(ins);
      const hole = X.cyl(1.6, 0.1, X.colorMat(0x050505), 12, sx * 87, 146.01, sz * 57); g.add(hole);
    }
    // embossed name on the front
    const name = new THREE.Mesh(new THREE.PlaneGeometry(70, 9), new THREE.MeshStandardMaterial({ map: X.labelTex('CHRONOCASE', { w: 768, h: 96, fg: '#5d6166', font: '800 78px Arial' }), transparent: true, depthWrite: false }));
    name.position.set(25, 118, 65.05); g.add(name);
    // switch nut + washer on the outside of the front wall
    const nut = new THREE.Mesh(new THREE.CylinderGeometry(4.6, 4.6, 2.2, 6), X.M.nickel); nut.rotation.x = Math.PI / 2; nut.position.set(-61, 30, 66.3); g.add(nut);
    const wash = new THREE.Mesh(new THREE.CylinderGeometry(5.2, 5.2, 0.6, 24), X.M.nickel); wash.rotation.x = Math.PI / 2; wash.position.set(-61, 30, 65.3); g.add(wash);
    enc('e_shell', g, 'Shell, printed PETG, 3 mm walls (190 × 130 × 146 mm)', 'D1');
  }
  // heat-set inserts shown separately for their step
  {
    const g = new THREE.Group();
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const r = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.7, 4.2, 16), X.colorMat(0xd4ab52, { metalness: 1, roughness: 0.28 })); r.position.set(sx * 87, 144, sz * 57); g.add(r);
    }
    enc('e_inserts', g, 'Brass M3 heat-set inserts ×4', 'A17', podRoot, 'base', false);
  }
  // ---------------------------------------------------------------- mid deck
  {
    const s = rrect(183, 123, 4); s.holes.push(rectPath(76, -30, 90, 50));
    const g = new THREE.Group(); g.add(extrudeY(s, 45, 48, petg));
    enc('e_deck', g, 'Mid deck, 3 mm printed plate at 45 mm', 'D1', podRoot, 'deck');
  }
  // ---------------------------------------------------------------- XPS foam block (4 layers) with the well, pack slots and cable channel
  const foamMat = new THREE.MeshStandardMaterial({ map: foamTex, color: 0xffffff, roughness: 0.95 });
  const layerY = [48, 73.4, 98.8, 124.2, 146];
  for (let i = 0; i < 4; i++) {
    let s;
    if (i === 2) {
      s = new THREE.Shape();
      const pts = [[-92, -62], [50, -62], [50, -12], [29, -12], [29, -50], [-71, -50], [-71, 50], [29, 50], [29, 12], [50, 12], [50, 62], [-92, 62]];
      s.moveTo(pts[0][0], -pts[0][1]); for (const [x, z] of pts.slice(1)) s.lineTo(x, -z); s.lineTo(pts[0][0], -pts[0][1]);
    } else { s = new THREE.Shape(); s.moveTo(-92, 62); s.lineTo(50, 62); s.lineTo(50, -62); s.lineTo(-92, -62); s.lineTo(-92, 62); s.holes.push(rectPath(-71, -50, 29, 50)); }
    if (i >= 0 && i <= 3) { s.holes.push(rectPath(-89, -40, -77, 40)); s.holes.push(rectPath(35, -40, 47, 40)); }
    const m = extrudeY(s, layerY[i] + 0.15, layerY[i + 1] - 0.15, foamMat.clone());
    const g = new THREE.Group(); g.add(m);
    enc('e_foam' + (i + 1), g, `XPS foam layer ${i + 1} of 4 (FOAMULAR, 1 in)`, 'D2', podRoot, 'foam' + (i + 1));
  }
  // cold packs (water in zip bags, fridge-chilled)
  {
    const g = new THREE.Group();
    const bag = new THREE.MeshPhysicalMaterial({ color: 0xcfe8ff, roughness: 0.2, transmission: 0.5, thickness: 6, transparent: true, opacity: 0.82 });
    for (const x of [-83, 41]) {
      const b = X.rbox(10, 70, 78, 3, bag); b.position.set(x, 61, 0); g.add(b);
      g.add(X.box(10.4, 2, 78, X.colorMat(0xe8eef2, { roughness: 0.4 }), x, 129, 0));
    }
    enc('e_packs', g, 'Two 60 mL cold packs (zip bags, chilled to 4 °C)', 'D10', podRoot, 'foam2');
  }
  // ---------------------------------------------------------------- Sorbothane feet + cradle
  {
    const g = new THREE.Group();
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const h = new THREE.Mesh(new THREE.SphereGeometry(9.5, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), X.colorMat(0x2b2420, { roughness: 0.7 }));
      h.rotation.x = Math.PI; h.position.set(-21 + sx * 19, 57.5, sz * 19); g.add(h);
    }
    enc('e_feet', g, 'Sorbothane hemispheres, 0.75 in, ×4', 'D3', podRoot, 'cradle');
  }
  {
    const g = new THREE.Group();
    const sq = new THREE.Shape(); sq.moveTo(-49, -28); sq.lineTo(7, -28); sq.lineTo(7, 28); sq.lineTo(-49, 28); sq.lineTo(-49, -28);
    const bore = new THREE.Path(); bore.absarc(-21, 0, 13.6, 0, Math.PI * 2, true); sq.holes.push(bore);
    g.add(extrudeY(sq, 61.5, 102.5, petg, 32));
    const base = new THREE.Shape(); base.moveTo(-49, -28); base.lineTo(7, -28); base.lineTo(7, 28); base.lineTo(-49, 28); base.lineTo(-49, -28);
    g.add(extrudeY(base, 57.5, 61.5, petg));
    const dark = X.colorMat(0x050505);
    const port = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), dark); port.position.set(-21, 80, 28.06); g.add(port);
    const ventHole = new THREE.Mesh(new THREE.CircleGeometry(3.1, 20), dark); ventHole.position.set(-8, 92, -28.06); ventHole.rotation.y = Math.PI; g.add(ventHole);
    const ptHole = new THREE.Mesh(new THREE.CircleGeometry(1.8, 16), dark); ptHole.position.set(-49.06, 72, 0); ptHole.rotation.y = -Math.PI / 2; g.add(ptHole);
    // NFC tab rising from the left side; reed boss on the rim (rear-left); spacer pads behind the boards
    g.add(X.box(3, 44, 46, petg, -50.5, 84, 0));
    const boss = X.box(12, 4, 6, petg, 0, 0, 0); boss.position.set(-38, 102.5, -17); boss.rotation.y = Math.PI / 4; g.add(boss);
    g.add(X.box(22, 18, 2, petg, -21, 71, 29));     // AS7341 pad
    g.add(X.box(22, 18, 2, petg, -21, 76, -29));    // BME688 pad
    g.add(X.box(2, 16, 22, petg, 8, 62, 0));        // IMU pad
    g.add(X.box(2, 16, 22, petg, 8, 84, 0));        // high-g pad
    // spring clip over the core PT1000
    const clip = new THREE.Mesh(new THREE.TorusGeometry(4, 0.4, 6, 20, Math.PI), X.M.steel); clip.position.set(-49.6, 72, 0); clip.rotation.y = Math.PI / 2; g.add(clip);
    enc('e_cradle', g, 'Cartridge cradle, printed, on four Sorbothane feet', 'D1', podRoot, 'cradle');
  }
  // vent plug (M6 ePTFE) into the cradle rear wall
  {
    const g = new THREE.Group();
    const hex = new THREE.Mesh(new THREE.CylinderGeometry(4.6, 4.6, 2.4, 6), X.colorMat(0x141414)); hex.rotation.x = Math.PI / 2; hex.position.set(-8, 92, -27); g.add(hex);
    const mem = new THREE.Mesh(new THREE.CircleGeometry(2.4, 20), X.colorMat(0xf2f2ee, { roughness: 0.9 })); mem.position.set(-8, 92, -25.75); g.add(mem);
    enc('e_vent', g, 'ePTFE vent plug M6, black', 'D5', podRoot, 'cradle', false);
  }
  // ---------------------------------------------------------------- cartridge: vial, keyed collar with N52 magnet and NTAG215 sticker
  {
    const g = new THREE.Group();
    const glass = new THREE.Mesh(new THREE.CylinderGeometry(12.7, 12.7, 52, 40, 1, true), X.M.glass); glass.position.y = 26; g.add(glass);
    const bot = new THREE.Mesh(new THREE.SphereGeometry(12.7, 32, 10, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), X.M.glass); g.add(bot);
    const liq = new THREE.Mesh(new THREE.CylinderGeometry(11.9, 11.9, 34, 32), new THREE.MeshPhysicalMaterial({ color: 0x4f9a4a, roughness: 0.1, transmission: 0.3, transparent: true, opacity: 0.88 })); liq.position.y = 17; g.add(liq);
    const cap = X.cyl(13.4, 9, X.colorMat(0x101010, { roughness: 0.5 }), 40, 0, 52); g.add(cap);
    const collar = X.cyl(15.6, 8, petg, 40, 0, 40.5); g.add(collar);
    const flat = X.box(1.2, 7, 12, petg, 0, 41, 0); flat.position.set(-15.6, 41, 0); g.add(flat);
    const mag = X.cyl(3.175, 3.175, X.M.nickel, 20); mag.rotation.z = Math.PI / 2; mag.position.set(-12.5, 42.5, -12.5); g.add(mag);
    const tag = new THREE.Mesh(new THREE.PlaneGeometry(11, 6.5), new THREE.MeshStandardMaterial({ map: X.labelTex('NTAG215', { w: 256, h: 150, fg: '#3a3a3a', bg: '#f3f1ea', font: 'bold 44px Arial' }) }));
    tag.position.set(-16.3, 44.5, 0); tag.rotation.y = -Math.PI / 2; g.add(tag);
    g.position.set(-21, 62, 0); g.updateMatrix();
    g.userData.liq = liq;
    enc('e_vial', g, 'Cartridge: 20 mL vial, keyed collar, N52 magnet, NTAG215', 'D6–D9', podRoot, 'cradle', false);
    g.userData.podM = g.matrix.clone();
  }
  // ---------------------------------------------------------------- posts, silica, lid
  {
    const g = new THREE.Group(); g.add(X.cyl(3, 68, petg, 16, 84, 48, 52)); g.add(X.box(8, 3, 8, petg, 84, 113, 52));
    enc('e_post', g, 'Ambient-probe post, printed', 'D1', podRoot, 'zoneR');
    const g2 = new THREE.Group(); g2.add(X.cyl(3, 51, petg, 16, 80, 48, 20));
    enc('e_rgbpost', g2, 'Status-LED post, printed', 'D1', podRoot, 'zoneR');
    const g3 = new THREE.Group(); const sachet = X.rbox(26, 6, 34, 3, X.colorMat(0xf1f1ec, { roughness: 0.95 })); sachet.position.set(80, 3, -50); g3.add(sachet);
    const lab = new THREE.Mesh(new THREE.PlaneGeometry(20, 12), new THREE.MeshStandardMaterial({ map: X.labelTex('SILICA GEL\nDO NOT EAT', { w: 256, h: 150, fg: '#2c4a8a', font: 'bold 34px Arial' }), transparent: true, depthWrite: false }));
    lab.rotation.x = -Math.PI / 2; lab.position.set(80, 9.05, -50); g3.add(lab);
    enc('e_silica', g3, 'Silica gel sachet (salvaged)', 'D11', podRoot, 'base', false);
  }
  {
    const g = new THREE.Group();
    // gasket: 2 mm silicone cord in the rim groove
    const path = new THREE.CurvePath(); const s = rrect(187, 127, 6.5); s.curves.forEach(c => path.add(c));
    const pts = path.getSpacedPoints(240).map(p => V(p.x, 146.4, -p.y));
    const gasket = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, true), 240, 1.0, 6, true), X.colorMat(0xc0392b, { roughness: 0.6 }));
    g.add(gasket);
    enc('e_gasket', g, 'Silicone O-ring cord gasket, 2 mm', 'D4', podRoot, 'lid');
  }
  {
    const g = new THREE.Group();
    const lidS = rrect(190, 130, 8); lidS.holes.push(rpath(5.2, 5.2, 2.5, 80, 20));
    g.add(extrudeY(lidS, 146.8, 160, petg));
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(2.5, 2.5, 13.4, 20), new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: 0.25, transmission: 0.7, thickness: 4, transparent: true, opacity: 0.8, emissive: 0x000000 }));
    pipe.position.set(80, 153.5, 20); g.add(pipe); P.pipe = pipe;
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const head = X.cyl(2.8, 1.8, X.colorMat(0x2a2a2c, { metalness: 0.8, roughness: 0.35 }), 20, sx * 87, 160, sz * 57); g.add(head);
      const hx = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.2, 6), X.colorMat(0x050505)); hx.position.set(sx * 87, 161.85, sz * 57); g.add(hx);
    }
    const plug = X.box(96, 10, 96, new THREE.MeshStandardMaterial({ map: foamTex, roughness: 0.95 }), -21, 136.6, 0); g.add(plug);
    const name = new THREE.Mesh(new THREE.PlaneGeometry(60, 7.5), new THREE.MeshStandardMaterial({ map: X.labelTex('CHRONOCASE', { w: 768, h: 96, fg: '#55595e', font: '800 78px Arial' }), transparent: true, depthWrite: false }));
    name.rotation.x = -Math.PI / 2; name.position.set(-20, 160.02, 40); g.add(name);
    enc('e_lid', g, 'Lid, 14 mm, with foam plug, light pipe and four M3 screws', 'D1', podRoot, 'lid');
  }
  // ---------------------------------------------------------------- dock box
  {
    const g = new THREE.Group();
    const ring = rrect(190, 130, 8); ring.holes.push(rpath(184, 124, 5));
    g.add(extrudeY(ring, 3, 32, petg));
    const dfloor = extrudeY(rrect(190, 130, 8), 0, 3, petg); dfloor.userData.noclip = true; g.add(dfloor);
    const top = rrect(190, 130, 8); top.holes.push(rectPath(-9, 16, 9, 24)); top.holes.push(rpath(184, 124, 5, 0, 0)); // shown open: the top is a frame
    const frame = rrect(190, 130, 8); frame.holes.push(rectPath(-9, 16, 9, 24));
    const topM = extrudeY(frame, 32, 35, petg); g.add(topM); P.dockTop = topM;
    for (const x of [-36.83 + 1.27, 36.83 + 1.27]) g.add(X.cyl(3, 26.3, X.M.nylon, 6, x, 3, 33.97));
    const hole = X.box(10, 8, 0.1, X.colorMat(0x050505), 32, 8, -65.05); g.add(hole);
    const name = new THREE.Mesh(new THREE.PlaneGeometry(60, 7.5), new THREE.MeshStandardMaterial({ map: X.labelTex('CHRONODOCK', { w: 768, h: 96, fg: '#55595e', font: '800 78px Arial' }), transparent: true, depthWrite: false }));
    name.position.set(0, 18, 65.05); g.add(name);
    enc('e_dock', g, 'Dock box, printed PETG (Pi Zero 2 W + dock board inside)', 'D1', dockRoot, 'dock');
  }
  return P;
}

// --------------------------------------------------------------------------- poses
const basis = (Xa, N) => { const Z = new THREE.Vector3().crossVectors(Xa, N); return new THREE.Matrix4().makeBasis(Xa, N, Z); };
function poseAt(center, Xa, N, localCenter) {
  const m = basis(Xa, N); const off = localCenter.clone().applyMatrix4(m);
  m.setPosition(center.clone().sub(off)); return m;
}
function poseEuler(pos, ex = 0, ey = 0, ez = 0, order = 'XYZ') {
  const m = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(ex, ey, ez, order)); m.setPosition(pos); return m;
}
export const ATTACH = {
  pp1: ['ldo', 'cin', 'cout', 'q1', 'q2', 'q3', 'q4', 'rb1', 'rb2', 'rb3', 'rb4', 'rw', 'boost', 'hdr_boost', 'h_p21p', 'h_p21n', 'h_en', 'h_a1', 'h_a2', 'h_a3', 'h_a4', 'h_gnd1', 'so_pp1'],
  pp2: ['core', 'amb', 'hdr_core', 'hdr_amb', 'h_sck', 'h_miso', 'h_mosi', 'h_cs10', 'h_cs9', 'h_3v3', 'h_gnd2', 'so_pp2'],
  pp3: ['fuse', 'rtx', 'rrx', 'magDock', 'so_pp3'],
  lsm6: ['h_i1', 'so_lsm6'], h3lis: ['h_int3', 'so_h3lis'], gauge: ['h_alrt', 'so_gauge'], dk: ['so_dk'], chg: ['so_chg'],
  as7341: ['so_as7341'], bme: ['so_bme'], rtc: ['so_rtc'], pi: ['so_pi', 'sd'], nfc: ['so_nfc'], ptcore: ['kap_core'], ptamb: ['kap_amb'],
};
export const DOCK_IDS = new Set(['pi', 'pp3', 'fuse', 'rtx', 'rrx', 'magDock', 'so_pp3', 'so_pi', 'sd']);
export const HIDE_IN_POD = new Set(['bracket', 'usb', 'so_pp2', 'so_pp3', 'so_as7341', 'so_lsm6', 'so_h3lis', 'so_bme', 'so_nfc', 'cut1a', 'blob05']);
const EXPLODE = { lid: V(0, 190, 0), foam4: V(0, 150, 0), foam3: V(0, 120, 0), foam2: V(0, 95, 0), foam1: V(0, 75, 0), cradle: V(0, 45, 0), zoneR: V(70, 35, 0), deck: V(0, 20, 0) };

function podPoses(B) {
  const S = B.specs; const ada = (k) => { const [x0, y0, x1, y1] = S[k].bbox; return V((x1 - x0) / 2, 0, -(y1 - y0) / 2); };
  const P = {};
  P.dk = poseAt(V(0, 15, -29.2), V(1, 0, 0), UP, V(68, 0, -31.8));
  P.bat = poseEuler(V(-61, 3, 30), 0, -Math.PI / 2, 0);
  P.gauge = poseAt(V(-16, 9, 16), V(0, 0, -1), UP, ada('max17048'));
  P.chg = poseAt(V(-10, 9, 45), V(1, 0, 0), UP, ada('bq24074'));
  P.pp1 = poseAt(V(51, 9, 33), V(1, 0, 0), UP, V(0, 0, 0));
  P.tog = poseEuler(V(-61, 30, 61.5), Math.PI / 2, 0, 0);
  P.magPod = poseEuler(V(0, 4, 20), Math.PI, 0, 0);
  P.rtc = poseAt(V(71, 54, -52), V(1, 0, 0), UP, ada('pcf8523'));
  P.pp2 = poseAt(V(58, 82, 0), V(0, 0, -1), V(1, 0, 0), V(0, 0, 0));
  P.as7341 = poseAt(V(-21, 80, 32.1), V(1, 0, 0), V(0, 0, -1), V(12.7, 0, -8.51));
  P.bme = poseAt(V(-21, 85, -32.1), V(-1, 0, 0), V(0, 0, 1), V(12.7, 0, -8.89));
  P.lsm6 = poseAt(V(9.4, 62, 0), V(0, 0, -1), V(1, 0, 0), ada('lsm6dsox'));
  P.h3lis = poseAt(V(9.4, 84, 0), V(0, 0, -1), V(1, 0, 0), ada('h3lis331'));
  P.nfc = poseAt(V(-52, 106, 0), V(0, 0, 1), V(-1, 0, 0), V(21.4, 0, -20.13));
  P.reed = poseEuler(V(-38, 105, -17), 0, Math.PI / 4, 0);
  P.ptcore = poseEuler(V(-35.2, 71.7, 0), 0, Math.PI, 0);
  P.ptamb = poseEuler(V(84, 118, 52), 0, 0, -Math.PI / 2);
  P.rgb = poseEuler(V(80, 99, 20), 0, 0, 0);
  {
    const q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, 0.61, 0)).multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0)));
    const m = new THREE.Matrix4().makeRotationFromQuaternion(q); const off = V(0, 9.2, 0).applyMatrix4(m);
    m.setPosition(V(-6, 80, 38).sub(off)); P.wled = m;
  }
  // dock
  P.pi = poseAt(V(0, 9, -40), V(1, 0, 0), UP, V(32.5, 0, -15));
  P.pp3 = poseAt(V(1.27, 29.3, 33.97), V(1, 0, 0), UP, V(0, 0, 0));
  return P;
}

// --------------------------------------------------------------------------- harness routing inside the pod
function zone(p) { if (p.y < 46) return 'B'; if (p.x > 50) return 'R'; return 'W'; }
function jitter(id) { let h = 7; for (const c of id) h = (h * 31 + c.charCodeAt(0)) >>> 0; return V(((h % 97) / 97 - 0.5) * 6, (((h >> 7) % 89) / 89 - 0.5) * 5, (((h >> 13) % 83) / 83 - 0.5) * 6); }
function podRoute(fa, fb, o) {
  const j = jitter(o.id || '');
  const za = zone(fa.pos), zb = zone(fb.pos);
  const EXIT = (z) => [V(26, 110, THREE.MathUtils.clamp(z, -10, 10)), V(56, 110, THREE.MathUtils.clamp(z, -10, 10))];
  const SLOT = (z) => [V(86, 60, THREE.MathUtils.clamp(z, -26, 46)), V(84, 38, THREE.MathUtils.clamp(z, -26, 46))];
  const lead = 8;
  const a0 = fa.pos.clone().addScaledVector(fa.dir, lead), b0 = fb.pos.clone().addScaledVector(fb.dir, lead);
  let nodes = [];
  const key = za + zb;
  if (key === 'WR') nodes = EXIT(a0.z); else if (key === 'RW') nodes = EXIT(b0.z).reverse();
  else if (key === 'RB') nodes = SLOT(a0.z); else if (key === 'BR') nodes = SLOT(b0.z).reverse();
  else if (key === 'WB') nodes = [...EXIT(a0.z), ...SLOT(b0.z)]; else if (key === 'BW') nodes = [...SLOT(a0.z), ...EXIT(b0.z)].reverse().length ? [...SLOT(a0.z).reverse().map(v => v), ...EXIT(b0.z).reverse()] : [];
  if (key === 'BW') nodes = [...SLOT(a0.z).reverse(), ...EXIT(b0.z).reverse()];
  nodes = nodes.map(n => n.clone().add(j));
  let pts;
  if (!nodes.length) {
    const d = fa.pos.distanceTo(fb.pos); const mid = a0.clone().lerp(b0, 0.5); mid.y = Math.max(a0.y, b0.y) + Math.min(10, 2 + d * 0.06);
    if (za === 'B') mid.y = Math.min(mid.y, 43); mid.add(j.clone().multiplyScalar(0.6));
    pts = [fa.pos, a0, mid, b0, fb.pos];
    if (d < 6) pts = [fa.pos, a0, b0, fb.pos];
  } else pts = [fa.pos, a0, ...nodes, b0, fb.pos];
  return new THREE.CatmullRomCurve3(pts, false, 'centripetal', 0.5);
}

// --------------------------------------------------------------------------- mode switching
export function makePodController(P) {
  const B = P.B;
  const poses = podPoses(B);
  const childOf = {}; for (const [p, kids] of Object.entries(ATTACH)) for (const k of kids) childOf[k] = p;
  P.childOf = childOf;
  P.rootPart = (id) => childOf[id] || id;
  const movable = () => Object.keys(B.parts).filter(id => !B.parts[id].pod && B.parts[id].obj.parent && !['cut1a', 'blob05', 'cr1220'].includes(id));
  P.solderGroups = [];
  P.enter = () => {
    if (P.mode === 'pod') return;
    P.mode = 'pod';
    podRoot.position.set(0, 0, 0); dockRoot.position.set(0, 0, 0); podRoot.updateMatrixWorld(true); dockRoot.updateMatrixWorld(true);
    const bench = {};
    for (const id of movable()) { const o = B.parts[id].obj; o.updateMatrix(); bench[id] = o.matrix.clone(); o.userData.benchM = bench[id]; o.userData.benchParent = o.parent; }
    for (const g of P.solderGroups) { g.updateMatrix(); g.userData.benchM = g.matrix.clone(); g.userData.benchParent = g.parent; }
    const place = (o, m, root) => { root.add(o); o.matrix.copy(m); o.matrix.decompose(o.position, o.quaternion, o.scale); o.userData.podM = m.clone(); };
    for (const id of movable()) {
      const o = B.parts[id].obj; const par = childOf[id];
      const root = DOCK_IDS.has(id) ? dockRoot : podRoot;
      let m;
      if (poses[id]) m = poses[id];
      else if (par && poses[par]) m = poses[par].clone().multiply(bench[par].clone().invert()).multiply(bench[id]);
      else continue;
      place(o, m, root);
      o.userData.xg = xgroup(id);
    }
    for (const g of P.solderGroups) {
      const par = g.userData.pp; if (!poses[par]) continue;
      const m = poses[par].clone().multiply(bench[par].clone().invert()).multiply(g.userData.benchM);
      place(g, m, DOCK_IDS.has(par) ? dockRoot : podRoot); g.userData.xg = xgroup(par);
    }
    // the LED holders stay as printed holders; hide bench-only objects
    for (const id of HIDE_IN_POD) if (B.parts[id]) B.parts[id].obj.userData.podHidden = true;
    B.parentFor = (a, b) => (DOCK_IDS.has(P.rootPart(a.p)) || DOCK_IDS.has(P.rootPart(b.p))) ? dockRoot : podRoot;
    B.podRoute = podRoute;
    rebuildWires();
    podRoot.position.copy(P.podHome); dockRoot.position.copy(P.dockHome);
    P.setCut(P.cut);
  };
  P.exit = () => {
    if (P.mode !== 'pod') return;
    P.mode = 'bench'; P.setExplode(0, true); P.dock(false, true);
    for (const id of movable()) {
      const o = B.parts[id].obj; if (!o.userData.benchM) continue;
      o.userData.benchParent.add(o); o.matrix.copy(o.userData.benchM); o.matrix.decompose(o.position, o.quaternion, o.scale);
    }
    for (const g of P.solderGroups) { if (!g.userData.benchM) continue; g.userData.benchParent.add(g); g.matrix.copy(g.userData.benchM); g.matrix.decompose(g.position, g.quaternion, g.scale); }
    B.parentFor = null; B.podRoute = null;
    rebuildWires();
  };
  const xgroup = (id) => {
    const r = P.rootPart(id);
    if (['as7341', 'bme', 'lsm6', 'h3lis', 'nfc', 'reed', 'ptcore', 'wled'].includes(r)) return 'cradle';
    if (['pp2', 'rtc', 'ptamb', 'rgb'].includes(r)) return 'zoneR';
    if (DOCK_IDS.has(r)) return 'dock';
    return 'base';
  };
  function rebuildWires() {
    const keepP = podRoot.position.clone(), keepD = dockRoot.position.clone();
    podRoot.position.set(0, 0, 0); dockRoot.position.set(0, 0, 0); podRoot.updateMatrixWorld(true); dockRoot.updateMatrixWorld(true);
    for (const id of Object.keys(B.wires)) { if (id === 'usb' && P.mode === 'pod') { B.wires[id].obj.visible = false; continue; } B.rebuild(id); }
    podRoot.position.copy(keepP); dockRoot.position.copy(keepD);
    P.onRebuild?.();
  }
  P.rebuildWires = rebuildWires;
  P.setExplode = (k, noRebuild) => {
    P.explode = k;
    const all = [...Object.values(B.parts).map(p => p.obj), ...P.solderGroups];
    for (const o of all) {
      if (!o.userData.podM || (o.parent !== podRoot)) continue;
      const off = EXPLODE[o.userData.xg]; o.matrix.copy(o.userData.podM);
      if (off) o.matrix.premultiply(new THREE.Matrix4().makeTranslation(off.x * k, off.y * k, off.z * k));
      o.matrix.decompose(o.position, o.quaternion, o.scale); o.userData._y0 = o.position.y;
    }
    if (!noRebuild && P.mode === 'pod') rebuildWires();
  };
  P.setCut = (on) => {
    P.cut = on;
    for (const m of P.clipMats) { m.clippingPlanes = on ? [m.userData.clipKind === 'front' ? clipFront : clip] : null; m.clipShadows = true; m.side = on ? THREE.DoubleSide : THREE.FrontSide; m.needsUpdate = true; }
  };
  const clip = new THREE.Plane(V(0, 0, -1), 14), clipFront = new THREE.Plane(V(0, 0, -1), 58);
  P.dockAnim = null;
  P.dock = (on, instant) => {
    if (P.docked === !!on && !instant) return; P.docked = !!on;
    const to = on ? P.dockHome.clone().add(V(0, 35, 0)) : P.podHome.clone();
    if (instant || P.mode !== 'pod') { podRoot.position.copy(to); return; }
    P.dockAnim = { t: 0, from: podRoot.position.clone(), to };
  };
  P.tick = (dt) => {
    if (!P.dockAnim) return; const a = P.dockAnim; a.t = Math.min(1, a.t + dt / 1.6);
    const k = a.t < 0.5 ? 2 * a.t * a.t : 1 - Math.pow(-2 * a.t + 2, 2) / 2;
    podRoot.position.lerpVectors(a.from, a.to, k); podRoot.position.y += Math.sin(Math.PI * k) * 60;
    if (a.t >= 1) P.dockAnim = null;
  };
  const podRoot = P.podRoot, dockRoot = P.dockRoot;
  return P;
}

// --------------------------------------------------------------------------- Build D steps (week 5): moving into the pod
export const POD_STEPS = (() => {
  const s = []; const add = (title, text, o = {}) => s.push({ build: 'D', scene: 'pod', title, text, ...o });
  add('Print the shell', 'Print the shell in black PETG (3 mm walls, 0.2 mm layers, 4 perimeters). Black keeps the optical bay dark. The floor has a pocket for the pod half of the dock connector.', { show: ['e_shell'], focus: ['e_shell'], parts: ['e_shell'] });
  add('Heat-set inserts', 'Press four <b>M3 brass inserts</b> into the corner bosses with the iron at 220 °C. The lid screws into them.', { show: ['e_inserts'], focus: ['e_inserts'], parts: ['e_inserts'], view: 'top' });
  add('Dock connector into the base', 'Glue the <b>flat-pad half</b> into the floor pocket, pads facing down, paint dot toward the front. Its five wires are already soldered.', { show: ['magPod'], focus: ['magPod'], zoom: 40, view: 'under', parts: ['magPod'] });
  add('Battery', 'Stick the <b>LiPo</b> into the front-left of the base tray with foam tape, lead toward the middle.', { show: ['bat'], focus: ['bat'], zoom: 70, parts: ['bat'] });
  add('Fuel gauge', 'Screw the <b>MAX17048</b> (6 mm standoffs) between the battery and the DK; the battery plugs straight into it.', { show: ['gauge'], focus: ['gauge'], zoom: 50, parts: ['gauge'] });
  add('Charger', 'Screw the <b>bq24074</b> to the front-centre of the tray, JST sockets facing right.', { show: ['chg'], focus: ['chg'], zoom: 55, parts: ['chg'] });
  add('Power & light board', 'Screw <b>Perma-Proto #1</b> to the front-right of the tray, with everything on it still wired.', { show: ['pp1'], focus: ['pp1'], zoom: 80, parts: ['pp1'] });
  add('Main switch', 'Push the <b>toggle switch</b> through the front-wall hole (front-left, above the battery) and tighten the nut and washer outside.', { show: ['tog'], focus: ['tog'], zoom: 45, parts: ['tog'] });
  add('nRF5340 DK', 'Lower the <b>DK</b> onto its four 12 mm standoffs at the rear of the tray, jumpers still plugged in.', { show: ['dk'], focus: ['dk'], zoom: 110, parts: ['dk'] });
  add('Silica gel', 'Drop a <b>silica gel sachet</b> in the rear-right corner of the tray.', { show: ['e_silica'], focus: ['e_silica'], zoom: 40, parts: ['e_silica'] });
  add('Mid deck', 'Lay the <b>3 mm mid deck</b> on its ledges at 45 mm. Feed the backbone and cradle wiring up through the slot on the right.', { show: ['e_deck'], focus: ['e_deck'], parts: ['e_deck'] });
  add('Real-time clock', 'Screw the <b>PCF8523</b> to the deck’s rear-right corner, behind the backbone.', { show: ['rtc'], focus: ['rtc'], zoom: 45, parts: ['rtc'] });
  add('Backbone upright', 'Stand <b>Perma-Proto #2</b> upright on the right of the deck, MAX31865 boards facing the right wall, terminal blocks on top.', { show: ['pp2'], focus: ['pp2'], zoom: 90, parts: ['pp2'] });
  add('Ambient probe post', 'Glue the printed <b>post</b> in the front-right corner and tape the <b>ambient PT1000</b> to its tip, in free air.', { show: ['e_post', 'ptamb'], focus: ['e_post'], zoom: 60, parts: ['e_post', 'ptamb'] });
  add('Status LED post', 'Glue the <b>LED post</b> beside the backbone; the RGB LED sits in its holder, right under the lid’s light pipe.', { show: ['e_rgbpost', 'rgb'], focus: ['e_rgbpost', 'rgb'], zoom: 60, parts: ['e_rgbpost', 'rgb'] });
  for (let i = 1; i <= 4; i++) add(`Foam layer ${i}`, `Cut <b>XPS layer ${i}</b> from the FOAMULAR panel with a hot knife: the 100 × 100 mm well, two pack slots${i === 3 ? ', and the cable channel to the backbone' : ''}. Press it in.`, { show: ['e_foam' + i], focus: ['e_foam' + i], parts: ['e_foam' + i] });
  add('Cold packs', 'Chill two 60 mL water bags at 4 °C (never frozen) and slide them into the <b>pack slots</b> either side of the well.', { show: ['e_packs'], focus: ['e_packs'], parts: ['e_packs'] });
  add('Sorbothane feet', 'Stick the four <b>Sorbothane hemispheres</b> on the well floor.', { show: ['e_feet'], focus: ['e_feet'], zoom: 45, parts: ['e_feet'] });
  add('Cradle', 'Set the printed <b>cradle</b> on the feet. Its optical port faces the front.', { show: ['e_cradle'], focus: ['e_cradle'], zoom: 70, parts: ['e_cradle'] });
  add('AS7341 on the optical port', 'Screw the <b>AS7341</b> over the optical port with nylon screws, window square to the vial, 5–10 mm from the wall.', { show: ['as7341'], focus: ['as7341'], zoom: 45, parts: ['as7341'] });
  add('White LED', 'Clip the <b>white LED</b> holder beside the port, aimed 35° at the vial.', { show: ['wled'], focus: ['wled'], zoom: 40, parts: ['wled'] });
  add('IMU', 'Screw the <b>LSM6DSOX</b> tight to the cradle’s right flat, low. No foam tape: it has to feel every bump.', { show: ['lsm6'], focus: ['lsm6'], zoom: 45, parts: ['lsm6'] });
  add('High-g accelerometer', 'Screw the <b>H3LIS331</b> to the right flat, above the IMU.', { show: ['h3lis'], focus: ['h3lis'], zoom: 45, parts: ['h3lis'] });
  add('BME688', 'Screw the <b>BME688</b> into the rear pocket, sensor facing the vent.', { show: ['bme'], focus: ['bme'], zoom: 45, view: 'back', parts: ['bme'] });
  add('Vent plug', 'Thread the <b>ePTFE vent plug</b> into the cradle’s rear wall.', { show: ['e_vent'], focus: ['e_vent'], zoom: 35, view: 'back', parts: ['e_vent'] });
  add('NFC module', 'Screw the <b>ST25R3916B module</b> to the printed tab on the cradle’s left, antenna at collar height.', { show: ['nfc'], focus: ['nfc'], zoom: 60, parts: ['nfc'] });
  add('Reed switch', 'Press the heat-shrunk <b>reed switch</b> into the rim boss at the rear-left, where the collar magnet lands.', { show: ['reed'], focus: ['reed'], zoom: 35, parts: ['reed'] });
  add('Core PT1000', 'Slide the <b>core element</b> through the hole in the cradle’s left wall so it touches the vial; the spring clip holds it.', { show: ['ptcore'], focus: ['ptcore'], zoom: 35, parts: ['ptcore'] });
  add('Cartridge', 'Fill the vial with indicator, fit the <b>keyed collar</b> (N52 magnet, NTAG215 on the flat facing the NFC module) and drop it into the cradle.', { show: ['e_vial'], state: { cartridge: 1 }, focus: ['e_vial'], zoom: 70, parts: ['e_vial'] });
  add('Gasket', 'Press <b>2 mm silicone cord</b> into the rim groove all the way round; cut it so the ends just meet.', { show: ['e_gasket'], focus: ['e_gasket'], parts: ['e_gasket'] });
  add('Lid', 'Fill the light pipe with clear hot glue, then screw the <b>lid</b> down with four M3 screws. The foam plug closes the well.', { show: ['e_lid'], focus: ['e_lid'], parts: ['e_lid'] });
  add('Switch ON: Gate D', 'Flip the switch ON. Status light blinks green under the lid; core and ambient readings agree before the packs go in. <b>Gate D:</b> closed lid, core 2–8 °C for 8 hours.', { state: { toggle: 1, boost: 1 }, focus: ['e_shell'] });
  add('Dock box', 'The <b>dock</b>: Pi Zero 2 W and the dock board on 26 mm posts, spring pins through the top frame.', { show: ['e_dock', 'pi', 'pp3'], state: { pi: 1 }, focus: ['e_dock'], parts: ['e_dock'] });
  add('Dock the pod', 'Set the pod on the dock; the magnets pull the pads onto the spring pins. Charging starts and the log syncs.', { state: { docked: 1 }, focus: ['e_dock', 'e_shell'] });
  return s;
})();
